-- MariaDB dump 10.19  Distrib 10.4.31-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.4.31-MariaDB-1:10.4.31+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` text NOT NULL,
  `icon` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) NOT NULL DEFAULT '',
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(120) NOT NULL DEFAULT '',
  `widgets` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `non_exclude_fields` text DEFAULT NULL,
  `explicit_allowdeny` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` text DEFAULT NULL,
  `db_mountpoints` text DEFAULT NULL,
  `pagetypes_select` text DEFAULT NULL,
  `tables_select` text DEFAULT NULL,
  `tables_modify` text DEFAULT NULL,
  `groupMods` text DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `subgroup` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` text DEFAULT NULL,
  `mfa_providers` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(255) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `email` varchar(255) NOT NULL DEFAULT '',
  `db_mountpoints` text DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) NOT NULL DEFAULT '',
  `userMods` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `TSconfig` text DEFAULT NULL,
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  `mfa` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1706085502,1546914362,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$OTZGVzdmRlFwU3B1eHBYOA$ZoMJFRKz/iuEQzOjQQ0CtRecps7UpySaaEBzmO7SKy8',1,'','default','',NULL,0,'',NULL,'','',NULL,NULL,1,NULL,1706085266,0,NULL,'',NULL),(5,0,1679749610,1679749610,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$L3F0c01xSHRPNzBta3JDbg$rfRlZaRf2eGXogySwzq98eZNZ+YX5h0mxXBkMLne3gc',1,NULL,'default','',NULL,0,'',NULL,'','',NULL,NULL,1,NULL,0,0,NULL,'',NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--

LOCK TABLES `cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--

LOCK TABLES `cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` text DEFAULT NULL,
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(2048) DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(11) NOT NULL DEFAULT 0,
  `keywords` text DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `newUntil` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text DEFAULT NULL,
  `module` varchar(255) NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` text DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` text DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` text DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `canonical_link` varchar(2048) NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_pagelist_images` int(10) unsigned DEFAULT 0,
  `tx_pagelist_datetime` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_pagelist_eventfinish` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_pagelist_eventlocation` tinytext DEFAULT NULL,
  `tx_pagelist_eventlocationlink` tinytext DEFAULT NULL,
  `tx_pagelist_productprice` varchar(255) DEFAULT NULL,
  `tx_pagelist_notinlist` int(11) NOT NULL DEFAULT 0,
  `tx_pagelist_starttime` int(11) NOT NULL DEFAULT 0,
  `tx_pagelist_endtime` int(11) NOT NULL DEFAULT 0,
  `tx_advancedtitle_prefix` tinytext DEFAULT NULL,
  `tx_advancedtitle_sufix` tinytext DEFAULT NULL,
  `tx_personnel_authors` tinytext DEFAULT NULL,
  `tx_advancedtitle_absolute` tinytext DEFAULT NULL,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `tx_pagelist_eventstart` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_pagelist_shortcut` varchar(255) DEFAULT NULL,
  `page_icon` varchar(120) NOT NULL DEFAULT '',
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `slug` (`slug`(127)),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1705996759,1546914440,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"title\":\"\"}',0,0,0,0,1,1,31,27,0,'Power of TYPO3 in a Ready-to-go Package','/',1,NULL,1,0,'',0,0,'',0,'',0,0,'typo3, template, open source, free',0,'',0,'Free template for TYPO3 CMS. Easy to use and configure for your own needs.',0,1705996759,NULL,'',0,'','','',0,0,0,0,0,'pagets__home','pagets__sub','EXT:microtemplate/Configuration/PageTS/setup.typoscript,EXT:beux/Configuration/PageTS/setup.typoscript','',0,0,'','',0,'','',0,'',0,0,0,0,NULL,NULL,NULL,0,0,0,'','| Microtemplate',NULL,NULL,0.5,'','summary',0,NULL,'',0),(2,1,1679820847,1546915678,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"tx_advancedtitle_prefix\":\"\",\"tx_advancedtitle_sufix\":\"\",\"tx_advancedtitle_absolute\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"tx_pagelist_images\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"tx_pagelist_notinlist\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,1,31,31,0,'Features','/features',1,NULL,0,0,'',0,0,'',0,'',0,0,'TYPO3, template,features,speed,css,js,html',0,'',0,'TYPO3 template with good looks and lightning speed!',0,1679820847,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'TYPO3 Microtemplate Features','TYPO3 template with good looks and lightning speed!',0,'TYPO3 Microtemplate Features','TYPO3 template with good looks and lightning speed!',0,'',0,0,0,0,NULL,NULL,NULL,0,0,0,'','',NULL,NULL,0.5,'','summary',0,NULL,'',0),(3,1,1639989524,1546917831,0,0,0,0,'',512,NULL,0,0,0,0,NULL,0,'a:20:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;s:23:\"tx_advancedtitle_prefix\";N;s:22:\"tx_advancedtitle_sufix\";N;s:18:\"tx_favicon_favicon\";N;}',0,0,0,0,1,1,31,27,0,'Articles & Events','/articles-events',199,NULL,0,0,'',0,3,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,0.5,'','',0,NULL,'',0),(5,3,1679761638,1546919175,0,0,0,0,'',80,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"subtitle\":\"\",\"slug\":\"\",\"tx_pagelist_datetime\":\"\",\"lastUpdated\":\"\",\"abstract\":\"\",\"tx_personnel_authors\":\"\",\"tx_pagelist_images\":\"\",\"seo_title\":\"\",\"description\":\"\",\"tx_advancedtitle_prefix\":\"\",\"tx_advancedtitle_sufix\":\"\",\"tx_advancedtitle_absolute\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"keywords\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"tx_staticfilecache_cache\":\"\",\"tx_staticfilecache_cache_force\":\"\",\"tx_staticfilecache_cache_offline\":\"\",\"tx_staticfilecache_cache_priority\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"tx_pagelist_notinlist\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,1,31,31,0,'Article for content examples','/article-for-content-examples',136,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1679761638,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,1,1546775160,0,NULL,NULL,NULL,0,0,0,NULL,NULL,'2',NULL,0.5,'','summary',0,NULL,'',0),(6,1,1679747808,1546919223,0,0,0,0,'0',2304,NULL,0,0,0,0,NULL,0,'{\"title\":\"\"}',0,0,0,0,1,1,31,25,0,'Personnel','/personnel',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,0.5,'','',0,NULL,'',0),(7,3,1679761611,1546921754,0,0,0,0,'',160,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"subtitle\":\"\",\"slug\":\"\",\"tx_pagelist_datetime\":\"\",\"lastUpdated\":\"\",\"tx_pagelist_eventstart\":\"\",\"tx_pagelist_starttime\":\"\",\"tx_pagelist_eventfinish\":\"\",\"tx_pagelist_endtime\":\"\",\"tx_pagelist_eventlocation\":\"\",\"tx_pagelist_eventlocationlink\":\"\",\"abstract\":\"\",\"tx_personnel_authors\":\"\",\"tx_pagelist_images\":\"\",\"seo_title\":\"\",\"description\":\"\",\"tx_advancedtitle_prefix\":\"\",\"tx_advancedtitle_sufix\":\"\",\"tx_advancedtitle_absolute\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"keywords\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"tx_staticfilecache_cache\":\"\",\"tx_staticfilecache_cache_force\":\"\",\"tx_staticfilecache_cache_offline\":\"\",\"tx_staticfilecache_cache_priority\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"tx_pagelist_notinlist\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,1,31,31,0,'Event example','/event-example',137,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1679761611,'Event introduction, just a short summary for vCal and lists.','',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,1,1639908000,1644249600,'Longmen Village, Penghu, Taiwan','https://www.google.com/maps/place/Longmen+Beach/@23.564886,119.683584,15z/data=!4m12!1m6!3m5!1s0x0:0xc6f5020858fbe74a!2sLongmen+Beach!8m2!3d23.564886!4d119.683584!3m4!1s0x0:0xc6f5020858fbe74a!8m2!3d23.564886!4d119.683584',NULL,0,1,1,'','','3',NULL,0.5,'','summary',1643709600,NULL,'',0),(11,1,1679747798,1546940212,0,0,0,0,'',912,NULL,0,0,0,0,NULL,0,'a:49:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:23:\"tx_advancedtitle_prefix\";N;s:22:\"tx_advancedtitle_sufix\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:18:\"tx_favicon_favicon\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:18:\"tx_pagelist_images\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:21:\"tx_pagelist_notinlist\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,1,1,31,27,0,'Error 404','/error-404',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1679747798,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',1,0,'',NULL,0,'',NULL,0,'',0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,0.5,'','',0,NULL,'',0),(26,1,1639989513,1568099806,0,0,0,0,'',656,NULL,0,0,0,0,NULL,0,'a:1:{s:5:\"title\";N;}',0,0,0,0,1,1,31,31,0,'Success!','/success',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1639989513,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,0.5,'','',0,NULL,'',0),(54,1,1678368278,1678368255,0,0,0,0,'0',2560,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,27,0,'Menu content','/menu-content',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0,1678368131,0,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,0.5,'','summary',0,NULL,'',0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext NOT NULL,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (2,0,1679820308,1546915254,0,1,'2',0,'/user_upload/bg/anime-city-desktop-wallpaper.jpg','de68a4318de14ea1e74203b3a36a189520745c95','77461e349bd1a778aff63a4f8603b4eea691eee5','jpg','image/jpeg','anime-city-desktop-wallpaper.jpg','c12bf83567b5269bab05cd9b474564fb8e9c4cef',189664,1679746821,1639832671),(4,0,1546918619,0,0,0,'2',0,'/typo3conf/ext/pagelist/Resources/Public/Images/clear.png','0c091a9e69750ff60eb7d39f0f8f27ce72bf912b','3f394c4cb51deb9535eadbaabea7d3ad79b89ed9','png','image/png','clear.png','3442a95fe890ce4769b36b2ecc611b801a54cfb5',95,1546914103,1546914103),(5,0,1679823273,1546922224,0,1,'2',0,'/user_upload/persons/obama_.jpg','01a0fc8121f105920d517a223298e48d4a35d674','3d43b9840044b5156cff303a1b06302bd6f6a36e','jpg','','obama_.jpg','01614a09a7615af8dfd9d5040c1efb0aecda8dd9',255391,1679823273,1679823208),(8,0,1679820326,1546994332,0,1,'2',0,'/user_upload/icons/favicon.png','7d0fe513c43b2d60d399a63579f3792b0669b20c','0254dba25222ae8bfa0ee1b38a90ca349548b97d','png','image/png','favicon.png','fe8efedb19d5e6930fcaa365301bc76fd33fec51',1921,1679746821,1639832671),(10,0,1547775392,0,0,0,'2',0,'/typo3conf/ext/news/Resources/Public/Images/dummy-preview-image.png','9f596bc172c8537a3ddc2d6efbb7e3212094e837','e70c7d8d1f511f7ac68ed0154b9a7ded896e72f2','png','image/png','dummy-preview-image.png','b069aa085f06da6743b904400b0e412c3b0b5b07',25896,1547775045,1541485963),(13,0,1679820318,1548056315,0,1,'2',0,'/user_upload/corporate/favicon.png','9a47a353dabc3c622193f9d366e30efe326aad6e','7b3ad4c23dbc86c6810a63003b6c61874d24c721','png','image/png','favicon.png','fe8efedb19d5e6930fcaa365301bc76fd33fec51',1921,1679746821,1639832671),(16,0,1679747678,1559996683,0,1,'1',0,'/form_definitions/contactus_1.form.yaml','35839f76d665a569c0f3569bcdfc97ef304c5c0c','c62e3e70a526a59f0f0b7687864947eab72d7d3f','yaml','text/plain','contactus_1.form.yaml','2728ba22b8ea09807059499c1a8dc3eff5f06f4a',3194,1679747678,1679747678),(21,0,1568973233,0,0,0,'2',0,'/typo3conf/ext/microtemplate/Resources/Public/Images/ico_soundoff.svg','4d3ed9adfebdd0dd5786740890c5d44f98a0b73e','c9fb5963292375e0421dc583abec37994351f306','svg','image/svg+xml','ico_soundoff.svg','81fa3d3c500cc6cded40dd084fc5a791f560cb0f',765,1568972570,1568972570),(22,0,1568973288,0,0,0,'2',0,'/typo3conf/ext/microtemplate/Resources/Public/Images/ico_soundon.svg','a93c4417a903b6c84f33d9f0e28b356a2b97061f','c9fb5963292375e0421dc583abec37994351f306','svg','image/svg+xml','ico_soundon.svg','667f7de07184068ce5fd8e94801932ed17eb2aa3',692,1568972578,1568972578),(29,0,1569484601,1569484601,1,1,'5',0,'/user_upload/00045_04.pdf','c4779495e5a58902cee8dfa912052f623755949a','19669f1e02c2f16705ec7587044c66443be70725','pdf','application/pdf','00045_04.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1569484601,1569484600),(30,0,1569484724,1569484724,1,1,'5',0,'/user_upload/00045_05.pdf','a6ac66390076d277664ba9d285e447f6ae86962e','19669f1e02c2f16705ec7587044c66443be70725','pdf','application/pdf','00045_05.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1569484724,1569484724),(31,0,1569484753,1569484753,1,1,'5',0,'/user_upload/00045_06.pdf','d12b0878e4163a9fab5cc30b27130693e1c01a16','19669f1e02c2f16705ec7587044c66443be70725','pdf','application/pdf','00045_06.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1569484753,1569484753),(32,0,1569490843,1569490843,1,1,'5',0,'/user_upload/00045_07.pdf','67e7412f0bafac75bf4ff9beb68a84cec3b942ff','19669f1e02c2f16705ec7587044c66443be70725','pdf','application/pdf','00045_07.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1569490843,1569490842),(33,0,1569490861,1569490861,1,1,'5',0,'/user_upload/00045_08.pdf','8ecf0f4ce53316d3561da95af5c4fe9f5e0f981a','19669f1e02c2f16705ec7587044c66443be70725','pdf','application/pdf','00045_08.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1569490861,1569490861),(34,0,1642087033,1569493073,0,1,'1',0,'/form_definitions/form_definitions/contactus.form.yaml','f16aa372d5957600fdeef976b48cbcdd884459f5','b35cda9a1f5ead13e2f6e66bed83771f8ba7faf1','yaml','text/plain','contactus.form.yaml','39e73eb11918765927762c24249da7ddde5e7e6b',3163,1639832671,1639832671),(35,0,1642087033,1569493073,0,1,'1',0,'/form_definitions/form_definitions/contactus_1.form.yaml','62eaf8d84c2b8ef9c094e32379c605cffbf8f3b8','b35cda9a1f5ead13e2f6e66bed83771f8ba7faf1','yaml','text/plain','contactus_1.form.yaml','0912913ae0d2c8f31aeffad6747a38bfff598da3',2230,1639832671,1639832671),(39,0,1638523729,0,0,0,'2',0,'/typo3temp/assets/online_media/youtube_ca47273252cbacf9a8ca1d3b474276f4.jpg','2011a7baaf3e4d96393b832c29be91c2a49e16ae','4cc752e47a34a774308932666b4f77c095218aab','jpg','image/jpeg','youtube_ca47273252cbacf9a8ca1d3b474276f4.jpg','b48caf7a58305e93cc60feaffcd30e77ae5cd091',64864,1638523729,1638523729),(40,0,1638529925,0,0,0,'2',0,'/typo3conf/ext/microtemplate/Resources/Public/Icons/Extension.png','62da83939620080f0bcf609d089f1132c444f95a','45a0b8fd6fe6aadf4b87c40f70f2f28bdd557299','png','image/png','Extension.png','cf0ddad4ae5378b12bdcb6a8ac32c860e60e19d6',2448,1638529682,1638529682),(41,0,1705294917,1705294917,0,1,'4',0,'/user_upload/videos/the_claypool_lennon_delirium_-_blood_and_rockets__live_at_the_current_.youtube','6fe9a285bc55f62bf2f3711825bf4cb4c31bc85c','f05a21365c4a2f25a46d9ee7628fa779ede128fc','youtube','video/youtube','the_claypool_lennon_delirium_-_blood_and_rockets__live_at_the_current_.youtube','f585d0dd70808500974b07be57fbcfaa0c32d514',11,1705294917,1704807937),(42,0,1638776310,0,0,0,'2',0,'/typo3temp/assets/online_media/youtube_5e976ac5f7f6502a38f08f65d5b629a2.jpg','8c0d56b9a75b8323d006665b903c38362d40c1c1','4cc752e47a34a774308932666b4f77c095218aab','jpg','image/jpeg','youtube_5e976ac5f7f6502a38f08f65d5b629a2.jpg','274a562de06eb646397a5ab5c3291bf5a95a46c0',15712,1638776310,1638776310),(46,0,1639949398,0,0,1,'5',0,'/user_upload/user_upload/00045.pdf','ae90f8ca42911aaaaf5034368283b541cc1258b7','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(47,0,1639949398,0,0,1,'5',0,'/user_upload/user_upload/00045_01.pdf','88e98b53f237a1b7a6aecd287aef0b006a647424','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_01.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(48,0,1639949399,0,0,1,'5',0,'/user_upload/user_upload/00045_02.pdf','f5e0706912dcdc151e9a9bd22e3a632ba19636d6','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_02.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(49,0,1639949399,0,0,1,'5',0,'/user_upload/user_upload/00045_03.pdf','8a297e18d6a0c8784603dcc3411c0fc23966b67c','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_03.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(50,0,1639949399,0,0,1,'5',0,'/user_upload/user_upload/00045_04.pdf','c0ccae3074d52075d509521bb0c00f155b8a94a1','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_04.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(51,0,1639949400,0,0,1,'5',0,'/user_upload/user_upload/00045_05.pdf','0c9b83e001e8b596a3fec4956c2e2f973e1bd3e7','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_05.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(52,0,1639949400,0,0,1,'5',0,'/user_upload/user_upload/00045_06.pdf','4a2fba044aba94c53d442430c0a73fbefdce3eda','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_06.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(53,0,1639949400,0,0,1,'5',0,'/user_upload/user_upload/00045_07.pdf','03797ae7b0d933337ab02d0db831daae60805092','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_07.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(54,0,1639949400,0,0,1,'5',0,'/user_upload/user_upload/00045_08.pdf','30677a8341ea5b81d4063cc653ae36ff320fe618','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_08.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(74,0,1642087033,0,0,1,'4',0,'/user_upload/media/video/cityscape.mp4','0c6546111d6bf211d9eae9b5cece158204ee3b06','d9c66617c830db5765b3cdedbe585dd99e85f4f8','mp4','video/mp4','cityscape.mp4','e833a337b2f772c15a4119f26bcf36c5260c6a17',3334253,1639832671,1639832671),(81,0,1642087033,0,0,1,'5',0,'/user_upload/user_upload/_temp_/index.html','5ba4b9055ef5f636e670775269e51f762c75e804','a34b977abbe38f57b102296673b84f2bedf1860c','html','application/x-empty','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',0,1639832671,1639832671),(82,0,1642087033,0,0,1,'1',0,'/user_upload/user_upload/_temp_/importexport/index.html','72606fa22bef4d75b8f8aca7e26742311b9bddd0','0b424920f998855ea7209e85f5329d9e6b894b29','html','text/html','index.html','344e8d2f838769251206d105d6977c1e6b5dab44',110,1639832671,1639832671),(83,0,1642087033,0,0,1,'5',0,'/user_upload/user_upload/index.html','b1377759ea12f03a6c1cb93e90306abdc7f01d75','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','html','application/x-empty','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',0,1639832671,1639832671),(84,0,1642087033,0,0,1,'5',0,'/user_upload/_temp_/index.html','a3ef597b554ed2a28c720b3e90e51edc9ec642b1','4e0743c93934dd9a02564d8e654d714bd2dc3d20','html','application/x-empty','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',0,1639832671,1639832671),(85,0,1642087033,0,0,1,'1',0,'/user_upload/_temp_/importexport/index.html','68614dc2826769e93d8a8ead62af30ac99aaa83a','0795cf796b4fc959be0ec00b183c0f47609dd9a5','html','text/html','index.html','344e8d2f838769251206d105d6977c1e6b5dab44',110,1639832671,1639832671),(86,0,1642087033,0,0,1,'1',0,'/_temp_/index.html','1cd5eec12b9b11599c0b4c6b2d43342c4fb53a7b','0258f8a5f703dd44c350fbfcddeecb1634d46ad4','html','text/html','index.html','344e8d2f838769251206d105d6977c1e6b5dab44',110,1610276839,1546914266),(92,0,1642087033,0,0,1,'2',0,'/user_upload/media/images/pic.jpg','fad056d37762940b7c1596e4a0e0336f56b3b3d7','1dcf72b02574755552c4f8b8e43e44a0e8dea5fe','jpg','image/jpeg','pic.jpg','ecc9203ed78ff8f7234ee5abf74da710efe3cb21',3974321,1639832671,1639832671),(93,0,1642087033,0,0,1,'4',0,'/user_upload/user_upload/img/bg/sunset-lapse.mp4','25c72d23ddce3fadf9b8a5f55bd8cd99ea340e80','260c52f5f2d1b027d200c5aead280881514d5de2','mp4','video/mp4','sunset-lapse.mp4','a723ef48863180f29849665bc7979a15cd794d51',4302509,1639832671,1639832671),(95,0,1642087033,0,0,1,'4',0,'/user_upload/media/the_knife_-_a_tooth_for_an_eye_-_official_video.youtube','984e291f624c91decf594ad6bb768a634fa5f3a2','df6d8fdb269ee2f04a4c68ac639c0e4d8d670990','youtube','video/youtube','the_knife_-_a_tooth_for_an_eye_-_official_video.youtube','4546de77bc886ca62f815b7d46f1d533c92011ea',11,1639832671,1639832671),(97,0,1642344307,0,0,0,'5',0,'/typo3conf/ext/microtemplate/Resources/Public/Fonts/fira-sans-extra-condensed-v5-latin-500.woff2','0976a1dad2f49bf41dfdebc335318af869275fd8','c0d6295a7e4642af3e3b5aaf435a1d3b143ee6ef','woff2','application/octet-stream','fira-sans-extra-condensed-v5-latin-500.woff2','88b0869975ab2c233978f45f37b928ca1daeb16f',22848,1642344287,1642344287),(101,0,1658668023,0,0,1,'1',0,'/form_definitions/emails/voucher_Plaintext.html','cad29742ba6c3396644039eebfb2a61d9b58b2fb','803db7e6f0fdbd7b26f6105c0cd02e15c14e9f29','html','text/html','voucher_Plaintext.html','084c23d84a5accc7d559e2c6e246b49f04cd63a1',1712,1658667949,1658667949),(110,0,1667121975,0,0,0,'2',0,'/typo3conf/ext/favicon/Resources/Public/Icons/Extension.png','2a11b604b7f36243469d95c225d7ca09033384e2','d834b898cbb4b9c9be7812a50c0aee7aafe06832','png','image/png','Extension.png','61b97166a62b1638c489ec02f2ecd33756b191b8',10160,1662534349,1638784693),(114,0,1679820308,0,0,1,'2',0,'/user_upload/bg/rainbow-vortex.svg','266472da28a8fb1aebc27342bd245503458ad4b8','77461e349bd1a778aff63a4f8603b4eea691eee5','svg','image/svg+xml','rainbow-vortex.svg','9830dbdc09114af9f0ce16dd3a7cdb6a3b2ef229',1063,1679746821,1678444624),(119,0,1679823005,0,0,1,'2',0,'/user_upload/gallery/20200904.jpg','c77b5b57c9f7906b56a834e6f24fd79cd8a1cb72','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20200904.jpg','cfaa7238405f4ad167fc0129e86eb178ff532016',277573,1679823005,1679821529),(120,0,1679823015,0,0,1,'2',0,'/user_upload/gallery/20190721.jpg','1a075e3cf7ead3098dd6a1a33976773820e5450c','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20190721.jpg','4ba1fc4d1734f28c3fdc4d4df8cece1f4f292644',382812,1679823015,1679821529),(123,0,1679822992,0,0,1,'2',0,'/user_upload/gallery/20221216.jpg','c3c783be375a3c152a5d4a7397ba80c5dcac3514','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20221216.jpg','7504bcf9338bd71e2425fe6d6b18be2be9c7561c',438310,1679822992,1679821529),(125,0,1679822974,0,0,1,'2',0,'/user_upload/gallery/20221029.jpg','c3407df36fa390dd7b343a9c81e2744660929843','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20221029.jpg','f49c3c6c1cb66386c6527661b76c80047d0dea52',849099,1679822974,1679821529),(128,0,1679823037,0,0,1,'2',0,'/user_upload/gallery/0101.jpg','99e99154dde229869c1cdecdfed8664091aca3f6','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','0101.jpg','850d0495b08cee17183c55d591b7e4a4ab5de371',560528,1679823037,1678612743),(130,0,1679823055,0,0,1,'2',0,'/user_upload/gallery/20180501.jpg','b3e02df0f9c2cae5aa2a0d7bda585585d90d0ed4','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20180501.jpg','e0daa8a670a43462aeb2bf38970a55ba3d3fbe8d',229412,1679823054,1679821529),(134,0,1679823066,0,0,1,'2',0,'/user_upload/gallery/20170823.jpg','82791449b2dc2229b681cfecacc264aaf931abbb','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20170823.jpg','03dc979559f32f3c9910f346d820a3f5794fb972',330966,1679823066,1679821529),(135,0,1679823078,0,0,1,'2',0,'/user_upload/gallery/20170728.jpg','0f55ba1c6ab095fbb984a6751e6a8af676726395','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20170728.jpg','61733e05cb0ad3bf9c063b01cad48e839d682e13',334898,1679823078,1679821528),(136,0,1679823090,0,0,1,'2',0,'/user_upload/gallery/20170714.jpg','df9357e4a0c0db41b493300f9f677f12d01734b2','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20170714.jpg','c3e85b4c2a680ca8cfc89b5834c63d7e2313fcc7',491756,1679823090,1679821528),(141,0,1679823639,0,0,1,'2',0,'/user_upload/content/a3822210348.jpg','049d29039387d08301960a5b701974047a4f0810','a5fd4827bb8bc1413fbc5bd229aa5341605e28fb','jpg','image/jpeg','a3822210348.jpg','0b61b63d12412eb3d1d482905d96caa082738a05',413487,1679823639,1679823617),(142,0,1705294917,1705294917,0,1,'4',0,'/user_upload/videos/VisionVersion__Why___These_Few_Presidents_.youtube','2d529107da41f47c781f2bf8d4d9ab5509e5fc2e','f05a21365c4a2f25a46d9ee7628fa779ede128fc','youtube','video/youtube','VisionVersion__Why___These_Few_Presidents_.youtube','5b99ebba9e9a48405e99fddf56e8395fcf5d1db0',11,1705294917,1704807937),(148,0,1679393492,0,0,1,'1',0,'/user_upload/user_upload/_temp_/importexport/.htaccess','af872ce5a33388a520dd41447cf7a53027b8763a','0b424920f998855ea7209e85f5329d9e6b894b29','htaccess','text/plain','.htaccess','88d1ddbb5d89f89d8c7c859f10f9c328acd9b1cf',372,1658686725,1639832671),(149,0,1679394204,0,0,1,'1',0,'/form_definitions/contact-6419859c5ebc18.73862340.form.yaml.deleted','803216dd859b1988e91168881a8084cd5d7fbdbe','c62e3e70a526a59f0f0b7687864947eab72d7d3f','deleted','text/plain','contact-6419859c5ebc18.73862340.form.yaml.deleted','96760a9d17c2c3833a0214ad45fcbf0c1d1c41e0',2010,1679394204,1679394204),(150,0,1679394323,0,0,1,'1',0,'/form_definitions/testVouchers-64198613a79748.51076883.form.yaml.deleted','1ab7771aa530a68be92253cbdc0f927b90141b23','c62e3e70a526a59f0f0b7687864947eab72d7d3f','deleted','text/plain','testVouchers-64198613a79748.51076883.form.yaml.deleted','d1b33b9663e87f7c4f66aec1539f7918072dae7b',1479,1679394323,1679394323),(151,0,1679394327,0,0,1,'1',0,'/form_definitions/testFormtoPDF-64198617aee0f7.59668425.form.yaml.deleted','ed1b2a35d960b9275909f8dcb65799bb272ec19d','c62e3e70a526a59f0f0b7687864947eab72d7d3f','deleted','text/plain','testFormtoPDF-64198617aee0f7.59668425.form.yaml.deleted','dcebdf1ab67d187d3e68fce8576d9a911b20bd5d',1176,1679394327,1679394327),(152,0,1679394340,0,0,1,'1',0,'/form_definitions/exampleForm-64198624c53938.97863058.form.yaml.deleted','27cdf066326689518bca39097d6894fcb985240c','c62e3e70a526a59f0f0b7687864947eab72d7d3f','deleted','text/plain','exampleForm-64198624c53938.97863058.form.yaml.deleted','3cc3e0858d6709ac3bc51b58f62de0d5ce740ae9',2877,1679394340,1679394340),(153,0,1679751450,0,0,0,'2',0,'/_assets/cde4951fa6e7de365908c2d0c98cbd49/Icons/Extension.png','f8fc58353945fab2344e3509b82304a3aaf7340b','8124ec2b0f30fdc1220fdcc3250a433df1151aef','png','image/png','Extension.png','cf0ddad4ae5378b12bdcb6a8ac32c860e60e19d6',2448,1679732862,1674517891),(155,0,1705919658,1705919658,0,1,'1',0,'/form_definitions/contact_us.form.yaml','76622669dfb7d96a8145f5d35bd491afa86c1631','c62e3e70a526a59f0f0b7687864947eab72d7d3f','yaml','text/plain','contact_us.form.yaml','0d2df1c077f30a60e84a58abcaa8d55c8687a0fd',3496,1705919658,1705919658),(156,0,1679823495,0,0,1,'2',0,'/user_upload/persons/meri_.jpg','7b3cc4ca14e78923c4820a66222220a6b22fb64f','3d43b9840044b5156cff303a1b06302bd6f6a36e','jpg','image/jpeg','meri_.jpg','e04798ad281fbefe9487983358c96964f0c29462',280302,1679823495,1679823208),(157,0,1679823260,0,0,1,'2',0,'/user_upload/persons/Obama.jpg','540af462614eef77352d6cf6e5c59950fd474cfa','3d43b9840044b5156cff303a1b06302bd6f6a36e','jpg','image/jpeg','Obama.jpg','01614a09a7615af8dfd9d5040c1efb0aecda8dd9',255391,1679823208,1679823208),(158,0,1679823374,0,0,1,'2',0,'/user_upload/persons/tsai_.jpg','9d89ae26851dc401d8ccb6ca1053e084cedbb463','3d43b9840044b5156cff303a1b06302bd6f6a36e','jpg','image/jpeg','tsai_.jpg','f5bfdb0bc54683eaa2ccaf0d4d3d8c6fa117d019',167788,1679823367,1679823367),(160,0,1679823622,0,0,1,'2',0,'/user_upload/content/speed.jpg','a7b2286a99ad9b58cfa06c35086ef6647d62d2c1','a5fd4827bb8bc1413fbc5bd229aa5341605e28fb','jpg','image/jpeg','speed.jpg','7a94a912b8e817f9fc068ccdeb871cd6c46976c6',216245,1679823617,1679823617),(162,0,1705294864,1705294864,0,1,'4',0,'/user_upload/videos/Windsurf_-_Hardcore.vimeo','9bbdac19003435dd826ee552e428f11a3b0553c3','f05a21365c4a2f25a46d9ee7628fa779ede128fc','vimeo','video/vimeo','Windsurf_-_Hardcore.vimeo','da410b3f1fdcb74896b5fdddfdd5b755b5dc9178',9,1705294864,1704807937),(163,0,1701863363,1701863363,0,0,'2',0,'/typo3temp/assets/online_media/vimeo_cea34da3337fa12f6caff318115f1e12.jpg','5ba383b450841d5d94221406818ed6dd895215b1','4cc752e47a34a774308932666b4f77c095218aab','jpg','image/jpeg','vimeo_cea34da3337fa12f6caff318115f1e12.jpg','13fcd5b8cc9eb4991e4f4923d111d9f93c4e549e',40131,1701863297,1701863297);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (2,0,1679820308,1546915254,0,0,NULL,0,'',0,0,0,0,2,NULL,1920,1080,NULL,NULL,0),(4,0,1546918619,1546918618,0,0,NULL,0,'',0,0,0,0,4,NULL,1,1,NULL,NULL,0),(5,0,1679823273,1546922224,0,0,NULL,0,'',0,0,0,0,5,NULL,1400,1084,NULL,NULL,0),(8,0,1679820326,1546994332,0,0,NULL,0,'',0,0,0,0,8,NULL,150,150,NULL,NULL,0),(10,0,1547775392,1547775391,0,0,NULL,0,'',0,0,0,0,10,NULL,128,128,NULL,NULL,0),(13,0,1679820318,1548056315,0,0,NULL,0,'',0,0,0,0,13,NULL,150,150,NULL,NULL,0),(16,0,1679747678,1559996683,0,0,NULL,0,'',0,0,0,0,16,NULL,0,0,NULL,NULL,0),(21,0,1568973233,1568973233,0,0,NULL,0,'',0,0,0,0,21,NULL,23,19,NULL,NULL,0),(22,0,1568973288,1568973288,0,0,NULL,0,'',0,0,0,0,22,NULL,23,19,NULL,NULL,0),(29,0,1569484601,1569484600,0,0,NULL,0,'',0,0,0,0,29,NULL,0,0,NULL,NULL,0),(30,0,1569484724,1569484724,0,0,NULL,0,'',0,0,0,0,30,NULL,0,0,NULL,NULL,0),(31,0,1569484753,1569484753,0,0,NULL,0,'',0,0,0,0,31,NULL,0,0,NULL,NULL,0),(32,0,1569490843,1569490842,0,0,NULL,0,'',0,0,0,0,32,NULL,0,0,NULL,NULL,0),(33,0,1569490861,1569490861,0,0,NULL,0,'',0,0,0,0,33,NULL,0,0,NULL,NULL,0),(34,0,1642087033,1569493071,0,0,NULL,0,'',0,0,0,0,34,NULL,0,0,NULL,NULL,0),(35,0,1642087033,1569493071,0,0,NULL,0,'',0,0,0,0,35,NULL,0,0,NULL,NULL,0),(39,0,1638523729,1638523729,0,0,NULL,0,'',0,0,0,0,39,NULL,1280,720,NULL,NULL,0),(40,0,1638529922,1638529922,0,0,NULL,0,'',0,0,0,0,40,NULL,512,512,NULL,NULL,0),(41,0,1679820704,1638776307,0,0,NULL,0,'',0,0,0,0,41,'The Claypool Lennon Delirium - Blood and Rockets (Live at The Current)',2048,1152,NULL,NULL,0),(42,0,1638776310,1638776310,0,0,NULL,0,'',0,0,0,0,42,NULL,320,180,NULL,NULL,0),(46,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,46,NULL,595,842,NULL,NULL,0),(47,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,47,NULL,595,842,NULL,NULL,0),(48,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,48,NULL,595,842,NULL,NULL,0),(49,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,49,NULL,595,842,NULL,NULL,0),(50,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,50,NULL,595,842,NULL,NULL,0),(51,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,51,NULL,595,842,NULL,NULL,0),(52,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,52,NULL,595,842,NULL,NULL,0),(53,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,53,NULL,595,842,NULL,NULL,0),(54,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,54,NULL,595,842,NULL,NULL,0),(74,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,74,NULL,0,0,NULL,NULL,0),(81,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,81,NULL,0,0,NULL,NULL,0),(82,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,82,NULL,0,0,NULL,NULL,0),(83,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,83,NULL,0,0,NULL,NULL,0),(84,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,84,NULL,0,0,NULL,NULL,0),(85,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,85,NULL,0,0,NULL,NULL,0),(86,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,86,NULL,0,0,NULL,NULL,0),(92,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,92,NULL,4812,3208,NULL,NULL,0),(93,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,93,NULL,0,0,NULL,NULL,0),(95,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,95,'The Knife - A Tooth For An Eye - Official video',200,113,NULL,NULL,0),(97,0,1642344306,1642344306,0,0,NULL,0,'',0,0,0,0,97,NULL,0,0,NULL,NULL,0),(101,0,1658668023,1658668023,0,0,NULL,0,'',0,0,0,0,101,NULL,0,0,NULL,NULL,0),(110,0,1667121975,1667121975,0,0,NULL,0,'',0,0,0,0,110,NULL,512,512,NULL,NULL,0),(114,0,1679820308,1678444624,0,0,NULL,0,'',0,0,0,0,114,NULL,100,100,NULL,NULL,0),(119,0,1679823005,1678612658,0,0,NULL,0,'',0,0,0,0,119,NULL,1400,1050,NULL,NULL,0),(120,0,1679823015,1678612660,0,0,NULL,0,'',0,0,0,0,120,NULL,1400,1050,NULL,NULL,0),(123,0,1679822992,1678612672,0,0,NULL,0,'',0,0,0,0,123,NULL,1050,1400,NULL,NULL,0),(125,0,1679822974,1678612678,0,0,NULL,0,'{\"alternative\":\"\",\"description\":\"\",\"title\":\"\",\"sys_language_uid\":\"\",\"categories\":\"\"}',0,0,0,0,125,NULL,1050,1400,NULL,NULL,0),(128,0,1679823037,1678612743,0,0,NULL,0,'',0,0,0,0,128,NULL,2592,1936,NULL,NULL,0),(130,0,1679823055,1678612748,0,0,NULL,0,'',0,0,0,0,130,NULL,1400,1050,NULL,NULL,0),(134,0,1679823066,1678612757,0,0,NULL,0,'',0,0,0,0,134,NULL,1400,1050,NULL,NULL,0),(135,0,1679823078,1678612761,0,0,NULL,0,'',0,0,0,0,135,NULL,1400,1050,NULL,NULL,0),(136,0,1679823090,1678612761,0,0,NULL,0,'',0,0,0,0,136,NULL,1400,1050,NULL,NULL,0),(141,0,1679823639,1679055637,0,0,NULL,0,'',0,0,0,0,141,NULL,1400,1400,NULL,NULL,0),(142,0,1679820718,1679055662,0,0,NULL,0,'',0,0,0,0,142,'VisionVersion: Why? \"These Few Presidents\"',2048,1152,NULL,NULL,0),(148,0,1679393492,1679393492,0,0,NULL,0,'',0,0,0,0,148,NULL,0,0,NULL,NULL,0),(149,0,1679394204,1679394204,0,0,NULL,0,'',0,0,0,0,149,NULL,0,0,NULL,NULL,0),(150,0,1679394323,1679394323,0,0,NULL,0,'',0,0,0,0,150,NULL,0,0,NULL,NULL,0),(151,0,1679394327,1679394327,0,0,NULL,0,'',0,0,0,0,151,NULL,0,0,NULL,NULL,0),(152,0,1679394340,1679394340,0,0,NULL,0,'',0,0,0,0,152,NULL,0,0,NULL,NULL,0),(153,0,1679751448,1679751448,0,0,NULL,0,'',0,0,0,0,153,NULL,512,512,NULL,NULL,0),(155,0,1679821045,1679820997,0,0,NULL,0,'',0,0,0,0,155,NULL,0,0,NULL,NULL,0),(156,0,1679823495,1679821324,0,0,NULL,0,'',0,0,0,0,156,NULL,1120,1400,NULL,NULL,0),(157,0,1679823260,1679823256,0,0,NULL,0,'',0,0,0,0,157,NULL,1400,1084,NULL,NULL,0),(158,0,1679823374,1679823374,0,0,NULL,0,'',0,0,0,0,158,NULL,1168,1400,NULL,NULL,0),(160,0,1679823621,1679823621,0,0,NULL,0,'',0,0,0,0,160,NULL,1400,768,NULL,NULL,0),(162,0,1701863294,1701863294,0,0,NULL,0,'',0,0,0,0,162,'Windsurf - Hardcore',2048,1152,NULL,NULL,0),(163,0,1701863363,1701863363,0,0,NULL,0,'',0,0,0,0,163,NULL,1280,720,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  `processing_url` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=4731 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES (4723,1706086438,1706086438,1,120,'/_processed_/6/d/csm_20190721_a611656c4c.jpg','csm_20190721_a611656c4c.jpg','a:3:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:-1.4000000000000001;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:1400;s:9:\"\0*\0height\";d:1050;}}','63592a48a53ce59f2ec21385da98f82986460e7c','4ba1fc4d1734f28c3fdc4d4df8cece1f4f292644','Image.CropScaleMask','a611656c4c',64,48,''),(4724,1706086438,1706086438,1,128,'/_processed_/f/9/preview_0101_6f3439bf2c.jpg','preview_0101_6f3439bf2c.jpg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','850d0495b08cee17183c55d591b7e4a4ab5de371','Image.Preview','6f3439bf2c',64,48,''),(4725,1706086438,1706086438,1,119,'/_processed_/9/7/preview_20200904_9e7e7d3067.jpg','preview_20200904_9e7e7d3067.jpg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','cfaa7238405f4ad167fc0129e86eb178ff532016','Image.Preview','9e7e7d3067',64,48,''),(4726,1706086438,1706086438,1,130,'/_processed_/2/d/preview_20180501_88f219d275.jpg','preview_20180501_88f219d275.jpg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','e0daa8a670a43462aeb2bf38970a55ba3d3fbe8d','Image.Preview','88f219d275',64,48,''),(4727,1706086438,1706086438,1,125,'/_processed_/2/1/preview_20221029_61bc5bee04.jpg','preview_20221029_61bc5bee04.jpg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','f49c3c6c1cb66386c6527661b76c80047d0dea52','Image.Preview','61bc5bee04',48,64,''),(4728,1706086438,1706086438,1,123,'/_processed_/f/4/csm_20221216_9a4aa5250e.jpg','csm_20221216_9a4aa5250e.jpg','a:3:{s:8:\"maxWidth\";i:64;s:9:\"maxHeight\";i:64;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:492.79999999999995;s:8:\"\0*\0width\";d:1048.6000000000001;s:9:\"\0*\0height\";d:590.8;}}','76004f7a84e879989fdc0c86110e9dae4b8fe9bf','7504bcf9338bd71e2425fe6d6b18be2be9c7561c','Image.CropScaleMask','9a4aa5250e',64,36,''),(4729,1706086438,1706086438,1,136,'/_processed_/3/c/preview_20170714_56a4fe7ded.jpg','preview_20170714_56a4fe7ded.jpg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','c3e85b4c2a680ca8cfc89b5834c63d7e2313fcc7','Image.Preview','56a4fe7ded',64,48,''),(4730,1706086438,1706086438,1,134,'/_processed_/f/d/preview_20170823_107afabd03.jpg','preview_20170823_107afabd03.jpg','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','03dc979559f32f3c9910f346d820a3f5794fb972','Image.Preview','107afabd03',64,48,'');
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `crop` varchar(4000) NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  `tx_youtubevideo_autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_youtubevideo_rel` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_youtubevideo_starttime` varchar(10) DEFAULT NULL,
  `tx_youtubevideo_endtime` varchar(10) DEFAULT NULL,
  `tx_youtubevideo_ratio` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_youtubevideo_fullscreen` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_youtubevideo_loop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_youtubevideo_mute` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_youtubevideo_coverimage` int(11) NOT NULL DEFAULT 0,
  `tx_vimeovideo_starttime` varchar(10) DEFAULT NULL,
  `tx_vimeovideo_endtime` varchar(10) DEFAULT NULL,
  `tx_vimeovideo_ratio` varchar(10) DEFAULT NULL,
  `tx_vimeovideo_loop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_vimeovideo_mute` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_vimeovideo_coverimage` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=244 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES (5,6,1678817249,1546922491,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,5,3,'tx_personnel_domain_model_person','images',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":0.875968992248062,\"width\":0.678,\"x\":0.159,\"y\":0.03359173126614987},\"selectedRatio\":\"1:1\",\"focusArea\":null}}',0,0,0,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,0,0,0),(6,1,1546994336,1546994336,0,0,0,0,NULL,'',0,0,0,0,8,1,'pages','favicon',1,NULL,NULL,NULL,'','',0,0,0,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,0,0,0),(16,1,1638206748,1551408917,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,13,1,'pages','tx_favicon_favicon',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0,0,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,0,0,0),(76,1,1638523616,1637190395,0,1,0,0,NULL,'a:4:{s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,2,16,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0,0,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,0,0,0),(155,1,1679829793,1678444642,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,114,1,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(184,1,1679749915,1678612875,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,119,158,'tt_content','assets',3,NULL,NULL,'Straight Summer road','','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"x\":0,\"y\":0.125,\"width\":1,\"height\":0.75},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2210599721059972,\"width\":1,\"height\":0.5578800557880056},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21875,\"y\":0,\"width\":0.5625,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.323,\"y\":0.20185185185185184,\"width\":0.323,\"height\":0.7656296296296297},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.33,\"y\":0.0012866666666666417,\"width\":0.313,\"height\":0.9974266666666667},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(188,1,1679749915,1678612875,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,130,158,'tt_content','assets',4,NULL,NULL,'Road on a dam','','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"x\":0,\"y\":0.125,\"width\":1,\"height\":0.75},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2210599721059972,\"width\":1,\"height\":0.5578800557880056},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21875,\"y\":0,\"width\":0.5625,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.325,\"y\":0.1614814814814815,\"width\":0.289,\"height\":0.6850370370370369},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.37304811715481173,\"y\":0.042666666666666665,\"width\":0.2569037656903766,\"height\":0.8186666666666668},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(189,1,1679749915,1678612875,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,128,158,'tt_content','assets',2,NULL,NULL,'Winter road','','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0.002057613168724338,\"y\":0,\"width\":0.9958847736625513,\"height\":1},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"x\":0,\"y\":0.1234504132231405,\"width\":1,\"height\":0.753099173553719},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.21990732736263355,\"width\":1,\"height\":0.5601853452747328},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.12654320987654322,\"y\":0,\"width\":0.7469135802469136,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21990740740740758,\"y\":0,\"width\":0.5601851851851852,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.25108273836085077,\"y\":0.13788487282463185,\"width\":0.3498345232782984,\"height\":0.8326639892904953},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.365,\"y\":0.20739365583546301,\"width\":0.23100000000000004,\"height\":0.7391618181818184},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(193,5,1679397244,1678805035,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,135,5,'pages','tx_pagelist_images',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":0.7493333333333333,\"width\":0.999,\"x\":0,\"y\":0.23066666666666666},\"selectedRatio\":\"16:9\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(199,1,1701863399,1679055709,0,0,0,0,NULL,'{\"title\":\"\",\"description\":\"\",\"tx_youtubevideo_mute\":\"\",\"tx_youtubevideo_loop\":\"\",\"tx_youtubevideo_fullscreen\":\"\",\"tx_youtubevideo_rel\":\"\",\"tx_youtubevideo_starttime\":\"\",\"tx_youtubevideo_endtime\":\"\",\"tx_youtubevideo_ratio\":\"\",\"tx_youtubevideo_coverimage\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,142,16,'tt_content','tx_youtubevideo_assets',1,NULL,NULL,NULL,'','',0,0,1,'','',0,1,0,0,1,NULL,NULL,NULL,0,0,0),(200,1,1701863399,1679055709,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,141,199,'sys_file_reference','tx_youtubevideo_coverimage',1,NULL,NULL,NULL,'','{\"widescreen\":{\"cropArea\":{\"x\":0.1493333333333333,\"y\":0.034,\"width\":0.6933333333333334,\"height\":0.39},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0.125,\"width\":1,\"height\":0.75},\"selectedRatio\":\"4:3\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(203,5,1705734791,1679229170,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,125,163,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0.21875,\"width\":1,\"height\":0.5625},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"height\":0.421,\"width\":1,\"x\":0,\"y\":0.311},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.3430962343096235,\"width\":1,\"height\":0.3138075313807531},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0,\"y\":0.125,\"width\":1,\"height\":0.75},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.22105997210599734,\"y\":0,\"width\":0.5578800557880056,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(204,5,1705734791,1679229170,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,123,163,'tt_content','assets',2,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0.3523437499999999,\"width\":0.9986666666666668,\"height\":0.4213125000000001},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0.21875,\"width\":1,\"height\":0.5625},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"x\":0.0010370370370371045,\"y\":0.475,\"width\":0.9979259259259258,\"height\":0.421},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.3430962343096235,\"width\":1,\"height\":0.3138075313807531},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0,\"y\":0.25,\"width\":1,\"height\":0.75},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.22105997210599748,\"y\":0,\"width\":0.5578800557880056,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(205,5,1705734791,1679229170,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,136,163,'tt_content','assets',3,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"height\":0.6173333333333333,\"width\":0.823,\"x\":0.017,\"y\":0},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2210599721059972,\"width\":1,\"height\":0.5578800557880056},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21875,\"y\":0,\"width\":0.5625,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.2890625,\"y\":0,\"width\":0.421875,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.34309623430962344,\"y\":0,\"width\":0.3138075313807531,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(206,5,1705734791,1679229170,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,134,163,'tt_content','assets',4,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"height\":0.7493333333333333,\"width\":1,\"x\":0,\"y\":0.20933333333333334},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2210599721059972,\"width\":1,\"height\":0.5578800557880056},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21875,\"y\":0,\"width\":0.5625,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.2890625,\"y\":0,\"width\":0.421875,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.34309623430962344,\"y\":0,\"width\":0.3138075313807531,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(211,7,1679388709,1679337505,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,134,7,'pages','tx_pagelist_images',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":0.5946666666666667,\"width\":0.794,\"x\":0.205,\"y\":0.36133333333333334},\"selectedRatio\":\"16:9\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(214,1,1679749915,1679605882,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,120,158,'tt_content','assets',1,NULL,NULL,'Summer road','','{\"default\":{\"cropArea\":{\"x\":-0.001,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0.00022036139268400177,\"width\":1,\"height\":0.999559277214632},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"x\":7.5189707487841285e-17,\"y\":0.125165271044513,\"width\":0.99999999999999989,\"height\":0.74966945791097395},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2211829073320413,\"width\":1,\"height\":0.55763418533591735},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.12483465608465609,\"y\":0,\"width\":0.75033068783068779,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.121,\"y\":0.0094966945791097011,\"width\":0.41700000000000004,\"height\":0.74100661084178054},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.14699999999999999,\"y\":0.0006011458792419712,\"width\":0.29999999999999999,\"height\":0.71079770824151611},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.34302705275508621,\"y\":0,\"width\":0.31394589448982757,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(217,6,1679821425,1679821407,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,156,2,'tx_personnel_domain_model_person','images',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0.0074999999999999989,\"y\":0.01402984429065744,\"width\":0.94874999999999998,\"height\":0.75894031141868512},\"selectedRatio\":\"1:1\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(218,6,1705569587,1679823471,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,158,7,'tx_personnel_domain_model_person','images',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0.0001712328767123677,\"y\":0.003,\"width\":0.9996575342465752,\"height\":0.834},\"selectedRatio\":\"1:1\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(219,2,1679823717,1679823717,0,0,0,0,NULL,'',0,0,0,0,160,267,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0.13428571428571429,\"y\":0,\"width\":0.73142857142857143,\"height\":1},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"x\":0.012380952380952407,\"y\":0,\"width\":0.97523809523809524,\"height\":1},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.11863668061366806,\"width\":1,\"height\":0.76272663877266389},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.2257142857142857,\"y\":0,\"width\":0.5485714285714286,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.29428571428571426,\"y\":0,\"width\":0.41142857142857142,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.3457142857142857,\"y\":0,\"width\":0.30857142857142855,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.38523610280932458,\"y\":0,\"width\":0.22952779438135085,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(220,1,1701863373,1701863361,0,0,0,0,NULL,'{\"title\":\"\",\"description\":\"\",\"tx_vimeovideo_mute\":\"\",\"tx_vimeovideo_loop\":\"\",\"tx_vimeovideo_starttime\":\"\",\"tx_vimeovideo_endtime\":\"\",\"tx_vimeovideo_ratio\":\"\",\"tx_vimeovideo_coverimage\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,162,333,'tt_content','tx_vimeovideo_assets',1,NULL,NULL,NULL,'','',0,0,1,NULL,NULL,0,1,0,0,0,'','','0',0,0,0),(221,5,1706005844,1704810384,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,125,337,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0.21875,\"width\":1,\"height\":0.5625},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"height\":0.421,\"width\":1,\"x\":0,\"y\":0.311},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.3430962343096235,\"width\":1,\"height\":0.3138075313807531},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0,\"y\":0.125,\"width\":1,\"height\":0.75},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.22105997210599734,\"y\":0,\"width\":0.5578800557880056,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,'','',0,1,0,0,0,'','','',0,0,0),(222,5,1706005844,1704810384,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,123,337,'tt_content','assets',2,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0.3523437499999999,\"width\":0.9986666666666668,\"height\":0.4213125000000001},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0.21875,\"width\":1,\"height\":0.5625},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"x\":0.0010370370370371045,\"y\":0.475,\"width\":0.9979259259259258,\"height\":0.421},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.3430962343096235,\"width\":1,\"height\":0.3138075313807531},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0,\"y\":0.25,\"width\":1,\"height\":0.75},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.22105997210599748,\"y\":0,\"width\":0.5578800557880056,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,'','',0,1,0,0,0,'','','',0,0,0),(223,5,1706005844,1704810384,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,136,337,'tt_content','assets',3,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"height\":0.6173333333333333,\"width\":0.823,\"x\":0.017,\"y\":0},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2210599721059972,\"width\":1,\"height\":0.5578800557880056},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21875,\"y\":0,\"width\":0.5625,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.2890625,\"y\":0,\"width\":0.421875,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.34309623430962344,\"y\":0,\"width\":0.3138075313807531,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,'','',0,1,0,0,0,'','','',0,0,0),(224,5,1706005844,1704810384,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,134,337,'tt_content','assets',4,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"height\":0.7493333333333333,\"width\":1,\"x\":0,\"y\":0.20933333333333334},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2210599721059972,\"width\":1,\"height\":0.5578800557880056},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21875,\"y\":0,\"width\":0.5625,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.2890625,\"y\":0,\"width\":0.421875,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.34309623430962344,\"y\":0,\"width\":0.3138075313807531,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,'','',0,1,0,0,0,'','','',0,0,0),(235,5,1705049556,1704829893,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,41,355,'tt_content','tx_youtubevideo_assets',1,NULL,NULL,NULL,'','',0,0,1,'','',0,1,0,0,0,NULL,NULL,NULL,0,0,0),(236,5,1706006547,1705044488,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,135,357,'tt_content','media',1,'First file in the list','Description to the file goes here. Let\'s always show the download file name for security reasons.',NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(237,5,1706006547,1705044488,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,120,357,'tt_content','media',2,'Second file in the list','Description to the second file goes here. Let\'s make it longer for testing purposes. And see what happens if it\'s on more than few lines.',NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(238,5,1706006547,1705044488,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,119,357,'tt_content','media',3,'Third and last file has no description',NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(239,1,1705917244,1705386262,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,125,374,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0.21875,\"width\":1,\"height\":0.5625},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"height\":0.421,\"width\":1,\"x\":0,\"y\":0.311},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.3430962343096235,\"width\":1,\"height\":0.3138075313807531},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0,\"y\":0.125,\"width\":1,\"height\":0.75},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.22105997210599734,\"y\":0,\"width\":0.5578800557880056,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,'','',0,1,0,0,0,'','','',0,0,0),(240,1,1705917244,1705386262,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,123,374,'tt_content','assets',2,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":0.422,\"width\":0.9986666666666667,\"x\":0,\"y\":0.352},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0.21875,\"width\":1,\"height\":0.5625},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"x\":0.0010370370370371045,\"y\":0.475,\"width\":0.9979259259259258,\"height\":0.421},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.3430962343096235,\"width\":1,\"height\":0.3138075313807531},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"height\":0.75,\"width\":1,\"x\":0,\"y\":0.25},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.22105997210599748,\"y\":0,\"width\":0.5578800557880056,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,'','',0,1,0,0,0,'','','',0,0,0),(241,1,1705917244,1705386262,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,136,374,'tt_content','assets',3,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"height\":0.6173333333333333,\"width\":0.823,\"x\":0.017,\"y\":0},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2210599721059972,\"width\":1,\"height\":0.5578800557880056},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21875,\"y\":0,\"width\":0.5625,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.2890625,\"y\":0,\"width\":0.421875,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.34309623430962344,\"y\":0,\"width\":0.3138075313807531,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,'','',0,1,0,0,0,'','','',0,0,0),(242,1,1705917244,1705386262,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,134,374,'tt_content','assets',4,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"height\":0.7493333333333333,\"width\":1,\"x\":0,\"y\":0.20933333333333334},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2210599721059972,\"width\":1,\"height\":0.5578800557880056},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21875,\"y\":0,\"width\":0.5625,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.2890625,\"y\":0,\"width\":0.421875,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.34309623430962344,\"y\":0,\"width\":0.3138075313807531,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,'','',0,1,0,0,0,'','','',0,0,0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `driver` tinytext DEFAULT NULL,
  `configuration` text DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1658667601,1546914447,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin/ (auto-created)','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"baseUri\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
INSERT INTO `sys_filemounts` VALUES (1,0,1639988930,0,0,256,'','Files',0,'1:/user_upload/');
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(32) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) NOT NULL DEFAULT '',
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `parent` (`pid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `channel` (`channel`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `message` text DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`fields`)),
  `identifier` varchar(36) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) NOT NULL DEFAULT '',
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('00b3a6ec0f73f00c701e03aa22b75f38','sys_file_reference',238,'uid_local','','','',0,0,'sys_file',119,''),('014e9145ac19ccb2a7ad062ef959c504','sys_file',30,'metadata','','','',0,0,'sys_file_metadata',30,''),('02ff87103c05ddc5c3100f854fe9623f','sys_file',85,'storage','','','',0,0,'sys_file_storage',1,''),('03130f0d682948d2bbbb9176bd3cc867','sys_file',50,'storage','','','',0,0,'sys_file_storage',1,''),('03e4764a35c3b1f131a1a0c7c66e994e','sys_file',50,'metadata','','','',0,0,'sys_file_metadata',50,''),('03e925867c5ac09b11c9c5094df32965','sys_file',35,'storage','','','',0,0,'sys_file_storage',1,''),('04409d20f4d0d02388fcdecf01e91a80','sys_file_metadata',52,'file','','','',0,0,'sys_file',52,''),('0531758ecc221acdfbda084f47657389','tt_content',13,'bodytext','','typolink_tag','1',-1,0,'pages',1,''),('05540ce6915ad9371e39267d1338e54a','tt_content',337,'assets','','','',2,0,'sys_file_reference',223,''),('05d5e7de5f4f21df4b07936b474782f4','tx_personnel_domain_model_person',7,'email','','email','2',-1,0,'_STRING',0,'example@domain.com'),('06fbbd1bcf2d9d01e4d9cc1d267de19b','sys_file_metadata',128,'file','','','',0,0,'sys_file',128,''),('076efd2605c2d2fb5b1db21cc8c30ecb','sys_file',123,'metadata','','','',0,0,'sys_file_metadata',123,''),('0777a44368e3ba8649661f93fbf61e1d','sys_file',162,'metadata','','','',0,0,'sys_file_metadata',162,''),('0826c19097811ebecc3c9cc744ad9ba6','sys_file',142,'metadata','','','',0,0,'sys_file_metadata',142,''),('0870bb4b83e18a7142d1b8a4b2c69694','sys_file_metadata',95,'file','','','',0,0,'sys_file',95,''),('09dad6e5106c71255fd539e47fe0fd47','sys_file',46,'storage','','','',0,0,'sys_file_storage',1,''),('0ae53cefd9d1768f05cec38e8de18e28','tt_content',323,'tx_container_parent','','','',0,0,'tt_content',166,''),('0be16d2414942c028029834b29d87f10','tt_content',309,'bodytext','','typolink_tag','1',-1,0,'pages',2,''),('0c209a7f09de10dbe5cc78aaa5ab1a42','sys_file_reference',189,'uid_local','','','',0,0,'sys_file',128,''),('0c3e754852083f9c591f9ebcee29a1cc','tt_content',19,'tx_container_parent','','','',0,0,'tt_content',6,''),('0db7a2a66608ac6f928d430902e5da0b','tt_content',368,'tx_container_parent','','','',0,0,'tt_content',367,''),('0fff0d1dedbea94bd37f4a0e7aaf713c','sys_file_reference',155,'uid_local','','','',0,0,'sys_file',114,''),('12d585212e2cc7408ae67d19390414cf','sys_file',95,'storage','','','',0,0,'sys_file_storage',1,''),('131e66eb58321eda7d8b00ced59268e4','sys_file_metadata',33,'file','','','',0,0,'sys_file',33,''),('13c9d76de5872edc45e72172fee0ac56','sys_file',156,'metadata','','','',0,0,'sys_file_metadata',156,''),('13d8fb9941ce946dcb07df62ef011a03','sys_file',53,'metadata','','','',0,0,'sys_file_metadata',53,''),('1412c68f02343e0b35149317df7b9076','sys_file',150,'metadata','','','',0,0,'sys_file_metadata',150,''),('14ee01323df816fc7cfe3dc6258b152a','sys_file_metadata',151,'file','','','',0,0,'sys_file',151,''),('16f8a2eb03d20262089f58b9bda41d9d','tt_content',22,'tx_container_parent','','','',0,0,'tt_content',5,''),('170f0bc94eab5a80e1962a126fdd03f0','tt_content',375,'bodytext','','typolink_tag','1',-1,0,'pages',1,''),('17516f60f5789f88718c7e02377d7cc2','tt_content',159,'tx_container_parent','','','',0,0,'tt_content',157,''),('177a98741a97628dcac2d64d4a46e13f','tt_content',16,'tx_youtubevideo_assets','','','',0,0,'sys_file_reference',199,''),('18710caee73b67ab529faf648faaa8b7','pages',5,'tx_personnel_authors','','','',0,0,'tx_personnel_domain_model_person',2,''),('19d697c050a347544670168270a45c11','sys_file',158,'storage','','','',0,0,'sys_file_storage',1,''),('1c9b8784c1518ef7b22704c4fc698ca9','sys_file',2,'storage','','','',0,0,'sys_file_storage',1,''),('1d0c915ba80d50b79070fee03197459d','sys_file',31,'storage','','','',0,0,'sys_file_storage',1,''),('1d9bf3e82f9d8f8460dfb6b7074ccc16','sys_file_reference',5,'uid_local','','','',0,0,'sys_file',5,''),('1d9ea97da5cddcedae16f1420a865e08','sys_file',158,'metadata','','','',0,0,'sys_file_metadata',158,''),('1db6f423d98136650a22dd68006be1a8','sys_file_metadata',136,'file','','','',0,0,'sys_file',136,''),('1e9a821cd9a44dd45c71b5af44afeb16','tt_content',375,'bodytext','','typolink_tag','6419576af9cd705add53705b99d8f8a2:1',-1,0,'tt_content',367,''),('1efe0f915811a82b0392b70425abe6fd','sys_file',151,'metadata','','','',0,0,'sys_file_metadata',151,''),('1f14573acf90f337fff037fdc450b354','sys_file_metadata',16,'file','','','',0,0,'sys_file',16,''),('201dc1e0bfcfe2f0da28f73af08e60c0','sys_file_metadata',2,'file','','','',0,0,'sys_file',2,''),('205ee1e7af4e30938944dda3fc6a9e60','sys_file',13,'storage','','','',0,0,'sys_file_storage',1,''),('208beee30966b76498a00167dbd15d78','sys_file',41,'storage','','','',0,0,'sys_file_storage',1,''),('20d38759c5b96b98641549771e1e1f6a','sys_file',93,'metadata','','','',0,0,'sys_file_metadata',93,''),('21459982906562a9b18a79ce3cc5cb74','sys_file',95,'metadata','','','',0,0,'sys_file_metadata',95,''),('2168032d562f64d32038d6547292b3dc','sys_file',101,'metadata','','','',0,0,'sys_file_metadata',101,''),('222cbfe52b4682648b9b6610ca5475f0','tt_content',333,'tx_container_parent','','','',0,0,'tt_content',332,''),('241893c8898d82d971299feeb8f61b0c','tt_content',91,'pi_flexform','sDEF/lDEF/settings.persistenceIdentifier/vDEF/','formPersistenceIdentifier','db0d68dfa12306bf049df0d2d77291cb',-1,0,'sys_file',155,''),('2532f5f01c7068d6cd1723377a7061ed','sys_file',48,'storage','','','',0,0,'sys_file_storage',1,''),('276a3c6ddf5df9f18d7b04dfb1ef4a7a','tt_content',374,'tx_container_parent','','','',0,0,'tt_content',371,''),('27bdcffd83d4726a8bc6e6846385ef0d','sys_file_metadata',152,'file','','','',0,0,'sys_file',152,''),('29c9f1b0ae60524e5895506c9186a7a4','sys_file_metadata',29,'file','','','',0,0,'sys_file',29,''),('2afa08f370c96201a704aad33eb17159','sys_file',51,'metadata','','','',0,0,'sys_file_metadata',51,''),('2bf3d65e32ee4456030b500b1e231e06','sys_file',82,'storage','','','',0,0,'sys_file_storage',1,''),('2e063935c54c7c1a55234e2c184477c2','sys_file',92,'storage','','','',0,0,'sys_file_storage',1,''),('2f438b18ee477413a114c366c2ee6a9f','sys_file',83,'metadata','','','',0,0,'sys_file_metadata',83,''),('3050cc591591f5c18b646e1ae4cd9afa','pages',7,'tx_personnel_authors','','','',0,0,'tx_personnel_domain_model_person',3,''),('307f25cc922de5d6001ca1615bed02f1','sys_file',151,'storage','','','',0,0,'sys_file_storage',1,''),('31c68235a696e7e07d652ab86b1e681c','pages',5,'tx_pagelist_images','','','',0,0,'sys_file_reference',193,''),('33a1a89e73c3c0c666b119182676818a','tt_content',163,'assets','','','',1,0,'sys_file_reference',204,''),('342da41df314ddf0487f5ec10835cb57','tt_content',370,'tx_container_parent','','','',0,0,'tt_content',369,''),('362d9b4b950a432f129d8696975270b6','sys_file',128,'metadata','','','',0,0,'sys_file_metadata',128,''),('3795391fab50cd89c13cc42a90f9441e','tt_content',31,'tx_container_parent','','','',0,0,'tt_content',7,''),('379e19f3c05eee4d7307ef585ec8a037','sys_file',123,'storage','','','',0,0,'sys_file_storage',1,''),('37a8085704cfdb14094e519ad1eb4203','sys_file',155,'storage','','','',0,0,'sys_file_storage',1,''),('37cce10ec4e0c089a957970d06983cee','sys_file_metadata',120,'file','','','',0,0,'sys_file',120,''),('3841356c5dac2b98e45aa8b5c87f00eb','sys_file_metadata',148,'file','','','',0,0,'sys_file',148,''),('39bc2d5c23ed0417800861069836c423','sys_file',136,'storage','','','',0,0,'sys_file_storage',1,''),('39cbde01f953d2523aba16c7fa02f876','tt_content',20,'pages','','','',0,0,'pages',6,''),('39dcc71290eb7518251d53839d471007','tt_content',24,'bodytext','','typolink_tag','3',-1,0,'pages',1,''),('3b58acb25b3eed199a2b81000679bea1','tt_content',337,'tx_container_parent','','','',0,0,'tt_content',334,''),('3c04889d5e9dff80d8339dfbd508ab13','sys_file',10,'metadata','','','',0,0,'sys_file_metadata',10,''),('3d8f82df29ca366dc60c3fd2d9da2648','sys_file',141,'metadata','','','',0,0,'sys_file_metadata',141,''),('3dde8ac3c6c2dd0e26dd1e8603ed4fc1','sys_file_reference',222,'uid_local','','','',0,0,'sys_file',123,''),('3f66705547724e17d946ac9c1681ff80','sys_file_metadata',93,'file','','','',0,0,'sys_file',93,''),('40b63d8a1a0e340fe33c9bd63e1befba','sys_file',40,'metadata','','','',0,0,'sys_file_metadata',40,''),('420d6995eb9975afd0d5225a795913c6','tt_content',163,'assets','','','',0,0,'sys_file_reference',203,''),('420f713d2e66732facca13ffa8836047','tt_content',374,'tx_paginatedprocessors_anchorid','','','',0,0,'tt_content',320,''),('423625973acb1a34275fa48b74f76f78','sys_file',8,'metadata','','','',0,0,'sys_file_metadata',8,''),('431ec60dffc6db479df413b2f27092b8','sys_file_metadata',47,'file','','','',0,0,'sys_file',47,''),('43b48dd3260d7a695d5535df5ae5cf7c','sys_file',39,'metadata','','','',0,0,'sys_file_metadata',39,''),('4623d430381ce0c0d96a7ce3457bb233','sys_file_metadata',85,'file','','','',0,0,'sys_file',85,''),('4750dd38eb5ff9d98e5df04ea4a442c4','sys_file',32,'storage','','','',0,0,'sys_file_storage',1,''),('47899da464265d22d955fccad07e7383','sys_file',22,'metadata','','','',0,0,'sys_file_metadata',22,''),('48c59f5f478bab7f218a6a928e4f8b87','sys_file',136,'metadata','','','',0,0,'sys_file_metadata',136,''),('48daaf78b655aefdf8a835343649b4ae','sys_file',16,'metadata','','','',0,0,'sys_file_metadata',16,''),('491dd54a1dce8453693ea4d17e5b0486','sys_file_metadata',86,'file','','','',0,0,'sys_file',86,''),('49b12c90eaf4a80295b934250348ddba','sys_file',153,'metadata','','','',0,0,'sys_file_metadata',153,''),('4d9fd84367dce56d921b12e6dd2d135d','tt_content',2,'tx_container_parent','','','',0,0,'tt_content',1,''),('4e9a7d84fd524aef314d554630a620e5','sys_file_metadata',158,'file','','','',0,0,'sys_file',158,''),('50c6b41c4b3df6a512bafdb62a204e95','sys_file_metadata',153,'file','','','',0,0,'sys_file',153,''),('521a4a638ae4152eec845b115a86fd76','sys_file_reference',224,'uid_local','','','',0,0,'sys_file',134,''),('52237f87bb0a7b7fca70dd8438709feb','tt_content',2,'bodytext','','typolink_tag','0cab4f88bc7a0d5318af1f7b96dce7b9:1',-1,0,'tt_content',3,''),('5298445b1835c575e66a1da78c729361','tt_content',370,'bodytext','','typolink_tag','6ae9cd4755df24a53b002a63e3ed73c6:1',-1,0,'tt_content',371,''),('52d745f0161e289a9c8ad92cd5e5c039','sys_file_metadata',101,'file','','','',0,0,'sys_file',101,''),('53613acbc84219fb3d51d32a6834915e','sys_file_reference',241,'uid_local','','','',0,0,'sys_file',136,''),('539e473da2e46432dfea444628bc4746','sys_file',120,'metadata','','','',0,0,'sys_file_metadata',120,''),('549b891bbf2b8d8c7dc23cf1281683a7','sys_file',92,'metadata','','','',0,0,'sys_file_metadata',92,''),('54cad1e717af832e6a1b2b560359925b','tt_content',187,'tx_container_parent','','','',0,0,'tt_content',9,''),('54d5bc51bf47154f3cbb9d2c0ab4d13b','sys_file',41,'metadata','','','',0,0,'sys_file_metadata',41,''),('55f62d4d2c99a52c5fbc552141ecadb7','sys_file_metadata',50,'file','','','',0,0,'sys_file',50,''),('56e727aca421fa994df3bafc75259f8d','tx_personnel_domain_model_person',7,'images','','','',0,0,'sys_file_reference',218,''),('573c3164eb8c83d9f9ad95eb3620227c','tt_content',158,'tx_container_parent','','','',0,0,'tt_content',157,''),('588f320fec2b4b67f5e105e667178e73','tt_content',335,'tx_container_parent','','','',0,0,'tt_content',334,''),('59abaa06dcf8e28f0addceee173e4b18','sys_file',128,'storage','','','',0,0,'sys_file_storage',1,''),('5a5b6aa225a045f63d5e784a2445895a','sys_file',148,'metadata','','','',0,0,'sys_file_metadata',148,''),('5a8cafcb2e835c6f75ec3f747b2f9c09','sys_file_metadata',134,'file','','','',0,0,'sys_file',134,''),('5b6d3b71b04f7443a121be23b85a1332','sys_file',130,'storage','','','',0,0,'sys_file_storage',1,''),('5d075746177918b286cfa8ab85a1ba2e','sys_file',29,'storage','','','',0,0,'sys_file_storage',1,''),('5d733278b3c0882d1be9d928bca31561','tx_personnel_domain_model_person',2,'email','','email','2',-1,0,'_STRING',0,'example@domain.com'),('5da7bbaa9339f9cb04a088062a69fe20','sys_file_metadata',156,'file','','','',0,0,'sys_file',156,''),('5ef13ab734b9153143ad30cce90cd70e','sys_file',85,'metadata','','','',0,0,'sys_file_metadata',85,''),('5f21615395ce5d4e97646eea9d50a70f','sys_file_reference',223,'uid_local','','','',0,0,'sys_file',136,''),('5fe7bc7d4b5e0525d6d1891723065f79','sys_file_reference',242,'uid_local','','','',0,0,'sys_file',134,''),('60e676dba9e57f4451dff6f2230582b1','sys_file_metadata',123,'file','','','',0,0,'sys_file',123,''),('61977478bd2dfb37904b8a4f7a50dd00','sys_file',13,'metadata','','','',0,0,'sys_file_metadata',13,''),('643e5c81fe35f47e2a610656ec3d4060','tt_content',32,'tx_container_parent','','','',0,0,'tt_content',7,''),('65827e61ebeb8c5c8fbdeff1644047e1','sys_file',160,'storage','','','',0,0,'sys_file_storage',1,''),('686bd383362ddd11eff9fce9dc30bb42','sys_file_reference',218,'uid_local','','','',0,0,'sys_file',158,''),('687e68460217e3b43fcd508e8510dc0c','sys_file_metadata',160,'file','','','',0,0,'sys_file',160,''),('692e129d0a6ae1105f43e3627f14e64d','sys_file',8,'storage','','','',0,0,'sys_file_storage',1,''),('698ee3755bb3c3c914a93b9a2cd767b0','sys_file_metadata',163,'file','','','',0,0,'sys_file',163,''),('6b65b767c242c3191e8d2cf0026a1710','tt_content',16,'tx_container_parent','','','',0,0,'tt_content',332,''),('6ba21a8d2dc056b3575d9554fb53d4a4','sys_file_reference',199,'tx_youtubevideo_coverimage','','','',0,0,'sys_file_reference',200,''),('6ca73b7ed9ee7af533ea7b9a1c82e64a','sys_file',86,'storage','','','',0,0,'sys_file_storage',1,''),('6d06f0be8cf68bc9e14e4682195dd2bb','tt_content',357,'tx_container_parent','','','',0,0,'tt_content',358,''),('6d7448b29e1912f1ea2e4645883a78b3','tt_content',330,'bodytext','','email','2',-1,0,'_STRING',0,'info@t3brightside.com'),('6d956b9630706f0e01239d7edb5cd63a','sys_file_metadata',81,'file','','','',0,0,'sys_file',81,''),('6da977dcf0267c79b2e49921f2e79e2b','sys_file_reference',204,'uid_local','','','',0,0,'sys_file',123,''),('70811c4e0c6633abf1b3ac1786bb3079','tt_content',8,'tx_container_parent','','','',0,0,'tt_content',3,''),('70e44f7fcaeb072c3a09e7fadfd37426','sys_file',130,'metadata','','','',0,0,'sys_file_metadata',130,''),('711c48bac1b894c671188743978f2aa5','sys_file_reference',236,'uid_local','','','',0,0,'sys_file',135,''),('7206b31211e1355569917c596b548185','tt_content',78,'tx_container_parent','','','',0,0,'tt_content',3,''),('721347c0ce4df94752a268820abd42d6','sys_file',81,'storage','','','',0,0,'sys_file_storage',1,''),('72b2f9f5cdf4e9679b405c82b7be8e93','tx_personnel_domain_model_person',2,'images','','','',0,0,'sys_file_reference',217,''),('732d00ac3e6683b82a9deec0f428a463','sys_file_metadata',157,'file','','','',0,0,'sys_file',157,''),('7401dfeb14147ed1d6597e9ee008dc66','sys_file_metadata',53,'file','','','',0,0,'sys_file',53,''),('7438b33eb243d508cb1f90a0974d0501','sys_file',93,'storage','','','',0,0,'sys_file_storage',1,''),('7488b928299581a77c081d70d2cb3e9e','tt_content',337,'assets','','','',0,0,'sys_file_reference',221,''),('749b0771828793d3e3eba1372852a7a8','sys_file',2,'metadata','','','',0,0,'sys_file_metadata',2,''),('74f42b0b6ac992bc791b2fe84e09b98f','tt_content',373,'bodytext','','typolink_tag','0de4bf68b6937c394debd377cd5d5741:1',-1,0,'tt_content',369,''),('7692cc3a0eb321f3516c7b047f5e6211','sys_file',29,'metadata','','','',0,0,'sys_file_metadata',29,''),('771d3c16378082f19a4a8d2c1c1582e3','sys_file',134,'metadata','','','',0,0,'sys_file_metadata',134,''),('7782b1ee1538a061408b5e0d31f0c149','sys_file_metadata',114,'file','','','',0,0,'sys_file',114,''),('790350e1dea97804892212c437058cd9','tt_content',17,'tx_paginatedprocessors_anchorid','','','',0,0,'tt_content',5,''),('791d3f9d43dcbfa78cd49dd8258caa09','sys_file',5,'storage','','','',0,0,'sys_file_storage',1,''),('79d2c903b87f5713c13d0b4cbafc1f35','sys_file',31,'metadata','','','',0,0,'sys_file_metadata',31,''),('7a98b2f14bd482419a9b676513c764ba','tt_content',357,'media','','','',2,0,'sys_file_reference',238,''),('7afa6934a0491343b7b2832837d78000','sys_file_metadata',34,'file','','','',0,0,'sys_file',34,''),('7dea25184bfdd1efc3e160636f252be7','sys_file',125,'storage','','','',0,0,'sys_file_storage',1,''),('7e6b7cca077f2e98aa7f7088d5f233d7','tt_content',24,'bodytext','','typolink_tag','7d6410794cd398f259caaa7295be76dd:3',-1,0,'tt_content',329,''),('7e846f6458ddae6eeff76b3b363c3fc7','tt_content',373,'bodytext','','typolink_tag','1',-1,0,'pages',1,''),('7f15ea8d3d71989d5ea275a32a7e85bb','sys_file',49,'storage','','','',0,0,'sys_file_storage',1,''),('7fcf177f47d5b87060639e75b96d4ff4','tt_content',337,'assets','','','',3,0,'sys_file_reference',224,''),('809760df02cc79bfed6bd34a0741cc3a','tt_content',1,'image','','','',0,0,'sys_file_reference',155,''),('80f6b9177c5e17a45113b806c39109ef','sys_file_reference',203,'uid_local','','','',0,0,'sys_file',125,''),('817a42bcedd459d0930e36776634f878','tt_content',158,'assets','','','',2,0,'sys_file_reference',184,''),('8233d2bb37cc1001bf35c88ee118f4cb','tt_content',330,'tx_container_parent','','','',0,0,'tt_content',329,''),('82650aa1fe5bd83e1ecb6f61c36417bf','sys_file',162,'storage','','','',0,0,'sys_file_storage',1,''),('82b54f58a09ff7c754eb47c874eff6c2','sys_file_metadata',10,'file','','','',0,0,'sys_file',10,''),('83766280f5bdc4b856fa034501dcc0b8','sys_file_metadata',135,'file','','','',0,0,'sys_file',135,''),('8501db49d3e7423980f6c0343ca064da','sys_file_metadata',149,'file','','','',0,0,'sys_file',149,''),('858d757fcdd731e3e8bf8f03a47e63a9','sys_file',51,'storage','','','',0,0,'sys_file_storage',1,''),('8592793a32ae37a399ab3b10d0e9973a','sys_file',35,'metadata','','','',0,0,'sys_file_metadata',35,''),('85ae815bc5289e2f0686a8b57676d4d8','tt_content',370,'bodytext','','typolink_tag','1',-1,0,'pages',1,''),('85ba6b818f707be0b494128cf8293b60','tt_content',337,'assets','','','',1,0,'sys_file_reference',222,''),('85ed0ed961ff0fa983be1c8f723eae16','tt_content',374,'assets','','','',1,0,'sys_file_reference',240,''),('8987893411baca05f986dca0a4c38bd8','sys_file',5,'metadata','','','',0,0,'sys_file_metadata',5,''),('8b449777adf7b3d6b5fc6c4500578a1b','sys_file',54,'metadata','','','',0,0,'sys_file_metadata',54,''),('8bd345fe20011f78b1c1e0b8d7597fae','tt_content',90,'tx_container_parent','','','',0,0,'tt_content',89,''),('8c6bdb6a11683dc6cd4a084ef2cd03ef','tt_content',374,'assets','','','',0,0,'sys_file_reference',239,''),('8cdb4b99b67a38464f26bf651849bde6','sys_file',125,'metadata','','','',0,0,'sys_file_metadata',125,''),('8d23731a2b2037f4781f89c5149c57be','sys_file_metadata',5,'file','','','',0,0,'sys_file',5,''),('8e02b4670398476bf4565f2ab0624e16','tt_content',163,'assets','','','',2,0,'sys_file_reference',205,''),('8f8397c45b5341cd83fb5e6ebc8c5544','tt_content',266,'bodytext','','typolink_tag','1',-1,0,'pages',1,''),('8fd6e23eca349e02ba628a6979d4199d','sys_file',157,'metadata','','','',0,0,'sys_file_metadata',157,''),('908d99d11254b098427aa11d88c52ae7','tt_content',158,'assets','','','',0,0,'sys_file_reference',214,''),('92caa29eaa405d11ab718473c1318ceb','sys_file_reference',220,'uid_local','','','',0,0,'sys_file',162,''),('92cc3842a84c2f6c1b01dfbf5935e0fc','sys_file',157,'storage','','','',0,0,'sys_file_storage',1,''),('9316901796f4763c98698177b373b6c4','tt_content',309,'tx_container_parent','','','',0,0,'tt_content',3,''),('952d5320e2db1d3343d80387c24c754c','sys_file_metadata',155,'file','','','',0,0,'sys_file',155,''),('952ff58309ea86d82acc12b3e4080ecc','tt_content',158,'assets','','','',1,0,'sys_file_reference',189,''),('96a207c4ca6aa58a7438792b4a42d366','sys_file_metadata',97,'file','','','',0,0,'sys_file',97,''),('96d65656979cfe98847ca94e0bb7489e','sys_file',142,'storage','','','',0,0,'sys_file_storage',1,''),('979c69cb03358a2d36b7e2714b4e4f88','tt_content',17,'pages','','','',0,0,'pages',3,''),('97f4f1ce666977d0059b799bcc45ab66','sys_file',155,'metadata','','','',0,0,'sys_file_metadata',155,''),('98573766620928ffb5c3877a32c44ace','sys_file',148,'storage','','','',0,0,'sys_file_storage',1,''),('99ca53250f4c18a528379d3d73d32963','sys_file',149,'metadata','','','',0,0,'sys_file_metadata',149,''),('99d190a15a12f183cd654f995176e2f7','sys_file',74,'metadata','','','',0,0,'sys_file_metadata',74,''),('99de689fcc8d549c1edc8d615d5e37a0','sys_file_metadata',4,'file','','','',0,0,'sys_file',4,''),('9add96dac2e37ee67c28e1187359ace9','tt_content',267,'assets','','','',0,0,'sys_file_reference',219,''),('9b6f369edfacbaf7be9f030e5130ddf6','sys_file_metadata',110,'file','','','',0,0,'sys_file',110,''),('9c0010ae14257773393bc978d172c883','sys_file',150,'storage','','','',0,0,'sys_file_storage',1,''),('9c8ea432459b121b02497c7f21d8d81a','sys_file_reference',76,'uid_local','','','',0,0,'sys_file',2,''),('9c9a7f6439eedb583b757e975ab9a7ce','sys_file_metadata',83,'file','','','',0,0,'sys_file',83,''),('9d045b88ecd74a28975bab42ed13a99e','sys_file_reference',214,'uid_local','','','',0,0,'sys_file',120,''),('9d1834b89afa44ba238a34c738f79204','tt_content',21,'tx_container_parent','','','',0,0,'tt_content',31,''),('9d5f6e844610c967eab14ac7af2f16e3','sys_file_metadata',141,'file','','','',0,0,'sys_file',141,''),('9dc2c83b8552791f2ded590f59e953f0','pages',7,'tx_pagelist_images','','','',0,0,'sys_file_reference',211,''),('9dcc5741d394ad0dfa1bbe0b3b6e3687','sys_file',160,'metadata','','','',0,0,'sys_file_metadata',160,''),('9f9cc515a0ed3fb45277193afa5266a0','tt_content',374,'assets','','','',3,0,'sys_file_reference',242,''),('9fbe3b191a69e140085da4955a1ad91f','sys_file_metadata',162,'file','','','',0,0,'sys_file',162,''),('a00625faa664b731bc39f7a8b9e9686a','sys_file_metadata',39,'file','','','',0,0,'sys_file',39,''),('a01426ae6a06b63ecfed5c9dc15c0374','tt_content',81,'tx_container_parent','','','',0,0,'tt_content',80,''),('a155e86b7915bb76541c7061cffcf707','tt_content',9,'tx_container_parent','','','',0,0,'tt_content',3,''),('a1e46773c821e13ad488d005962cf05b','sys_file',30,'storage','','','',0,0,'sys_file_storage',1,''),('a35233b40f8aa7f021a7fd8ae7f8bb8f','tt_content',158,'assets','','','',3,0,'sys_file_reference',188,''),('a391656edb2fc613c8c6beff0cf68321','tt_content',346,'tx_container_parent','','','',0,0,'tt_content',339,''),('a5aca38014ca63c88d1e85c0f7905e7f','sys_file_reference',237,'uid_local','','','',0,0,'sys_file',120,''),('a5ba571ba315e717ff4d3bf4f32475d8','sys_file_reference',6,'uid_local','','','',0,0,'sys_file',8,''),('a5e29a3a81967287c153e016ee36cba5','sys_file',54,'storage','','','',0,0,'sys_file_storage',1,''),('a64c000d6ba3290876831fdc1464dd36','tt_content',357,'media','','','',1,0,'sys_file_reference',237,''),('a6572b97acc7d0627fbf9e311fec1cc4','sys_file',16,'storage','','','',0,0,'sys_file_storage',1,''),('a665d2a2e117ae005bd0b1e800b1c86c','sys_file_metadata',130,'file','','','',0,0,'sys_file',130,''),('a66832d778186a6ad275c3deb26c20a2','sys_file',134,'storage','','','',0,0,'sys_file_storage',1,''),('a6aa2966e70054e32133cc186fd80673','tt_content',357,'media','','','',0,0,'sys_file_reference',236,''),('a8a00494a7aaad240d055e9f1759cd7a','sys_file_reference',200,'uid_local','','','',0,0,'sys_file',141,''),('ab02488914100661fcba11e47fd5490e','tt_content',334,'tx_container_parent','','','',0,0,'tt_content',80,''),('ac1a08a702bf97b64b015eb6103fbd2c','sys_file_metadata',125,'file','','','',0,0,'sys_file',125,''),('ac597d1c856d319c699ffce32fb24009','sys_file',114,'metadata','','','',0,0,'sys_file_metadata',114,''),('add8efad26c05469e1737c6381b1d493','sys_file',135,'storage','','','',0,0,'sys_file_storage',1,''),('aeb45c5f34c3aab73286b3fa0ab6cb99','tt_content',164,'tx_container_parent','','','',0,0,'tt_content',166,''),('af678b277177775a05c7cba09836a6fd','tt_content',124,'bodytext','','typolink_tag','1',-1,0,'pages',1,''),('aff8619cb291eb2743fcdee66964fc81','sys_template',2,'constants','','url','7',-1,0,'_STRING',0,'https://twitter.com/t3brightside'),('b1f3036a5e5118607c52701c9ab644e6','sys_file_metadata',84,'file','','','',0,0,'sys_file',84,''),('b29369f461d443f4eb1b8259f627eaf4','sys_file',149,'storage','','','',0,0,'sys_file_storage',1,''),('b445d1bae12e6345690ecadf933c92e2','sys_file',97,'metadata','','','',0,0,'sys_file_metadata',97,''),('b4fc6db3bdfc8f91a8e87dfad30996ee','tt_content',333,'tx_vimeovideo_assets','','','',0,0,'sys_file_reference',220,''),('b50f65443dd36304cb85aac1e0253da5','sys_file',47,'metadata','','','',0,0,'sys_file_metadata',47,''),('b5d8a5ee30fefad52d3847a23a678558','sys_file_metadata',74,'file','','','',0,0,'sys_file',74,''),('b79c96177201ae7b121ca0965a949291','sys_file_reference',188,'uid_local','','','',0,0,'sys_file',130,''),('b8ebfd578a12410878bd742a4c1f2413','sys_file',42,'metadata','','','',0,0,'sys_file_metadata',42,''),('baa22019f2ea8b1f88ed6ba714399740','sys_file_metadata',13,'file','','','',0,0,'sys_file',13,''),('bb1386f965960c4657547e666787ca9c','sys_file_reference',235,'uid_local','','','',0,0,'sys_file',41,''),('bb745801590a1442ba37c253da57cc3c','sys_file',48,'metadata','','','',0,0,'sys_file_metadata',48,''),('bbf33e7f83847f0ce1983e92c2c761b5','sys_file_metadata',48,'file','','','',0,0,'sys_file',48,''),('bc1b5dad51146707f3d784fee807c99e','sys_file_reference',219,'uid_local','','','',0,0,'sys_file',160,''),('bd13fa7b4f0b587e1949ce8e78a80db3','sys_file_metadata',142,'file','','','',0,0,'sys_file',142,''),('bd55138958258043e44365a0e16e3d79','tt_content',327,'bodytext','','typolink_tag','1',-1,0,'pages',1,''),('be549680be5bcabef6fe90ab2f83b042','sys_file',52,'metadata','','','',0,0,'sys_file_metadata',52,''),('be83d54bc28dcd9866709bc7eaf0e1c1','sys_file',119,'storage','','','',0,0,'sys_file_storage',1,''),('bfe765cb21c7469f08b05c6d60b2f3ca','sys_template',2,'constants','','url','2',-1,0,'_STRING',0,'https://microtemplate.t3brightside.com/'),('c0b0e162fa6e6d211d44ceaa65269399','tt_content',17,'tx_container_parent','','','',0,0,'tt_content',5,''),('c1b5228e5f2efda662f7061a1cb4d0af','sys_file_reference',239,'uid_local','','','',0,0,'sys_file',125,''),('c2472d27fdbdf12adcacf67ad558dfb5','sys_file',81,'metadata','','','',0,0,'sys_file_metadata',81,''),('c2478f259bdad12644b08d66ef406c1b','tt_content',374,'assets','','','',2,0,'sys_file_reference',241,''),('c2eab9bdec3b0927c1d9050754111031','sys_file',47,'storage','','','',0,0,'sys_file_storage',1,''),('c2eb74d56cd587786177f51681cda789','sys_file',110,'metadata','','','',0,0,'sys_file_metadata',110,''),('c3a7df501a6692ea8ba19067d94eaa75','tt_content',331,'tx_container_parent','','','',0,0,'tt_content',4,''),('c3da14db519dfa74eee714471843ed5f','tt_content',24,'tx_container_parent','','','',0,0,'tt_content',23,''),('c4f959a3de7389dc9ee792145540589b','sys_file_reference',199,'uid_local','','','',0,0,'sys_file',142,''),('c529bc3d6d1c7c100760c5e7d6c4321f','tt_content',375,'tx_container_parent','','','',0,0,'tt_content',371,''),('c61149d114d7178aba3d8e406023250f','sys_file',156,'storage','','','',0,0,'sys_file_storage',1,''),('c78c9588e7aadd6bcfc994551fe0540c','sys_file_metadata',21,'file','','','',0,0,'sys_file',21,''),('c80ba2a160d792c820431076e2373b43','sys_file',34,'metadata','','','',0,0,'sys_file_metadata',34,''),('c86256cf98a7988aaf84e161e7d3b6cf','sys_template',2,'constants','','url','17',-1,0,'_STRING',0,'https://stats.t3brightside.com/script.js'),('cbafd710778f2b16fd6ddbbdda8e9c0c','sys_file',120,'storage','','','',0,0,'sys_file_storage',1,''),('cbf603ff6f07831a78fee4a2952ed7c0','sys_file',141,'storage','','','',0,0,'sys_file_storage',1,''),('cc109381e9cf183f2c6bb7b7733025b9','tt_content',16,'image','','','',0,0,'sys_file_reference',76,''),('cd5231d05a5dfa030126ddaa004f3f7f','sys_file_metadata',22,'file','','','',0,0,'sys_file',22,''),('ce671e3684d78c110e94d7b58b26b0b8','sys_file_metadata',42,'file','','','',0,0,'sys_file',42,''),('cfa24d5d5a74c51b595c9fe018c101fb','sys_file_metadata',119,'file','','','',0,0,'sys_file',119,''),('d07b5d96253322ad53209d5ed3bc5c73','sys_file_metadata',32,'file','','','',0,0,'sys_file',32,''),('d238ad01c110266a753ba2566e0a1fc0','sys_file',152,'metadata','','','',0,0,'sys_file_metadata',152,''),('d2bd41560fe0f5e715127f74b7e2e676','sys_file',152,'storage','','','',0,0,'sys_file_storage',1,''),('d34cd882fce0d0bf298148858c1feec7','tt_content',266,'bodytext','','typolink_tag','270dccea89ad9178ee9552ab6c5b384f:1',-1,0,'tt_content',89,''),('d3970681b798dc90c4a7f7e7cd25bdab','tt_content',20,'tx_container_parent','','','',0,0,'tt_content',6,''),('d5b995e8a3fe8a4502c602b3cfc47bc0','sys_file_reference',211,'uid_local','','','',0,0,'sys_file',134,''),('d5d71ff67b6bae3ed54ffdef7393dd70','tt_content',355,'tx_youtubevideo_assets','','','',0,0,'sys_file_reference',235,''),('d7cd2959cf13f044f3c321499599adb6','tt_content',33,'tx_container_parent','','','',0,0,'tt_content',31,''),('d85040f054c4f271af748697872d00c2','sys_file_reference',217,'uid_local','','','',0,0,'sys_file',156,''),('d860ef2766c42de6aa9d4772ca15443a','tx_personnel_domain_model_person',3,'images','','','',0,0,'sys_file_reference',5,''),('d8c627b0fc66ed23eedf9a128e04b4b4','tt_content',372,'tx_container_parent','','','',0,0,'tt_content',371,''),('d8d9d25a7f3d83a886b583ae12ca136b','tt_content',163,'tx_paginatedprocessors_anchorid','','','',0,0,'tt_content',320,''),('da2944582a70b78cd69061550f2273fd','sys_file',84,'metadata','','','',0,0,'sys_file_metadata',84,''),('da67a01ed44ffd76d06b52fb67fb5ed4','sys_file',84,'storage','','','',0,0,'sys_file_storage',1,''),('db53bb5a34b43eeb97fcf974bdb1a93f','sys_file_metadata',49,'file','','','',0,0,'sys_file',49,''),('dc698db592512df5e8c9172f42ce59e2','sys_file',32,'metadata','','','',0,0,'sys_file_metadata',32,''),('dc8eaef8903e505b4778ef95debc8910','sys_file_metadata',40,'file','','','',0,0,'sys_file',40,''),('dd52226390c3c74e2c4ff3dfac676eb7','tt_content',355,'tx_container_parent','','','',0,0,'tt_content',339,''),('dd634c72f492fe1f69d55727b633f620','sys_file_metadata',51,'file','','','',0,0,'sys_file',51,''),('dd8186968bc801ad39522e557d7cd6d3','sys_file',135,'metadata','','','',0,0,'sys_file_metadata',135,''),('ddb89c754923625ea59d16459b4067bd','tt_content',10,'tx_container_parent','','','',0,0,'tt_content',9,''),('ddd77a9f8fb4fdf5a153e8bbbfc4a031','tt_content',85,'tx_container_parent','','','',0,0,'tt_content',80,''),('de28246790cc908b18bc4ddfb6048688','sys_file_metadata',92,'file','','','',0,0,'sys_file',92,''),('de60d2e2952c418fdf8d778f20d4ab69','sys_file',119,'metadata','','','',0,0,'sys_file_metadata',119,''),('df7941865f85a7c052d8325a495fc9c7','sys_file',46,'metadata','','','',0,0,'sys_file_metadata',46,''),('e08245868d20a8a886ddf7c4ba1a407d','sys_file_metadata',30,'file','','','',0,0,'sys_file',30,''),('e1322d48726d9a88913af93a4346d11e','tt_content',332,'tx_container_parent','','','',0,0,'tt_content',4,''),('e1dcf0085116e1304ba2607d59e85621','sys_file',33,'metadata','','','',0,0,'sys_file_metadata',33,''),('e2de3f1a500b27c086eb0507d6d7cb2c','sys_file_reference',184,'uid_local','','','',0,0,'sys_file',119,''),('e2f43aabc5ec1a476fd5f29c110c3842','sys_file',163,'metadata','','','',0,0,'sys_file_metadata',163,''),('e2f7aa23dc74e552b0957ffbf792d8c7','sys_file',86,'metadata','','','',0,0,'sys_file_metadata',86,''),('e3c29349febb6bb6ac551f326a2032ae','sys_file',83,'storage','','','',0,0,'sys_file_storage',1,''),('e4f25600caf6b47af195b39234312146','tt_content',2,'bodytext','','typolink_tag','1',-1,0,'pages',1,''),('e53a53527080ace80846d7f3112cd88f','sys_file_metadata',54,'file','','','',0,0,'sys_file',54,''),('e71f9a441a77a4684c950e9ca053309f','sys_file',52,'storage','','','',0,0,'sys_file_storage',1,''),('e73a9744cb16317b33be99593e291f19','sys_file_metadata',82,'file','','','',0,0,'sys_file',82,''),('e7dc538d1406a5a2d77b2dfa43b0be3b','tt_content',91,'tx_container_parent','','','',0,0,'tt_content',89,''),('ea3b0a4e1d6aad10e3a0278c33280af7','sys_file_metadata',31,'file','','','',0,0,'sys_file',31,''),('eadc00ea31f707ce16e08e7b4e94630f','tt_content',337,'tx_paginatedprocessors_anchorid','','','',0,0,'tt_content',320,''),('eb2653780c25deadd1ed253485b02dbe','sys_file',33,'storage','','','',0,0,'sys_file_storage',1,''),('ec01e9666331703a2215b40555f23bf6','sys_file',4,'metadata','','','',0,0,'sys_file_metadata',4,''),('ed6d2b4834715c14094537dfba600afe','sys_file',101,'storage','','','',0,0,'sys_file_storage',1,''),('eeed546becbfe3071f052082a9b9707a','sys_file_reference',193,'uid_local','','','',0,0,'sys_file',135,''),('efe5ffbc1b341f3a5efb8f97fed82792','sys_file_metadata',8,'file','','','',0,0,'sys_file',8,''),('f246ae436df2710ae96714cb6e0d3a83','sys_file_reference',221,'uid_local','','','',0,0,'sys_file',125,''),('f2e6fca58e49306bb461f131ba61a85a','sys_file_metadata',150,'file','','','',0,0,'sys_file',150,''),('f3dd5d2ff5a296310a1fb907730c2863','sys_file',49,'metadata','','','',0,0,'sys_file_metadata',49,''),('f454bcca7caf639631b5f9ebd77c0c78','tt_content',358,'tx_container_parent','','','',0,0,'tt_content',339,''),('f4cbdef7f9055fc7f1b68f4619bec7dc','sys_file_reference',240,'uid_local','','','',0,0,'sys_file',123,''),('f553e622178ae41c17f4aa628cfe7c75','sys_file_reference',206,'uid_local','','','',0,0,'sys_file',134,''),('f5d62fa507b9a41a2e8627265abc1ae6','sys_file',74,'storage','','','',0,0,'sys_file_storage',1,''),('f68c0805e7b937b9dd993024a7e3e74f','sys_file',21,'metadata','','','',0,0,'sys_file_metadata',21,''),('f6aa798ddf3af217759f0c4ac2ffbe56','sys_file_reference',16,'uid_local','','','',0,0,'sys_file',13,''),('f8044c0435d4088839f2eead4a7bd4d6','sys_template',2,'constants','','url','12',-1,0,'_STRING',0,'https://github.com/t3brightside'),('f836388fb2eb4afbb27c6770f192e4cf','sys_file',114,'storage','','','',0,0,'sys_file_storage',1,''),('f89e1f5c2c517c7e1bde227ded31c82b','sys_file_metadata',41,'file','','','',0,0,'sys_file',41,''),('fb149e2ea3ae318985101d54c3757ca8','sys_file',34,'storage','','','',0,0,'sys_file_storage',1,''),('fc904066767cd2c01d906ff41eaf80c5','tt_content',163,'assets','','','',3,0,'sys_file_reference',206,''),('fd3745cd4c8a8104a41de0fdf20f0cca','sys_file_metadata',35,'file','','','',0,0,'sys_file',35,''),('fd7d102c97967eb7e9871a7aa480a68f','sys_file_metadata',46,'file','','','',0,0,'sys_file',46,''),('fdac21ac7f91c672e4b344d6ce39e503','sys_file',53,'storage','','','',0,0,'sys_file_storage',1,''),('fe6baa496480c7da7ee5b771fe029733','tx_personnel_domain_model_person',3,'email','','email','2',-1,0,'_STRING',0,'example@domain.com'),('fe996e77775f48360a2b04cd9f089783','sys_file',82,'metadata','','','',0,0,'sys_file_metadata',82,''),('ff66364ce763f8d256f9ab7ef8fd5add','sys_file_reference',205,'uid_local','','','',0,0,'sys_file',136,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=626 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ExtensionManagerTables','i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\WizardDoneToRegistry','i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\StartModuleUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FrontendUserImageUpdateWizard','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\DatabaseRowsUpdateWizard','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CommandLineBackendUserRemovalUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FillTranslationSourceField','i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SectionFrameToFrameClassUpdate','i:1;'),(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SplitMenusUpdate','i:1;'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BulletContentElementUpdate','i:1;'),(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\UploadContentElementUpdate','i:1;'),(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFscStaticTemplateUpdate','i:1;'),(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FileReferenceUpdate','i:1;'),(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFeSessionDataUpdate','i:1;'),(15,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Compatibility7ExtractionUpdate','i:1;'),(16,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FormLegacyExtractionUpdate','i:1;'),(17,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RteHtmlAreaExtractionUpdate','i:1;'),(18,'installUpdate','TYPO3\\CMS\\Install\\Updates\\LanguageSortingUpdate','i:1;'),(19,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Typo3DbExtractionUpdate','i:1;'),(20,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FuncExtractionUpdate','i:1;'),(21,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateUrlTypesInPagesUpdate','i:1;'),(22,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SeparateSysHistoryFromSysLogUpdate','i:1;'),(23,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectExtractionUpdate','i:1;'),(24,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserStartModuleUpdate','i:1;'),(25,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayUpdate','i:1;'),(26,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayBeGroupsAccessRights','i:1;'),(27,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendLayoutIconUpdateWizard','i:1;'),(28,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectsExtensionUpdate','i:1;'),(29,'installUpdate','TYPO3\\CMS\\Install\\Updates\\AdminPanelInstall','i:1;'),(30,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PopulatePageSlugs','i:1;'),(31,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Argon2iPasswordHashes','i:1;'),(33,'extensionDataImport','typo3conf/ext/gridelements/ext_tables_static+adt.sql','s:0:\"\";'),(34,'extensionDataImport','typo3conf/ext/pagelist/ext_tables_static+adt.sql','s:0:\"\";'),(35,'extensionDataImport','typo3conf/ext/personnel/ext_tables_static+adt.sql','s:0:\"\";'),(36,'extensionDataImport','typo3conf/ext/youtubevideo/ext_tables_static+adt.sql','s:0:\"\";'),(37,'extensionDataImport','typo3conf/ext/metaplus/ext_tables_static+adt.sql','s:0:\"\";'),(38,'extensionDataImport','typo3conf/ext/microtemplate/ext_tables_static+adt.sql','s:0:\"\";'),(39,'extensionDataImport','typo3/sysext/recycler/ext_tables_static+adt.sql','s:0:\"\";'),(40,'extensionDataImport','typo3/sysext/scheduler/ext_tables_static+adt.sql','s:0:\"\";'),(41,'extensionDataImport','typo3conf/ext/advancedtitle/ext_tables_static+adt.sql','s:0:\"\";'),(42,'extensionDataImport','typo3conf/ext/favicon/ext_tables_static+adt.sql','s:0:\"\";'),(43,'extensionDataImport','typo3conf/ext/news/ext_tables_static+adt.sql','s:0:\"\";'),(44,'extensionDataImport','typo3/sysext/form/ext_tables_static+adt.sql','s:0:\"\";'),(47,'tx_scheduler','lastRun','a:3:{s:5:\"start\";i:1642087032;s:3:\"end\";i:1642087033;s:4:\"type\";s:6:\"manual\";}'),(49,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RsaauthExtractionUpdate','i:1;'),(50,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeeditExtractionUpdate','i:1;'),(51,'installUpdate','TYPO3\\CMS\\Install\\Updates\\TaskcenterExtractionUpdate','i:1;'),(52,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysActionExtractionUpdate','i:1;'),(53,'extensionDataImport','typo3conf/ext/staticfilecache/ext_tables_static+adt.sql','s:0:\"\";'),(55,'extensionDataImport','typo3conf/ext/gallerycontent/ext_tables_static+adt.sql','s:0:\"\";'),(60,'extensionDataImport','typo3conf/ext/form_to_database/ext_tables_static+adt.sql','s:0:\"\";'),(62,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),(63,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserLanguageMigration','i:1;'),(64,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogChannel','i:1;'),(65,'core','formProtectionSessionToken:3','s:64:\"a2cf043719e4e56d6f589bdf9dff784a3d22e421e0685aab0a0dd78fea454b16\";'),(66,'core','sys_refindex_lastUpdate','i:1705999222;'),(90,'core','formProtectionSessionToken:4','s:64:\"42eedeb138ccc62dbf61f11ed4937811e39ad4b3d4a148c16ed25746b36297de\";'),(201,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendGroupsExplicitAllowDenyMigration','i:1;'),(202,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileMountIdentifierMigration','i:1;'),(203,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate','i:1;'),(206,'extensionScannerNotAffected','1faef6b0562993ec8a054bed2ef2c93d','s:32:\"1faef6b0562993ec8a054bed2ef2c93d\";'),(207,'extensionScannerNotAffected','f416c9b17936bb2c9f6e525e3a2d10f7','s:32:\"f416c9b17936bb2c9f6e525e3a2d10f7\";'),(208,'extensionScannerNotAffected','6a69258d7e410abf281bb233ce1661b4','s:32:\"6a69258d7e410abf281bb233ce1661b4\";'),(209,'extensionScannerNotAffected','fd283cc724be66c8d6bed30408616ec0','s:32:\"fd283cc724be66c8d6bed30408616ec0\";'),(210,'extensionScannerNotAffected','3c562313c6689bc62fb848b678587f30','s:32:\"3c562313c6689bc62fb848b678587f30\";'),(211,'extensionScannerNotAffected','10491f982a8c97a285074bafecd4850c','s:32:\"10491f982a8c97a285074bafecd4850c\";'),(212,'extensionScannerNotAffected','1a768c46e0bc3222ecd5de6fa243e9c3','s:32:\"1a768c46e0bc3222ecd5de6fa243e9c3\";'),(213,'extensionScannerNotAffected','252e11cc4c45060b62906e765a69a9b9','s:32:\"252e11cc4c45060b62906e765a69a9b9\";'),(214,'extensionScannerNotAffected','7487ebac255315ebacdc2037d8703830','s:32:\"7487ebac255315ebacdc2037d8703830\";'),(215,'extensionScannerNotAffected','6a0bf83873b9e942825b66eafffa5b5e','s:32:\"6a0bf83873b9e942825b66eafffa5b5e\";'),(216,'extensionScannerNotAffected','a2c672f1cd58289b62009e699b3fb917','s:32:\"a2c672f1cd58289b62009e699b3fb917\";'),(217,'extensionScannerNotAffected','9461687a740bf75293500661c28dc086','s:32:\"9461687a740bf75293500661c28dc086\";'),(218,'extensionScannerNotAffected','92bde134c0712419f41b56cf75fade47','s:32:\"92bde134c0712419f41b56cf75fade47\";'),(219,'extensionScannerNotAffected','087c7a25d0ebc24b631f0200778af7aa','s:32:\"087c7a25d0ebc24b631f0200778af7aa\";'),(220,'extensionScannerNotAffected','e5bf6cace2a7bd01920f1b9d78fe6af3','s:32:\"e5bf6cace2a7bd01920f1b9d78fe6af3\";'),(221,'extensionScannerNotAffected','8d5d8fc5aaaa63362e0e66645e84cd04','s:32:\"8d5d8fc5aaaa63362e0e66645e84cd04\";'),(222,'extensionScannerNotAffected','b2184d0767b2c8db68fd1c71e99b09ae','s:32:\"b2184d0767b2c8db68fd1c71e99b09ae\";'),(223,'extensionScannerNotAffected','0161c1715c79c76be4bc0ca57f66ece2','s:32:\"0161c1715c79c76be4bc0ca57f66ece2\";'),(224,'extensionScannerNotAffected','a2d416eba69e875edc13e6e37169265d','s:32:\"a2d416eba69e875edc13e6e37169265d\";'),(225,'extensionScannerNotAffected','7c3dd0ff8c604268a31354f06ee49271','s:32:\"7c3dd0ff8c604268a31354f06ee49271\";'),(226,'extensionScannerNotAffected','901343ea26f5f0d78740ac282171e0ae','s:32:\"901343ea26f5f0d78740ac282171e0ae\";'),(227,'extensionScannerNotAffected','c8ae5ce15ce02f46a2c3a036d7073d54','s:32:\"c8ae5ce15ce02f46a2c3a036d7073d54\";'),(228,'extensionScannerNotAffected','8889d2cabb7a5d076d15574ffc9f0cf4','s:32:\"8889d2cabb7a5d076d15574ffc9f0cf4\";'),(229,'extensionScannerNotAffected','595ba7108ca292dcfe7c3684fd6ea490','s:32:\"595ba7108ca292dcfe7c3684fd6ea490\";'),(230,'extensionScannerNotAffected','f347e36ac973787adddfd05fe112ac0c','s:32:\"f347e36ac973787adddfd05fe112ac0c\";'),(231,'extensionScannerNotAffected','b1c85d92f1ac1d25fb0419a7d92bac49','s:32:\"b1c85d92f1ac1d25fb0419a7d92bac49\";'),(232,'extensionScannerNotAffected','8eaa532805aebdbb5e995b74d9b09502','s:32:\"8eaa532805aebdbb5e995b74d9b09502\";'),(233,'extensionScannerNotAffected','c62dc21e825d5deb840b8398aea22364','s:32:\"c62dc21e825d5deb840b8398aea22364\";'),(234,'extensionScannerNotAffected','8b5ea79532c9c1e51cf74c321d37d44d','s:32:\"8b5ea79532c9c1e51cf74c321d37d44d\";'),(235,'extensionScannerNotAffected','ba449b0ec547e6799851e556884d3cc9','s:32:\"ba449b0ec547e6799851e556884d3cc9\";'),(236,'extensionScannerNotAffected','7c086c7c671a702bbb19feb4bde0cce5','s:32:\"7c086c7c671a702bbb19feb4bde0cce5\";'),(237,'extensionScannerNotAffected','d713ed1319435c932ab25edc639efd48','s:32:\"d713ed1319435c932ab25edc639efd48\";'),(238,'extensionScannerNotAffected','1eea68e3ee257d2d55dcf5e34e549f46','s:32:\"1eea68e3ee257d2d55dcf5e34e549f46\";'),(239,'extensionScannerNotAffected','209c9172fd59c89a350cc212f8ce72ed','s:32:\"209c9172fd59c89a350cc212f8ce72ed\";'),(240,'extensionScannerNotAffected','81eecacac2cb8e30724923278d989190','s:32:\"81eecacac2cb8e30724923278d989190\";'),(241,'extensionScannerNotAffected','d0d0ce43c93e0695f3dc5e838a7ca747','s:32:\"d0d0ce43c93e0695f3dc5e838a7ca747\";'),(242,'extensionScannerNotAffected','ed59921fd9ba21c899a942f0853d0174','s:32:\"ed59921fd9ba21c899a942f0853d0174\";'),(243,'extensionScannerNotAffected','625a1f560231b99623efad8e1cfea17d','s:32:\"625a1f560231b99623efad8e1cfea17d\";'),(244,'extensionScannerNotAffected','cc33e6442844cdcd7750eeda6cefc5bd','s:32:\"cc33e6442844cdcd7750eeda6cefc5bd\";'),(245,'extensionScannerNotAffected','a2eaa3723e22394abc3a0bdb038a5a2d','s:32:\"a2eaa3723e22394abc3a0bdb038a5a2d\";'),(246,'extensionScannerNotAffected','8adb3cad3f824023512c4d59e05018f1','s:32:\"8adb3cad3f824023512c4d59e05018f1\";'),(247,'extensionScannerNotAffected','759b1697fd3cfc2c866993011cf40bcd','s:32:\"759b1697fd3cfc2c866993011cf40bcd\";'),(248,'extensionScannerNotAffected','0a02f6c26050f2843e94e6a02c8b9f31','s:32:\"0a02f6c26050f2843e94e6a02c8b9f31\";'),(249,'extensionScannerNotAffected','738d136046e3786fa7697ed7a9599e75','s:32:\"738d136046e3786fa7697ed7a9599e75\";'),(250,'extensionScannerNotAffected','41f5925b02b9cd0184b4a9a60445591e','s:32:\"41f5925b02b9cd0184b4a9a60445591e\";'),(251,'extensionScannerNotAffected','cf30296fc712c5019f9e41ad7b391d05','s:32:\"cf30296fc712c5019f9e41ad7b391d05\";'),(252,'extensionScannerNotAffected','85b0efe4750aedf3673dbdee06fb4659','s:32:\"85b0efe4750aedf3673dbdee06fb4659\";'),(253,'extensionScannerNotAffected','b4b04b96018216823f4ae488ef33f5e2','s:32:\"b4b04b96018216823f4ae488ef33f5e2\";'),(254,'extensionScannerNotAffected','a3cf1408f6b2c8797d4250c6fc15af28','s:32:\"a3cf1408f6b2c8797d4250c6fc15af28\";'),(255,'extensionScannerNotAffected','72fbcb357d250400dd199c53e4c9fd2a','s:32:\"72fbcb357d250400dd199c53e4c9fd2a\";'),(256,'extensionScannerNotAffected','9fe7d021d2fa5a417f5e063887ee14c7','s:32:\"9fe7d021d2fa5a417f5e063887ee14c7\";'),(257,'extensionScannerNotAffected','7da735b8ec41537724eac26c7e124e8e','s:32:\"7da735b8ec41537724eac26c7e124e8e\";'),(258,'extensionScannerNotAffected','b745a90643fc5296a0b2009f83de8533','s:32:\"b745a90643fc5296a0b2009f83de8533\";'),(259,'extensionScannerNotAffected','dc291f82d5ef4d17dd152bc0035378d7','s:32:\"dc291f82d5ef4d17dd152bc0035378d7\";'),(260,'extensionScannerNotAffected','6de1c713d7186d98adea577a8143421f','s:32:\"6de1c713d7186d98adea577a8143421f\";'),(261,'extensionScannerNotAffected','d4711b0253657ca879c919dfac68f6cb','s:32:\"d4711b0253657ca879c919dfac68f6cb\";'),(262,'extensionScannerNotAffected','db080fcfa58a6ff0c463a7194a7f2d53','s:32:\"db080fcfa58a6ff0c463a7194a7f2d53\";'),(263,'extensionScannerNotAffected','ae49edc5d81324435d65b41a94a45f15','s:32:\"ae49edc5d81324435d65b41a94a45f15\";'),(264,'extensionScannerNotAffected','dc86a1c15cb13a0627dcd562712a3493','s:32:\"dc86a1c15cb13a0627dcd562712a3493\";'),(265,'extensionScannerNotAffected','54b140e518734e045c84661ccf91326b','s:32:\"54b140e518734e045c84661ccf91326b\";'),(266,'extensionScannerNotAffected','3ed29a6e143843d495b7813535aaed1e','s:32:\"3ed29a6e143843d495b7813535aaed1e\";'),(267,'extensionScannerNotAffected','195568ce7afd80c6e6c54230d28c878e','s:32:\"195568ce7afd80c6e6c54230d28c878e\";'),(268,'extensionScannerNotAffected','e78e0aaec884228c9ddb207dcba3fdcb','s:32:\"e78e0aaec884228c9ddb207dcba3fdcb\";'),(269,'extensionScannerNotAffected','8b1b4c666f981d018261756563fa7a51','s:32:\"8b1b4c666f981d018261756563fa7a51\";'),(270,'extensionScannerNotAffected','9c169afac1995c48f1d08585420afb2e','s:32:\"9c169afac1995c48f1d08585420afb2e\";'),(271,'extensionScannerNotAffected','217fe2d7f41bb756e4c408a8d612bd25','s:32:\"217fe2d7f41bb756e4c408a8d612bd25\";'),(272,'extensionScannerNotAffected','dc58d384de76019c3b59743f42273d25','s:32:\"dc58d384de76019c3b59743f42273d25\";'),(273,'extensionScannerNotAffected','07dcd6a4ab34b7b776e320d8bf8ff4e1','s:32:\"07dcd6a4ab34b7b776e320d8bf8ff4e1\";'),(274,'extensionScannerNotAffected','bad8815536fffa9c5b081b6c38c45811','s:32:\"bad8815536fffa9c5b081b6c38c45811\";'),(275,'extensionScannerNotAffected','edbf3c3ff5463311f0ce6d953638a2c7','s:32:\"edbf3c3ff5463311f0ce6d953638a2c7\";'),(276,'extensionScannerNotAffected','d0ea2c1615870e16ce17ddd181604a4d','s:32:\"d0ea2c1615870e16ce17ddd181604a4d\";'),(277,'extensionScannerNotAffected','8ba8c53900fd266b9d2eea5d2746fd53','s:32:\"8ba8c53900fd266b9d2eea5d2746fd53\";'),(278,'extensionScannerNotAffected','1cd8ab1c12378c570ec4e66227aff97c','s:32:\"1cd8ab1c12378c570ec4e66227aff97c\";'),(279,'extensionScannerNotAffected','f5ce4e049277aa36fc83303bcb6055b1','s:32:\"f5ce4e049277aa36fc83303bcb6055b1\";'),(280,'extensionScannerNotAffected','14fd13563d1f17fb4db9cb11864048de','s:32:\"14fd13563d1f17fb4db9cb11864048de\";'),(281,'extensionScannerNotAffected','05bbe791e33558b09f8f30f00155ac37','s:32:\"05bbe791e33558b09f8f30f00155ac37\";'),(282,'extensionScannerNotAffected','c0aa129dac148fa44ab4c912d5b5cfcb','s:32:\"c0aa129dac148fa44ab4c912d5b5cfcb\";'),(283,'extensionScannerNotAffected','e4582c4edcb5b7f4b9c1b2b09f0de8ac','s:32:\"e4582c4edcb5b7f4b9c1b2b09f0de8ac\";'),(284,'extensionScannerNotAffected','110b117081a2e2d2a876a7f69799060b','s:32:\"110b117081a2e2d2a876a7f69799060b\";'),(285,'extensionScannerNotAffected','54a4661a0a79695809480784d49b3fc1','s:32:\"54a4661a0a79695809480784d49b3fc1\";'),(286,'extensionScannerNotAffected','6590b836e87a4be9ea0326c6bebce7b0','s:32:\"6590b836e87a4be9ea0326c6bebce7b0\";'),(287,'extensionScannerNotAffected','fcdf9ed05d525c1354d9c5c7ab043c17','s:32:\"fcdf9ed05d525c1354d9c5c7ab043c17\";'),(288,'extensionScannerNotAffected','3c47e3798a565d74d9fc990b8093ba50','s:32:\"3c47e3798a565d74d9fc990b8093ba50\";'),(289,'extensionScannerNotAffected','f93b9500411ad5e214034757a971e09a','s:32:\"f93b9500411ad5e214034757a971e09a\";'),(290,'extensionScannerNotAffected','343f573ef870e727d900672f5c55b58d','s:32:\"343f573ef870e727d900672f5c55b58d\";'),(291,'extensionScannerNotAffected','0cce48811ea2ce1b1bb690a78b7c1c26','s:32:\"0cce48811ea2ce1b1bb690a78b7c1c26\";'),(292,'extensionScannerNotAffected','a56c3d280b72b38afb1ec1102390754c','s:32:\"a56c3d280b72b38afb1ec1102390754c\";'),(293,'extensionScannerNotAffected','94e665a09f15f32a4c8980422a87e8c6','s:32:\"94e665a09f15f32a4c8980422a87e8c6\";'),(294,'extensionScannerNotAffected','c6f081ec6d0595b63f2c36afcbb06e0a','s:32:\"c6f081ec6d0595b63f2c36afcbb06e0a\";'),(295,'extensionScannerNotAffected','23f9c88fbd4fc32a43aa91484c28875d','s:32:\"23f9c88fbd4fc32a43aa91484c28875d\";'),(296,'extensionScannerNotAffected','71c476013c0eff29b821b97ebcf22729','s:32:\"71c476013c0eff29b821b97ebcf22729\";'),(297,'extensionScannerNotAffected','766c7969440bf79b6c81ee839c0e28d2','s:32:\"766c7969440bf79b6c81ee839c0e28d2\";'),(298,'extensionScannerNotAffected','01877cb58cc6718143d454af0e22e7a1','s:32:\"01877cb58cc6718143d454af0e22e7a1\";'),(299,'extensionScannerNotAffected','13c07913127ab79a0b19f2381c27dbc5','s:32:\"13c07913127ab79a0b19f2381c27dbc5\";'),(300,'extensionScannerNotAffected','f0de3d2d6407343dbdaa2aa46a029589','s:32:\"f0de3d2d6407343dbdaa2aa46a029589\";'),(301,'extensionScannerNotAffected','98877f6c0f3d08bab2c8905e658909bd','s:32:\"98877f6c0f3d08bab2c8905e658909bd\";'),(302,'extensionScannerNotAffected','2d8c13760adab1f09bc60cb2e755a702','s:32:\"2d8c13760adab1f09bc60cb2e755a702\";'),(303,'extensionScannerNotAffected','12d2cf32eb677dc029d573366841e5be','s:32:\"12d2cf32eb677dc029d573366841e5be\";'),(304,'extensionScannerNotAffected','09f06ea508acbec6a1d1cfcec1cdc341','s:32:\"09f06ea508acbec6a1d1cfcec1cdc341\";'),(305,'extensionScannerNotAffected','9c901fade5881d2d6b86cab31374afa2','s:32:\"9c901fade5881d2d6b86cab31374afa2\";'),(306,'extensionScannerNotAffected','ab50726177c2478d1c74e36ee28a72a0','s:32:\"ab50726177c2478d1c74e36ee28a72a0\";'),(307,'extensionScannerNotAffected','74bb572d676afda82986e28117e7b83a','s:32:\"74bb572d676afda82986e28117e7b83a\";'),(308,'extensionScannerNotAffected','8ff4781e994ca9651c6c2ca3af9ca1af','s:32:\"8ff4781e994ca9651c6c2ca3af9ca1af\";'),(309,'extensionScannerNotAffected','9fd8b5ab403710c4f351958450fe16e5','s:32:\"9fd8b5ab403710c4f351958450fe16e5\";'),(310,'extensionScannerNotAffected','af4912b503cec16f4f683299246fb13d','s:32:\"af4912b503cec16f4f683299246fb13d\";'),(311,'extensionScannerNotAffected','1d4942180d68f2945c11546228dd046b','s:32:\"1d4942180d68f2945c11546228dd046b\";'),(312,'extensionScannerNotAffected','0cd3cea5ce9cf53bb878d834fe978834','s:32:\"0cd3cea5ce9cf53bb878d834fe978834\";'),(313,'extensionScannerNotAffected','0b6fbaa43e4fa4039c709df5e37cb9ea','s:32:\"0b6fbaa43e4fa4039c709df5e37cb9ea\";'),(314,'extensionScannerNotAffected','63ac38f1ce52667e677c6d3b92d2343d','s:32:\"63ac38f1ce52667e677c6d3b92d2343d\";'),(315,'extensionScannerNotAffected','176228940ec6d0ebf8bd09b17a327eab','s:32:\"176228940ec6d0ebf8bd09b17a327eab\";'),(316,'extensionScannerNotAffected','1bed3603d8260f87eb3cc32df434a692','s:32:\"1bed3603d8260f87eb3cc32df434a692\";'),(317,'extensionScannerNotAffected','ccdc92eac42157b5151a29dd1a631eac','s:32:\"ccdc92eac42157b5151a29dd1a631eac\";'),(318,'extensionScannerNotAffected','d954a4fe5723e5c621c625eb5b71f92d','s:32:\"d954a4fe5723e5c621c625eb5b71f92d\";'),(319,'extensionScannerNotAffected','915f89ba7007d23066d966232ddaf5c9','s:32:\"915f89ba7007d23066d966232ddaf5c9\";'),(320,'extensionScannerNotAffected','9886bc3921cbde67d0f86a4cbcd3d6ab','s:32:\"9886bc3921cbde67d0f86a4cbcd3d6ab\";'),(321,'extensionScannerNotAffected','400915f740ff0d95c494ec029d4fa99e','s:32:\"400915f740ff0d95c494ec029d4fa99e\";'),(322,'extensionScannerNotAffected','5d754ca0288ee2174388230e92b91ead','s:32:\"5d754ca0288ee2174388230e92b91ead\";'),(323,'extensionScannerNotAffected','1422bec9f8bbb27eeede573b31e65c6a','s:32:\"1422bec9f8bbb27eeede573b31e65c6a\";'),(324,'extensionScannerNotAffected','d7141cecea6548e7153471910c0c7082','s:32:\"d7141cecea6548e7153471910c0c7082\";'),(325,'extensionScannerNotAffected','9bcb0bd6f5682a33b489eecf20189b91','s:32:\"9bcb0bd6f5682a33b489eecf20189b91\";'),(326,'extensionScannerNotAffected','f3e3e87a6287a82abc502befd2ae9262','s:32:\"f3e3e87a6287a82abc502befd2ae9262\";'),(327,'extensionScannerNotAffected','df957f25f5fcb2a650be7a902d046d5f','s:32:\"df957f25f5fcb2a650be7a902d046d5f\";'),(328,'extensionScannerNotAffected','ed0b1db5ff7c2db0b25623635acfb661','s:32:\"ed0b1db5ff7c2db0b25623635acfb661\";'),(329,'extensionScannerNotAffected','87dfebfd4c19f7e4b9b7d35544e59800','s:32:\"87dfebfd4c19f7e4b9b7d35544e59800\";'),(330,'extensionScannerNotAffected','a303c1518194f40e675ea712b92d897e','s:32:\"a303c1518194f40e675ea712b92d897e\";'),(331,'extensionScannerNotAffected','d53f132a55d2f23d56b4ceb73ffa3bdc','s:32:\"d53f132a55d2f23d56b4ceb73ffa3bdc\";'),(332,'extensionScannerNotAffected','344a90c7e0053be0c693dff2c8006acf','s:32:\"344a90c7e0053be0c693dff2c8006acf\";'),(333,'extensionScannerNotAffected','1c2f4d48334dfda58273b2d9d4d82771','s:32:\"1c2f4d48334dfda58273b2d9d4d82771\";'),(334,'extensionScannerNotAffected','85deaeb5619bf22362f08cb09e680efc','s:32:\"85deaeb5619bf22362f08cb09e680efc\";'),(335,'extensionScannerNotAffected','d678bbe44635ebe8bce726d708c7a80a','s:32:\"d678bbe44635ebe8bce726d708c7a80a\";'),(336,'extensionScannerNotAffected','9dc6000ae9b28143304b92a50c848724','s:32:\"9dc6000ae9b28143304b92a50c848724\";'),(337,'extensionScannerNotAffected','f273cca2ccce3ffd5a2ecfff8b28f365','s:32:\"f273cca2ccce3ffd5a2ecfff8b28f365\";'),(338,'extensionScannerNotAffected','abfeef94e8f69dff3c2351e0fb258c64','s:32:\"abfeef94e8f69dff3c2351e0fb258c64\";'),(339,'extensionScannerNotAffected','2c6025c21906acd5224231278951a73c','s:32:\"2c6025c21906acd5224231278951a73c\";'),(340,'extensionScannerNotAffected','ade09d1df6614f6ab7469887f5d2d248','s:32:\"ade09d1df6614f6ab7469887f5d2d248\";'),(341,'extensionScannerNotAffected','9866b0b48efd56e4845f5ee54a15178e','s:32:\"9866b0b48efd56e4845f5ee54a15178e\";'),(342,'extensionScannerNotAffected','1dbe8708a0f10bd80e34c0e75e68b1fd','s:32:\"1dbe8708a0f10bd80e34c0e75e68b1fd\";'),(343,'extensionScannerNotAffected','c80e4f8f0f7311133c8bbaca3d457b73','s:32:\"c80e4f8f0f7311133c8bbaca3d457b73\";'),(344,'extensionScannerNotAffected','324e28d10fd1d464bc8145e775dda6ae','s:32:\"324e28d10fd1d464bc8145e775dda6ae\";'),(345,'extensionScannerNotAffected','17b2a3df8ff87d4e93d7cb8eb2b772e9','s:32:\"17b2a3df8ff87d4e93d7cb8eb2b772e9\";'),(346,'extensionScannerNotAffected','3fe70aa1f2c5e78750cbdefd56447f3c','s:32:\"3fe70aa1f2c5e78750cbdefd56447f3c\";'),(347,'extensionScannerNotAffected','e6259480e6f36dc930821269d1a589ae','s:32:\"e6259480e6f36dc930821269d1a589ae\";'),(348,'extensionScannerNotAffected','9af17b92bffa30bac327e0abc02ca7cd','s:32:\"9af17b92bffa30bac327e0abc02ca7cd\";'),(349,'extensionScannerNotAffected','2824b8876243a2d39c2a6837ca996e2a','s:32:\"2824b8876243a2d39c2a6837ca996e2a\";'),(350,'extensionScannerNotAffected','c9bec55731d0544d95274453e56f6ef4','s:32:\"c9bec55731d0544d95274453e56f6ef4\";'),(351,'extensionScannerNotAffected','9eb6e6bad95bc6e4eab2d956f7a4b4cc','s:32:\"9eb6e6bad95bc6e4eab2d956f7a4b4cc\";'),(352,'extensionScannerNotAffected','b09ec2731f29170c2f0f5609153f6ebe','s:32:\"b09ec2731f29170c2f0f5609153f6ebe\";'),(353,'extensionScannerNotAffected','b70d7d6c6305141700464904600fc232','s:32:\"b70d7d6c6305141700464904600fc232\";'),(354,'extensionScannerNotAffected','898c41fd59415c24ecfa193e8ff8c13d','s:32:\"898c41fd59415c24ecfa193e8ff8c13d\";'),(355,'extensionScannerNotAffected','59f26cab8fae72894d4867b334d914b0','s:32:\"59f26cab8fae72894d4867b334d914b0\";'),(356,'extensionScannerNotAffected','0a7d587bcf91e38382ac8bb270dae721','s:32:\"0a7d587bcf91e38382ac8bb270dae721\";'),(357,'extensionScannerNotAffected','8bea9d810503cbeafd3ec1eeb5889b29','s:32:\"8bea9d810503cbeafd3ec1eeb5889b29\";'),(358,'extensionScannerNotAffected','737e9b4d966382ffda13162e4faebf5e','s:32:\"737e9b4d966382ffda13162e4faebf5e\";'),(359,'extensionScannerNotAffected','7e75dac7391b40c952a673633b06fdf7','s:32:\"7e75dac7391b40c952a673633b06fdf7\";'),(360,'extensionScannerNotAffected','7bcf1948811d1042a25e123663ca6fb2','s:32:\"7bcf1948811d1042a25e123663ca6fb2\";'),(361,'extensionScannerNotAffected','6b59d48adbb52a285bd6dedd821181fd','s:32:\"6b59d48adbb52a285bd6dedd821181fd\";'),(362,'extensionScannerNotAffected','a859d1492a9608a5b3033ef9386f70cd','s:32:\"a859d1492a9608a5b3033ef9386f70cd\";'),(363,'extensionScannerNotAffected','3e49e0f18a1d972eb0f0e2d9331c3adc','s:32:\"3e49e0f18a1d972eb0f0e2d9331c3adc\";'),(364,'extensionScannerNotAffected','d9ab2a929768eef40427dbba78475e0b','s:32:\"d9ab2a929768eef40427dbba78475e0b\";'),(365,'extensionScannerNotAffected','21d21b236ac7b67c7db7a19bdab6c8d6','s:32:\"21d21b236ac7b67c7db7a19bdab6c8d6\";'),(366,'extensionScannerNotAffected','e6149f464b533888fda416c97196b480','s:32:\"e6149f464b533888fda416c97196b480\";'),(367,'extensionScannerNotAffected','8386a8482642549e47699bb9932c597c','s:32:\"8386a8482642549e47699bb9932c597c\";'),(368,'extensionScannerNotAffected','471a2e9555c860e3455df935b2ae267c','s:32:\"471a2e9555c860e3455df935b2ae267c\";'),(369,'extensionScannerNotAffected','b8606ea80291cdb9967ae99134458d6e','s:32:\"b8606ea80291cdb9967ae99134458d6e\";'),(370,'extensionScannerNotAffected','2686fc92f56974b8c177b1037edb7802','s:32:\"2686fc92f56974b8c177b1037edb7802\";'),(371,'extensionScannerNotAffected','5b94ae0411266b07650f0780cda37f4e','s:32:\"5b94ae0411266b07650f0780cda37f4e\";'),(372,'extensionScannerNotAffected','17b6b7eaebaee383f8aa2c60388a9ba6','s:32:\"17b6b7eaebaee383f8aa2c60388a9ba6\";'),(373,'extensionScannerNotAffected','2ec427290f951b808ac206c264b0a8ea','s:32:\"2ec427290f951b808ac206c264b0a8ea\";'),(374,'extensionScannerNotAffected','7e3a05e76ce4a0a9337876500601bee3','s:32:\"7e3a05e76ce4a0a9337876500601bee3\";'),(375,'extensionScannerNotAffected','f3a54a6f1d13f03504745af117dcc032','s:32:\"f3a54a6f1d13f03504745af117dcc032\";'),(376,'extensionScannerNotAffected','72fda82a23e71be951eb74b45e7554d2','s:32:\"72fda82a23e71be951eb74b45e7554d2\";'),(377,'extensionScannerNotAffected','6fa734df2c37c25dc45e90aaa43bfb65','s:32:\"6fa734df2c37c25dc45e90aaa43bfb65\";'),(378,'extensionScannerNotAffected','adfee89e126e184e8813de4f39fab1c5','s:32:\"adfee89e126e184e8813de4f39fab1c5\";'),(379,'extensionScannerNotAffected','dffce21225dad8ce1b65ee0e8263be81','s:32:\"dffce21225dad8ce1b65ee0e8263be81\";'),(380,'extensionScannerNotAffected','a1bcabf0b593700aa64f6318b676eff6','s:32:\"a1bcabf0b593700aa64f6318b676eff6\";'),(381,'extensionScannerNotAffected','cd41e90753126eec12c9636b476d88e7','s:32:\"cd41e90753126eec12c9636b476d88e7\";'),(382,'extensionScannerNotAffected','5360dcf47c8467e899195bc2238e3034','s:32:\"5360dcf47c8467e899195bc2238e3034\";'),(383,'extensionScannerNotAffected','cc3032da10c33172c022073233fb2073','s:32:\"cc3032da10c33172c022073233fb2073\";'),(384,'extensionScannerNotAffected','c97ef638506e95d3fba0f04850f9b733','s:32:\"c97ef638506e95d3fba0f04850f9b733\";'),(385,'extensionScannerNotAffected','8bdd67afcd45687f5a10912a93993e21','s:32:\"8bdd67afcd45687f5a10912a93993e21\";'),(386,'extensionScannerNotAffected','8f5fa21fab02544da90f243885c33907','s:32:\"8f5fa21fab02544da90f243885c33907\";'),(387,'extensionScannerNotAffected','2f51daeacc3ec70cb1feb4f3473be0f8','s:32:\"2f51daeacc3ec70cb1feb4f3473be0f8\";'),(388,'extensionScannerNotAffected','0aa3a077801aeec1378e15f48fd04085','s:32:\"0aa3a077801aeec1378e15f48fd04085\";'),(389,'extensionScannerNotAffected','8cb9af86b0f5c3be3f458e2ae616b8d9','s:32:\"8cb9af86b0f5c3be3f458e2ae616b8d9\";'),(390,'extensionScannerNotAffected','b664fdd3c37899aed1984ad83d8e840c','s:32:\"b664fdd3c37899aed1984ad83d8e840c\";'),(391,'extensionScannerNotAffected','836cf172821154f36eb8d943f494c416','s:32:\"836cf172821154f36eb8d943f494c416\";'),(392,'extensionScannerNotAffected','6998fe944bf6376b184805ed00e16784','s:32:\"6998fe944bf6376b184805ed00e16784\";'),(393,'extensionScannerNotAffected','192975d53cd934a17614d613115fc5f0','s:32:\"192975d53cd934a17614d613115fc5f0\";'),(394,'extensionScannerNotAffected','e33ea194d97ec367bdab714ff02be462','s:32:\"e33ea194d97ec367bdab714ff02be462\";'),(395,'extensionScannerNotAffected','a33b9f4dd4f5da96a4c5c2a674102c42','s:32:\"a33b9f4dd4f5da96a4c5c2a674102c42\";'),(396,'extensionScannerNotAffected','2f4ef542b7e12539f1c858bf142c4c1c','s:32:\"2f4ef542b7e12539f1c858bf142c4c1c\";'),(397,'extensionScannerNotAffected','4346f09e5036ab5e9b0bbcd39d796e31','s:32:\"4346f09e5036ab5e9b0bbcd39d796e31\";'),(398,'extensionScannerNotAffected','85191e2718f47805bca9eaca48df37f7','s:32:\"85191e2718f47805bca9eaca48df37f7\";'),(399,'extensionScannerNotAffected','da91a8846d40aa2a08537f88cbf9d67b','s:32:\"da91a8846d40aa2a08537f88cbf9d67b\";'),(400,'extensionScannerNotAffected','cb3b34610c5a08d40e9bb6b9934f4281','s:32:\"cb3b34610c5a08d40e9bb6b9934f4281\";'),(401,'extensionScannerNotAffected','de4f78129ccd0ff356b1decf529cdb97','s:32:\"de4f78129ccd0ff356b1decf529cdb97\";'),(402,'extensionScannerNotAffected','865bb7d2bc4f13fa6270bfc21095c96b','s:32:\"865bb7d2bc4f13fa6270bfc21095c96b\";'),(403,'extensionScannerNotAffected','338425e76cbfa9ab68fa513a4f9a8da8','s:32:\"338425e76cbfa9ab68fa513a4f9a8da8\";'),(404,'extensionScannerNotAffected','113e37a399eca4d97593a5c63758bd90','s:32:\"113e37a399eca4d97593a5c63758bd90\";'),(405,'extensionScannerNotAffected','8bb3f19abdcc30cd9803055ed60ed696','s:32:\"8bb3f19abdcc30cd9803055ed60ed696\";'),(406,'extensionScannerNotAffected','b8e3638d5f10b52a6383642591e0389b','s:32:\"b8e3638d5f10b52a6383642591e0389b\";'),(407,'extensionScannerNotAffected','2f24b3647e448d26dd247b6f84ee1622','s:32:\"2f24b3647e448d26dd247b6f84ee1622\";'),(408,'extensionScannerNotAffected','7b3bdad6f4a6f29903ca75c1d78c9045','s:32:\"7b3bdad6f4a6f29903ca75c1d78c9045\";'),(409,'extensionScannerNotAffected','8e7ba344126721feb3d3b70cb492ae62','s:32:\"8e7ba344126721feb3d3b70cb492ae62\";'),(410,'extensionScannerNotAffected','9de4b2449f0b5592583a3483442f26fa','s:32:\"9de4b2449f0b5592583a3483442f26fa\";'),(411,'extensionScannerNotAffected','31488ac80433722392a6f101443e456c','s:32:\"31488ac80433722392a6f101443e456c\";'),(412,'extensionScannerNotAffected','91299ca37f2ff269a177dc8997a313a9','s:32:\"91299ca37f2ff269a177dc8997a313a9\";'),(413,'extensionScannerNotAffected','33615382b70df5f5c9188014025efb3b','s:32:\"33615382b70df5f5c9188014025efb3b\";'),(414,'extensionScannerNotAffected','3ca8182b629890f563c3f96af63cc508','s:32:\"3ca8182b629890f563c3f96af63cc508\";'),(415,'extensionScannerNotAffected','22c96e35d7df82b64644722ae115d8ef','s:32:\"22c96e35d7df82b64644722ae115d8ef\";'),(416,'extensionScannerNotAffected','5ac57be87683e4c7e1edbb04f004ed02','s:32:\"5ac57be87683e4c7e1edbb04f004ed02\";'),(417,'extensionScannerNotAffected','b507d9617d8ab776b739c285ef8f82e1','s:32:\"b507d9617d8ab776b739c285ef8f82e1\";'),(418,'extensionScannerNotAffected','22429ca46d8b1e925ca537dc189b1f45','s:32:\"22429ca46d8b1e925ca537dc189b1f45\";'),(419,'extensionScannerNotAffected','0ae3c5822c70a6ba35463962ec93a19d','s:32:\"0ae3c5822c70a6ba35463962ec93a19d\";'),(420,'extensionScannerNotAffected','e4513c8aec99e02d734d6c88f0cf5d45','s:32:\"e4513c8aec99e02d734d6c88f0cf5d45\";'),(421,'extensionScannerNotAffected','c9ab262630b4a1f349cf2ec45b822cda','s:32:\"c9ab262630b4a1f349cf2ec45b822cda\";'),(422,'extensionScannerNotAffected','042610074ad3436e7eefc7bf5c6cc810','s:32:\"042610074ad3436e7eefc7bf5c6cc810\";'),(423,'extensionScannerNotAffected','a95d350b20474d9e420dfe2b981b26e1','s:32:\"a95d350b20474d9e420dfe2b981b26e1\";'),(424,'extensionScannerNotAffected','c3275b175cc1d3488a5c1febc17e81d3','s:32:\"c3275b175cc1d3488a5c1febc17e81d3\";'),(425,'extensionScannerNotAffected','d4ecb764ccfaaad1965aa3de4c1538ec','s:32:\"d4ecb764ccfaaad1965aa3de4c1538ec\";'),(426,'extensionScannerNotAffected','1fab2904a16a5857dcb58251137d1628','s:32:\"1fab2904a16a5857dcb58251137d1628\";'),(427,'extensionScannerNotAffected','7a9d2755e712863f5b21964b8875296f','s:32:\"7a9d2755e712863f5b21964b8875296f\";'),(428,'extensionScannerNotAffected','67cc8ccda99af7f5b4c650ebc9cf0118','s:32:\"67cc8ccda99af7f5b4c650ebc9cf0118\";'),(429,'extensionScannerNotAffected','ce1cc4420d0a93076afd4ac6a4483def','s:32:\"ce1cc4420d0a93076afd4ac6a4483def\";'),(430,'extensionScannerNotAffected','30a11b57255b9e69def26e40e51a2692','s:32:\"30a11b57255b9e69def26e40e51a2692\";'),(431,'extensionScannerNotAffected','1e29f401ebde3aa98a5baacfd54c947e','s:32:\"1e29f401ebde3aa98a5baacfd54c947e\";'),(432,'extensionScannerNotAffected','0ae318dfe4b78d7da63e3794ab200db2','s:32:\"0ae318dfe4b78d7da63e3794ab200db2\";'),(433,'extensionScannerNotAffected','f942095aff6efa110444fc2d6aa72a19','s:32:\"f942095aff6efa110444fc2d6aa72a19\";'),(434,'extensionScannerNotAffected','d5360c9d1e21fdeda265108180abac53','s:32:\"d5360c9d1e21fdeda265108180abac53\";'),(435,'extensionScannerNotAffected','ce689b3c60bc6af2962c1033fa6fcfcd','s:32:\"ce689b3c60bc6af2962c1033fa6fcfcd\";'),(436,'extensionScannerNotAffected','355ca000e0f66c61fd554241cb95b202','s:32:\"355ca000e0f66c61fd554241cb95b202\";'),(437,'extensionScannerNotAffected','d7c5e769cde14fb4dfd385967d36975a','s:32:\"d7c5e769cde14fb4dfd385967d36975a\";'),(438,'extensionScannerNotAffected','e0bdc5e387014314b68c8459edfdc092','s:32:\"e0bdc5e387014314b68c8459edfdc092\";'),(439,'extensionScannerNotAffected','a458c39dd7c35c469051c0832f87c40a','s:32:\"a458c39dd7c35c469051c0832f87c40a\";'),(440,'extensionScannerNotAffected','39b05c57979e382cc79298e1fc2f1413','s:32:\"39b05c57979e382cc79298e1fc2f1413\";'),(441,'extensionScannerNotAffected','2d41669f9c242cb93b89b0954adbe1a7','s:32:\"2d41669f9c242cb93b89b0954adbe1a7\";'),(442,'extensionScannerNotAffected','a3fcdb0b710f4434650f1e23238726b9','s:32:\"a3fcdb0b710f4434650f1e23238726b9\";'),(443,'extensionScannerNotAffected','aa061d6fd6844d166886a02468a2c8c7','s:32:\"aa061d6fd6844d166886a02468a2c8c7\";'),(444,'extensionScannerNotAffected','e5fb8959e90ef8f85797eac0c831db45','s:32:\"e5fb8959e90ef8f85797eac0c831db45\";'),(445,'extensionScannerNotAffected','8bd94ed0ef4d4449d731396d3eca2950','s:32:\"8bd94ed0ef4d4449d731396d3eca2950\";'),(446,'extensionScannerNotAffected','6b3ac9fb900b2e53de8248364574e48f','s:32:\"6b3ac9fb900b2e53de8248364574e48f\";'),(447,'extensionScannerNotAffected','0c44bac06883c5ea942a91bc2edacdfb','s:32:\"0c44bac06883c5ea942a91bc2edacdfb\";'),(448,'extensionScannerNotAffected','0f49206e1150f80bdb80eaa5e4fd2ecf','s:32:\"0f49206e1150f80bdb80eaa5e4fd2ecf\";'),(449,'extensionScannerNotAffected','d20f8da2eb1cb7a7eca52a145fc787e2','s:32:\"d20f8da2eb1cb7a7eca52a145fc787e2\";'),(450,'extensionScannerNotAffected','fb5a3f0af01005c18639082b1a404b69','s:32:\"fb5a3f0af01005c18639082b1a404b69\";'),(451,'extensionScannerNotAffected','f5fd76fc9907cd3fe609e44a72657f1c','s:32:\"f5fd76fc9907cd3fe609e44a72657f1c\";'),(452,'extensionScannerNotAffected','6c8b81e030762c668def5fdaad99ab54','s:32:\"6c8b81e030762c668def5fdaad99ab54\";'),(453,'extensionScannerNotAffected','6763b0d6e9b6bc5ec9e7622ba04761dc','s:32:\"6763b0d6e9b6bc5ec9e7622ba04761dc\";'),(454,'extensionScannerNotAffected','cb8a107c133de25112085547cb51fee7','s:32:\"cb8a107c133de25112085547cb51fee7\";'),(455,'extensionScannerNotAffected','a7056572c1b4cdb727e48c6a28b4e528','s:32:\"a7056572c1b4cdb727e48c6a28b4e528\";'),(456,'extensionScannerNotAffected','da0efe14d3cb2782a53ab02ccc85f5a1','s:32:\"da0efe14d3cb2782a53ab02ccc85f5a1\";'),(457,'extensionScannerNotAffected','b7ef0ef7adc26e716130fb74dee0a4fd','s:32:\"b7ef0ef7adc26e716130fb74dee0a4fd\";'),(458,'extensionScannerNotAffected','6bdd13c460d24f22a219d91d121d7fb9','s:32:\"6bdd13c460d24f22a219d91d121d7fb9\";'),(459,'extensionScannerNotAffected','a69448c1b682bf753c4fabfae77e2b03','s:32:\"a69448c1b682bf753c4fabfae77e2b03\";'),(460,'extensionScannerNotAffected','e3f754d8dad6184cb0ad5b03d686b8cb','s:32:\"e3f754d8dad6184cb0ad5b03d686b8cb\";'),(461,'extensionScannerNotAffected','165330c2d09a53d009204a19b538e568','s:32:\"165330c2d09a53d009204a19b538e568\";'),(462,'extensionScannerNotAffected','160b52118d33ad5c149fd859e43ddd70','s:32:\"160b52118d33ad5c149fd859e43ddd70\";'),(463,'extensionScannerNotAffected','3545b03c4525f913e50a3a7b0141985e','s:32:\"3545b03c4525f913e50a3a7b0141985e\";'),(464,'extensionScannerNotAffected','8c4b22b879db672714ac1690dd2b3237','s:32:\"8c4b22b879db672714ac1690dd2b3237\";'),(465,'extensionScannerNotAffected','5f5077001a66e69aea233d3e93d1310a','s:32:\"5f5077001a66e69aea233d3e93d1310a\";'),(466,'extensionScannerNotAffected','feee31a4f626a6e125a5886c05638641','s:32:\"feee31a4f626a6e125a5886c05638641\";'),(467,'extensionScannerNotAffected','be5e9c098491dac91f80e7a1de064e9d','s:32:\"be5e9c098491dac91f80e7a1de064e9d\";'),(468,'extensionScannerNotAffected','5d612a94ffffdcb591692e002ff2ab9f','s:32:\"5d612a94ffffdcb591692e002ff2ab9f\";'),(469,'extensionScannerNotAffected','f3a267cb99caea4e72ed6d66bf4e2da8','s:32:\"f3a267cb99caea4e72ed6d66bf4e2da8\";'),(470,'extensionScannerNotAffected','014e5dcf35c3d6fc8b8a692cbb56e43a','s:32:\"014e5dcf35c3d6fc8b8a692cbb56e43a\";'),(471,'extensionScannerNotAffected','8c18585d0c72f55b03906fa74b79e30d','s:32:\"8c18585d0c72f55b03906fa74b79e30d\";'),(472,'extensionScannerNotAffected','7c4c3a6eb349d033a95e8724b0b725ba','s:32:\"7c4c3a6eb349d033a95e8724b0b725ba\";'),(473,'extensionScannerNotAffected','326a48421379558a7527a56b45c24e1b','s:32:\"326a48421379558a7527a56b45c24e1b\";'),(474,'extensionScannerNotAffected','16be5a40555f720156c6006f34dcfacd','s:32:\"16be5a40555f720156c6006f34dcfacd\";'),(475,'extensionScannerNotAffected','997ee9b6a3dae2a060def0bebcfc9aca','s:32:\"997ee9b6a3dae2a060def0bebcfc9aca\";'),(476,'extensionScannerNotAffected','9d8da8c7e57a1d109a100f35334b1d47','s:32:\"9d8da8c7e57a1d109a100f35334b1d47\";'),(477,'extensionScannerNotAffected','e0127e7c34fa573e3cae3815130f8211','s:32:\"e0127e7c34fa573e3cae3815130f8211\";'),(478,'extensionScannerNotAffected','168ead984b1d1dd9414b43bfb7463383','s:32:\"168ead984b1d1dd9414b43bfb7463383\";'),(479,'extensionScannerNotAffected','7b640070cdb67b65b964fb8008a81670','s:32:\"7b640070cdb67b65b964fb8008a81670\";'),(480,'extensionScannerNotAffected','c40b044fad095951023985f97183d4e7','s:32:\"c40b044fad095951023985f97183d4e7\";'),(481,'extensionScannerNotAffected','b0b91dbb7f0f75c6c1d49c32aba9c863','s:32:\"b0b91dbb7f0f75c6c1d49c32aba9c863\";'),(482,'extensionScannerNotAffected','6771f198146576fc2a70ce5461728021','s:32:\"6771f198146576fc2a70ce5461728021\";'),(483,'extensionScannerNotAffected','ff1d6d30074b812fe841bb0a198ddfbf','s:32:\"ff1d6d30074b812fe841bb0a198ddfbf\";'),(484,'extensionScannerNotAffected','03ee79ca31203e4b288fa61017b0cb04','s:32:\"03ee79ca31203e4b288fa61017b0cb04\";'),(485,'extensionScannerNotAffected','ecc8d90045bf5b51a4f5087f19e3bb72','s:32:\"ecc8d90045bf5b51a4f5087f19e3bb72\";'),(486,'extensionScannerNotAffected','b3eb2f57b7048dc10b06b601afa1a68b','s:32:\"b3eb2f57b7048dc10b06b601afa1a68b\";'),(487,'extensionScannerNotAffected','7f030ea0c1e7246e77472efc8ebf1b2e','s:32:\"7f030ea0c1e7246e77472efc8ebf1b2e\";'),(488,'extensionScannerNotAffected','4e8f9d2deaef1ad3d7207ea590882a33','s:32:\"4e8f9d2deaef1ad3d7207ea590882a33\";'),(489,'extensionScannerNotAffected','c6fbc609b28b5481a761b791cb61da80','s:32:\"c6fbc609b28b5481a761b791cb61da80\";'),(490,'extensionScannerNotAffected','38354fcab935ef5dee086db0a7770360','s:32:\"38354fcab935ef5dee086db0a7770360\";'),(491,'extensionScannerNotAffected','932da83d688a200c366300752d904773','s:32:\"932da83d688a200c366300752d904773\";'),(492,'extensionScannerNotAffected','544a390bad17591adb404198dbb9d3b6','s:32:\"544a390bad17591adb404198dbb9d3b6\";'),(493,'extensionScannerNotAffected','44845e9f43edfe787e293d09d66d8b8c','s:32:\"44845e9f43edfe787e293d09d66d8b8c\";'),(494,'extensionScannerNotAffected','89b1943128ab1b71dd4983855c5ce1e8','s:32:\"89b1943128ab1b71dd4983855c5ce1e8\";'),(495,'extensionScannerNotAffected','37b4a4b1ccd4f2a7a50c41cd97456b2b','s:32:\"37b4a4b1ccd4f2a7a50c41cd97456b2b\";'),(496,'extensionScannerNotAffected','17c5edeb29362e8ea099f7589be67ad4','s:32:\"17c5edeb29362e8ea099f7589be67ad4\";'),(497,'extensionScannerNotAffected','fa77b4ee0f04a894e7d389285e5cc8b1','s:32:\"fa77b4ee0f04a894e7d389285e5cc8b1\";'),(498,'extensionScannerNotAffected','8160290ad0e0a2b26df443f27751a519','s:32:\"8160290ad0e0a2b26df443f27751a519\";'),(499,'extensionScannerNotAffected','d47cc2621605a6652ab17ed6f239ac9b','s:32:\"d47cc2621605a6652ab17ed6f239ac9b\";'),(500,'extensionScannerNotAffected','e71d3f59519be4cb6df58929f0436275','s:32:\"e71d3f59519be4cb6df58929f0436275\";'),(501,'extensionScannerNotAffected','6d29b1ad49f8ecc3fecbea36a67859ec','s:32:\"6d29b1ad49f8ecc3fecbea36a67859ec\";'),(502,'extensionScannerNotAffected','9f89c82b6e0b431c04b87e4e229769d3','s:32:\"9f89c82b6e0b431c04b87e4e229769d3\";'),(503,'extensionScannerNotAffected','18f664c8c929b1cdb4418781aeda7af0','s:32:\"18f664c8c929b1cdb4418781aeda7af0\";'),(504,'extensionScannerNotAffected','ffba01881f59bda8b8095ca54ecf72a3','s:32:\"ffba01881f59bda8b8095ca54ecf72a3\";'),(505,'extensionScannerNotAffected','f3433235666f9f90138a5cc9c8b41965','s:32:\"f3433235666f9f90138a5cc9c8b41965\";'),(506,'extensionScannerNotAffected','9869b0cc809f66493dccd791ca3525cd','s:32:\"9869b0cc809f66493dccd791ca3525cd\";'),(507,'extensionScannerNotAffected','b9d9a059308b72188e7509b43b846547','s:32:\"b9d9a059308b72188e7509b43b846547\";'),(508,'extensionScannerNotAffected','7ef2b99923b54ba86061deb6092e67c8','s:32:\"7ef2b99923b54ba86061deb6092e67c8\";'),(509,'extensionScannerNotAffected','09d5425f8dcc500277411b9bd0d5fbb7','s:32:\"09d5425f8dcc500277411b9bd0d5fbb7\";'),(510,'extensionScannerNotAffected','efae40738a60a8456a1b3948da8cfccc','s:32:\"efae40738a60a8456a1b3948da8cfccc\";'),(511,'extensionScannerNotAffected','c07befd21624591e3f814d5401a30ab5','s:32:\"c07befd21624591e3f814d5401a30ab5\";'),(512,'extensionScannerNotAffected','45d4bb180e30ef974e9b4e584836d78c','s:32:\"45d4bb180e30ef974e9b4e584836d78c\";'),(513,'extensionScannerNotAffected','8f45ae1aaba029344a202292be5330e6','s:32:\"8f45ae1aaba029344a202292be5330e6\";'),(514,'extensionScannerNotAffected','6f5d8526244b83ae2759751e8bf436a7','s:32:\"6f5d8526244b83ae2759751e8bf436a7\";'),(515,'extensionScannerNotAffected','2fab8c2a8303d0a8114f19c44e1fa845','s:32:\"2fab8c2a8303d0a8114f19c44e1fa845\";'),(516,'extensionScannerNotAffected','16693438f698c4c62a0b084e48d45bba','s:32:\"16693438f698c4c62a0b084e48d45bba\";'),(517,'extensionScannerNotAffected','cb228474381c9bad647a56a5fa5c81e6','s:32:\"cb228474381c9bad647a56a5fa5c81e6\";'),(518,'extensionScannerNotAffected','3295a8a4fb1c867e34d1fe5e59850e3b','s:32:\"3295a8a4fb1c867e34d1fe5e59850e3b\";'),(519,'extensionScannerNotAffected','d4c7b89fac340cb568aeec849a9351a7','s:32:\"d4c7b89fac340cb568aeec849a9351a7\";'),(520,'extensionScannerNotAffected','af6c8a91b462b758ba24a21814c3fd4a','s:32:\"af6c8a91b462b758ba24a21814c3fd4a\";'),(521,'extensionScannerNotAffected','a4cfe53b75527725ffe8b9c303441ffd','s:32:\"a4cfe53b75527725ffe8b9c303441ffd\";'),(522,'extensionScannerNotAffected','669243de0464324ebcdf223492862f8e','s:32:\"669243de0464324ebcdf223492862f8e\";'),(523,'extensionScannerNotAffected','715138a5b463064e31a081aedb900026','s:32:\"715138a5b463064e31a081aedb900026\";'),(524,'extensionScannerNotAffected','0df982270c206f486f2f7c6854a6f99f','s:32:\"0df982270c206f486f2f7c6854a6f99f\";'),(525,'extensionScannerNotAffected','7b13ac9c4bdb0c699cc2c9271f75aa1d','s:32:\"7b13ac9c4bdb0c699cc2c9271f75aa1d\";'),(526,'extensionScannerNotAffected','72e33b0cd5ea51707ee9f2a87a066ebb','s:32:\"72e33b0cd5ea51707ee9f2a87a066ebb\";'),(527,'extensionScannerNotAffected','a2513e917270e1444cb272b38569011c','s:32:\"a2513e917270e1444cb272b38569011c\";'),(528,'extensionScannerNotAffected','c99d2df025ecc1582a7049e9be6e6405','s:32:\"c99d2df025ecc1582a7049e9be6e6405\";'),(529,'extensionScannerNotAffected','f91b97a15f215c9e427638d785caf933','s:32:\"f91b97a15f215c9e427638d785caf933\";'),(530,'extensionScannerNotAffected','ead9f6ff892cd928e4937d19b36272ec','s:32:\"ead9f6ff892cd928e4937d19b36272ec\";'),(531,'extensionScannerNotAffected','e0e6fa9bfc877ecd4b4c21cab0063fc3','s:32:\"e0e6fa9bfc877ecd4b4c21cab0063fc3\";'),(532,'extensionScannerNotAffected','7d7372a93db8f0ae259ae77372cfbcd6','s:32:\"7d7372a93db8f0ae259ae77372cfbcd6\";'),(533,'extensionScannerNotAffected','bc81bd413ec79a3bd71c16ea1afd3115','s:32:\"bc81bd413ec79a3bd71c16ea1afd3115\";'),(534,'extensionScannerNotAffected','7131beea634942741f92e9601786da79','s:32:\"7131beea634942741f92e9601786da79\";'),(535,'extensionScannerNotAffected','60b2c243b6ca4e013f444d7e2d62611f','s:32:\"60b2c243b6ca4e013f444d7e2d62611f\";'),(536,'extensionScannerNotAffected','3c18b48efafd3165cff971d467d727a5','s:32:\"3c18b48efafd3165cff971d467d727a5\";'),(537,'extensionScannerNotAffected','849409f5781ae37108ac498323e0b786','s:32:\"849409f5781ae37108ac498323e0b786\";'),(538,'extensionScannerNotAffected','0899a3301413807e5bb8d7431a92b042','s:32:\"0899a3301413807e5bb8d7431a92b042\";'),(539,'extensionScannerNotAffected','3e4178c5b2bcbd76797b85cbb7cb0ecb','s:32:\"3e4178c5b2bcbd76797b85cbb7cb0ecb\";'),(540,'extensionScannerNotAffected','adb5167fdb6a60c96ea7233ccbd0a630','s:32:\"adb5167fdb6a60c96ea7233ccbd0a630\";'),(541,'extensionScannerNotAffected','a3204ad427a5493624561fdca88f3994','s:32:\"a3204ad427a5493624561fdca88f3994\";'),(542,'extensionScannerNotAffected','0638957df2121314be77233a34bd138e','s:32:\"0638957df2121314be77233a34bd138e\";'),(543,'extensionScannerNotAffected','a32ab65f5492301a7bfef920ee30e237','s:32:\"a32ab65f5492301a7bfef920ee30e237\";'),(544,'extensionScannerNotAffected','afce2ed8b41decf309b87a6fba363309','s:32:\"afce2ed8b41decf309b87a6fba363309\";'),(545,'extensionScannerNotAffected','1bcca5208a568bb7d212ab2ba8f53264','s:32:\"1bcca5208a568bb7d212ab2ba8f53264\";'),(546,'extensionScannerNotAffected','116f6fea622aa1d03d3ee1a0aa976765','s:32:\"116f6fea622aa1d03d3ee1a0aa976765\";'),(547,'extensionScannerNotAffected','75c72558f548655ad173eac504ed7c83','s:32:\"75c72558f548655ad173eac504ed7c83\";'),(548,'extensionScannerNotAffected','4521d52bf6b6f35d7aab6ee189f024ac','s:32:\"4521d52bf6b6f35d7aab6ee189f024ac\";'),(549,'extensionScannerNotAffected','1b838cb5afa8a8747d5f8c32197f797f','s:32:\"1b838cb5afa8a8747d5f8c32197f797f\";'),(550,'extensionScannerNotAffected','fc45009fe1064c751abc7f6037173a10','s:32:\"fc45009fe1064c751abc7f6037173a10\";'),(551,'extensionScannerNotAffected','cfcb23aaa05c6c2c9447279702ee60b1','s:32:\"cfcb23aaa05c6c2c9447279702ee60b1\";'),(552,'extensionScannerNotAffected','fdef8b8e54457e6afb6363b0eccf7ba9','s:32:\"fdef8b8e54457e6afb6363b0eccf7ba9\";'),(553,'extensionScannerNotAffected','bb7e90b7b2e103dfc5a434e1d5facd81','s:32:\"bb7e90b7b2e103dfc5a434e1d5facd81\";'),(554,'extensionScannerNotAffected','3de90c68e822c91f0ded139b68bfe482','s:32:\"3de90c68e822c91f0ded139b68bfe482\";'),(555,'extensionScannerNotAffected','a267e0d6dc4a0385543f7a8b8a2a8ebb','s:32:\"a267e0d6dc4a0385543f7a8b8a2a8ebb\";'),(556,'extensionScannerNotAffected','3ffba20946d109ca5f8fcdad0eb7ef9d','s:32:\"3ffba20946d109ca5f8fcdad0eb7ef9d\";'),(557,'extensionScannerNotAffected','6c3cd6027c59bdb765ad671987b71ca1','s:32:\"6c3cd6027c59bdb765ad671987b71ca1\";'),(558,'extensionScannerNotAffected','1d33bcb61f5318f8f76b66dbf246dd1d','s:32:\"1d33bcb61f5318f8f76b66dbf246dd1d\";'),(559,'extensionScannerNotAffected','0293b40f4b6581d5b5f657797e02e880','s:32:\"0293b40f4b6581d5b5f657797e02e880\";'),(560,'extensionScannerNotAffected','2690c3f607b061473e9015f09435fc58','s:32:\"2690c3f607b061473e9015f09435fc58\";'),(561,'extensionScannerNotAffected','2cceb729a693916619e3898a48bb7d7f','s:32:\"2cceb729a693916619e3898a48bb7d7f\";'),(562,'extensionScannerNotAffected','f801ab642054829ee07b7827c6260c1a','s:32:\"f801ab642054829ee07b7827c6260c1a\";'),(563,'extensionScannerNotAffected','3584234aa6609e266b4d9dbb2b86d6ae','s:32:\"3584234aa6609e266b4d9dbb2b86d6ae\";'),(564,'extensionScannerNotAffected','29912aad74ac0ac74b563abfa2691046','s:32:\"29912aad74ac0ac74b563abfa2691046\";'),(565,'extensionScannerNotAffected','4b8eab6dc6925a8361432070110460ff','s:32:\"4b8eab6dc6925a8361432070110460ff\";'),(566,'extensionScannerNotAffected','6f8a563727b06eca78f63f7a4a60e1e5','s:32:\"6f8a563727b06eca78f63f7a4a60e1e5\";'),(567,'extensionScannerNotAffected','82a630b895e10045dcc02537ff1dbc0d','s:32:\"82a630b895e10045dcc02537ff1dbc0d\";'),(568,'extensionScannerNotAffected','7b080cc6b1c75d4f0250d21d0347a5e4','s:32:\"7b080cc6b1c75d4f0250d21d0347a5e4\";'),(569,'extensionScannerNotAffected','b38fed99897122695e3c7a32c8ca3fb6','s:32:\"b38fed99897122695e3c7a32c8ca3fb6\";'),(570,'extensionScannerNotAffected','49e9b2afd8c29c002992df010f42ed8f','s:32:\"49e9b2afd8c29c002992df010f42ed8f\";'),(571,'extensionScannerNotAffected','610700d32cc7a4c67695c4628e9d0c68','s:32:\"610700d32cc7a4c67695c4628e9d0c68\";'),(572,'extensionScannerNotAffected','8159e82a48c8a5304dc727db44cf9ccc','s:32:\"8159e82a48c8a5304dc727db44cf9ccc\";'),(573,'extensionScannerNotAffected','c867e41158524f2425306c52f1344f75','s:32:\"c867e41158524f2425306c52f1344f75\";'),(574,'extensionScannerNotAffected','77b498481c54b2bdba2caea86be14528','s:32:\"77b498481c54b2bdba2caea86be14528\";'),(575,'extensionScannerNotAffected','d0d23edf6c292c455044e4b156757bce','s:32:\"d0d23edf6c292c455044e4b156757bce\";'),(576,'extensionScannerNotAffected','73c26732718e840a0c3a13f510f694ec','s:32:\"73c26732718e840a0c3a13f510f694ec\";'),(577,'extensionScannerNotAffected','a53a92fe2d6c98562d32885b77c7c118','s:32:\"a53a92fe2d6c98562d32885b77c7c118\";'),(578,'extensionScannerNotAffected','7068e4f7efdaddea25cbb2d7d7c39994','s:32:\"7068e4f7efdaddea25cbb2d7d7c39994\";'),(579,'extensionScannerNotAffected','1d3586c7e8327fa52cf0d6953eaaf9a9','s:32:\"1d3586c7e8327fa52cf0d6953eaaf9a9\";'),(580,'extensionScannerNotAffected','83fd799b47acc1b01dfc15faf495c6fa','s:32:\"83fd799b47acc1b01dfc15faf495c6fa\";'),(581,'extensionScannerNotAffected','362eee6e56383d6ee4f61bc84a53412e','s:32:\"362eee6e56383d6ee4f61bc84a53412e\";'),(582,'extensionScannerNotAffected','fc0849229ef2b9f0025fc95d61645b4e','s:32:\"fc0849229ef2b9f0025fc95d61645b4e\";'),(583,'extensionScannerNotAffected','d7b642039705d72c6e28a3a0dbcc3128','s:32:\"d7b642039705d72c6e28a3a0dbcc3128\";'),(584,'extensionScannerNotAffected','217b962b55424e8b5905143e5d044a85','s:32:\"217b962b55424e8b5905143e5d044a85\";'),(585,'extensionScannerNotAffected','527f6e433f022b4f9bbfa0696107bba4','s:32:\"527f6e433f022b4f9bbfa0696107bba4\";'),(586,'extensionScannerNotAffected','51dee146d4cd05df5ac931c3e6fc2bcb','s:32:\"51dee146d4cd05df5ac931c3e6fc2bcb\";'),(587,'extensionScannerNotAffected','35a7e9bd2bb88459c1bc9aefe2efff33','s:32:\"35a7e9bd2bb88459c1bc9aefe2efff33\";'),(588,'extensionScannerNotAffected','55f49723ea2532b995d6d9aaebdcbd67','s:32:\"55f49723ea2532b995d6d9aaebdcbd67\";'),(589,'extensionScannerNotAffected','bbfe9546564594ee855a227bc3ee4bc0','s:32:\"bbfe9546564594ee855a227bc3ee4bc0\";'),(590,'extensionScannerNotAffected','b07252d8a7122b98d43cc2a4014d04fb','s:32:\"b07252d8a7122b98d43cc2a4014d04fb\";'),(591,'extensionScannerNotAffected','13e7127f427e0f21e15ffa5b5796bd14','s:32:\"13e7127f427e0f21e15ffa5b5796bd14\";'),(592,'extensionScannerNotAffected','fce695ddf31518b64a70a4db5fc7f2b9','s:32:\"fce695ddf31518b64a70a4db5fc7f2b9\";'),(593,'extensionScannerNotAffected','d057f8afa511161ac29cc64bf69191dc','s:32:\"d057f8afa511161ac29cc64bf69191dc\";'),(594,'extensionScannerNotAffected','644c08fddac592313d084b05773d57a0','s:32:\"644c08fddac592313d084b05773d57a0\";'),(595,'extensionScannerNotAffected','d660c9ab53b9eceb2583ee3d0223edea','s:32:\"d660c9ab53b9eceb2583ee3d0223edea\";'),(596,'extensionScannerNotAffected','c428519a0bdac804eb834fa5f5e48533','s:32:\"c428519a0bdac804eb834fa5f5e48533\";'),(597,'extensionScannerNotAffected','d8ca805203b2e45899537e7780032ff8','s:32:\"d8ca805203b2e45899537e7780032ff8\";'),(598,'extensionScannerNotAffected','2cbeb3b086105df5d4ba831d55802395','s:32:\"2cbeb3b086105df5d4ba831d55802395\";'),(599,'extensionScannerNotAffected','1afb1edc3ae1b1083c09200591d1b929','s:32:\"1afb1edc3ae1b1083c09200591d1b929\";'),(600,'extensionScannerNotAffected','ed983315cf25ac96bd414ffbfed6cf79','s:32:\"ed983315cf25ac96bd414ffbfed6cf79\";'),(601,'extensionScannerNotAffected','335ecc9f4130c3fc4b00e416ae00a608','s:32:\"335ecc9f4130c3fc4b00e416ae00a608\";'),(602,'extensionScannerNotAffected','8242a09071390f9b0eee618057a861ba','s:32:\"8242a09071390f9b0eee618057a861ba\";'),(603,'extensionScannerNotAffected','6fbf1a0bc13c1f883aa587c45a466e4a','s:32:\"6fbf1a0bc13c1f883aa587c45a466e4a\";'),(604,'extensionScannerNotAffected','b9f9b7fd91fee7ac6ec34aeeac8ca018','s:32:\"b9f9b7fd91fee7ac6ec34aeeac8ca018\";'),(605,'extensionScannerNotAffected','38a00c1a79f1521e29c10c43db146e7f','s:32:\"38a00c1a79f1521e29c10c43db146e7f\";'),(606,'extensionScannerNotAffected','533828d0a15378bcdadcff7fe3ad595f','s:32:\"533828d0a15378bcdadcff7fe3ad595f\";'),(607,'extensionScannerNotAffected','7fb6f9460525b3dda81f192a341d39af','s:32:\"7fb6f9460525b3dda81f192a341d39af\";'),(608,'extensionScannerNotAffected','091e5b4094bc3130d41a5582b291912a','s:32:\"091e5b4094bc3130d41a5582b291912a\";'),(609,'extensionScannerNotAffected','f37b07ef576c54a9f4c89c9e5b4025fe','s:32:\"f37b07ef576c54a9f4c89c9e5b4025fe\";'),(610,'extensionScannerNotAffected','e5f98248a9e22264708a39db4329ebc4','s:32:\"e5f98248a9e22264708a39db4329ebc4\";'),(611,'extensionScannerNotAffected','680b0fe8152a292d916e4329e58fcdcc','s:32:\"680b0fe8152a292d916e4329e58fcdcc\";'),(612,'extensionScannerNotAffected','38af711de1842099efa03bb1b1d04a51','s:32:\"38af711de1842099efa03bb1b1d04a51\";'),(613,'extensionScannerNotAffected','367dae17293f842d45930d8b5470cf45','s:32:\"367dae17293f842d45930d8b5470cf45\";'),(614,'extensionScannerNotAffected','22e17d683c48685fc8a7184252fc2485','s:32:\"22e17d683c48685fc8a7184252fc2485\";'),(615,'extensionScannerNotAffected','14be0a015f1bef748eae080c2b57aba7','s:32:\"14be0a015f1bef748eae080c2b57aba7\";'),(616,'extensionScannerNotAffected','e88e9e27dab577f87d38f63c24bfe01d','s:32:\"e88e9e27dab577f87d38f63c24bfe01d\";'),(617,'extensionScannerNotAffected','f92caf92ac4069d38ca1db6c0400a259','s:32:\"f92caf92ac4069d38ca1db6c0400a259\";'),(618,'extensionScannerNotAffected','43ec24ad0c3b73b7aef27e6cba9ce4c7','s:32:\"43ec24ad0c3b73b7aef27e6cba9ce4c7\";'),(619,'extensionScannerNotAffected','54ffc49091b69458321d4b670d5a384d','s:32:\"54ffc49091b69458321d4b670d5a384d\";'),(620,'extensionScannerNotAffected','743f1789098f2c75437e5c3a93e9f5cf','s:32:\"743f1789098f2c75437e5c3a93e9f5cf\";'),(621,'extensionScannerNotAffected','9c4f56051dc7c5ffecf6c0e5ea995028','s:32:\"9c4f56051dc7c5ffecf6c0e5ea995028\";'),(625,'core','formProtectionSessionToken:1','s:64:\"2179dac740b5d629fe0f00ff3b2c168a48294758e6951bc475829299836c43b0\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text DEFAULT NULL,
  `constants` text DEFAULT NULL,
  `config` text DEFAULT NULL,
  `basedOn` tinytext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (2,1,1705996070,1546914508,0,0,0,0,256,NULL,0,'Microtemplate: Root',1,3,'EXT:favicon/Configuration/TypoScript,EXT:advancedtitle/Configuration/TypoScript/,EXT:fluid_styled_content/Configuration/TypoScript/,EXT:paginatedprocessors/Configuration/TypoScript,EXT:pagelist/Configuration/TypoScript/,EXT:containeritems/Configuration/TypoScript,EXT:form/Configuration/TypoScript/,EXT:gallerycontent/Configuration/TypoScript,EXT:youtubevideo/Configuration/TypoScript/,EXT:vimeovideo/Configuration/TypoScript/,EXT:pagelist/Configuration/TypoScript/EventVcal/,EXT:personnel/Configuration/TypoScript/,EXT:iconpack/Configuration/TypoScript/,EXT:microtemplate/Configuration/TypoScript,EXT:microtemplate/Configuration/TypoScript/DarkMode,EXT:microtemplate/Configuration/Extensions/Umami/TypoScript','# domainName = https://microtemplate.t3brightside.com/\r\nfavicon.svgPath = data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'36\' height=\'36\' viewBox=\'0 0 36 36\'%3E%3Cg transform=\'translate(-481 -613)\'%3E%3Cg transform=\'translate(-280 -278)\'%3E%3Cpath d=\'M0,0H36V36H0Z\' transform=\'translate(761 891)\' fill=\'%23bc0000\'/%3E%3C/g%3E%3Crect width=\'22\' height=\'7\' transform=\'translate(488 620)\' fill=\'%23fff\'/%3E%3Crect width=\'9\' height=\'11\' transform=\'translate(488 631)\' fill=\'%23fff\'/%3E%3Crect width=\'9\' height=\'11\' transform=\'translate(501 631)\' fill=\'%23fff\'/%3E%3C/g%3E%3C/svg%3E%0A\r\nfavicon.pngPath = EXT:microtemplate/Resources/Public/Icons/Extension.png\r\ncontainerSection.bgImageQuality = 70\r\nyoutubevideo.cssPriority = 0\r\nmicrotemplate.mobilemenuContentPage = 54\r\nmicrotemplate.socialLinksEnabled = 1\r\nmicrotemplate.twitterUrl = https://twitter.com/t3brightside\r\nmicrotemplate.githubUrl = https://github.com/t3brightside\r\npagelist.forceImageFileFormat = webp\r\ngallerycontent.forceImageFileFormat = webp\r\nyoutubevideo.forceImageFileFormat = webp\r\nvimeovideo.forceImageFileFormat = webp\r\npersonnel.forceImageFileFormat = webp\nmicrotemplate.umami.src = https://stats.t3brightside.com/script.js\nmicrotemplate.umami.data-website-id = 4c368cfe-b0d2-46df-bf77-451f7eda6113\nmicrotemplate.umami.data-domains = microtemplate.t3brightside.com\nmicrotemplate.umami.data-do-not-track = false','','',0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(2048) NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `verify_ssl` int(11) NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`additional_headers`)),
  `identifier` varchar(36) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text DEFAULT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `bodytext` mediumtext DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `records` text DEFAULT NULL,
  `pages` text DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `header_link` varchar(1024) NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) NOT NULL DEFAULT '0',
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `date` int(11) NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext DEFAULT NULL,
  `accessibility_title` varchar(30) NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) NOT NULL DEFAULT '',
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_caption` varchar(255) DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_pagelist_authors` tinytext DEFAULT NULL,
  `tx_pagelist_template` varchar(25) DEFAULT NULL,
  `tx_pagelist_orderby` tinytext DEFAULT NULL,
  `tx_pagelist_disableimages` int(11) NOT NULL DEFAULT 0,
  `tx_pagelist_disableabstract` int(11) NOT NULL DEFAULT 0,
  `tx_pagelist_startfrom` varchar(6) DEFAULT NULL,
  `tx_pagelist_limit` varchar(6) DEFAULT NULL,
  `tx_personnel` tinytext DEFAULT NULL,
  `tx_personnel_template` varchar(25) DEFAULT NULL,
  `tx_personnel_images` int(11) NOT NULL DEFAULT 0,
  `tx_personnel_vcard` int(11) NOT NULL DEFAULT 0,
  `tx_personnel_information` int(11) NOT NULL DEFAULT 0,
  `tx_personnel_orderby` tinytext DEFAULT NULL,
  `tx_personnel_startfrom` varchar(6) DEFAULT NULL,
  `tx_personnel_limit` varchar(6) DEFAULT NULL,
  `tx_pagelist_recursive` int(11) NOT NULL DEFAULT 0,
  `tx_gallerycontent_template` varchar(25) DEFAULT NULL,
  `tx_gallerycontent_cropratio` varchar(25) DEFAULT NULL,
  `tx_gallerycontent_cropratiozoom` varchar(25) DEFAULT NULL,
  `tx_gallerycontent_showtitle` int(11) NOT NULL DEFAULT 0,
  `tx_gallerycontent_showdesc` int(11) NOT NULL DEFAULT 0,
  `tx_gallerycontent_showtitlezoom` int(11) NOT NULL DEFAULT 0,
  `tx_gallerycontent_showdesczoom` int(11) NOT NULL DEFAULT 0,
  `tx_youtubevideo_assets` int(11) NOT NULL DEFAULT 0,
  `tx_youtubevideo_colcount` int(11) NOT NULL DEFAULT 0,
  `tx_youtubevideo_oneatatime` int(11) NOT NULL DEFAULT 0,
  `tx_youtubevideo_titles` int(11) NOT NULL DEFAULT 0,
  `tx_youtubevideo_descriptions` int(11) NOT NULL DEFAULT 0,
  `tx_paginatedprocessors_paginationenabled` int(11) NOT NULL DEFAULT 0,
  `tx_paginatedprocessors_itemsperpage` varchar(6) DEFAULT NULL,
  `tx_paginatedprocessors_pagelinksshown` varchar(6) DEFAULT NULL,
  `tx_paginatedprocessors_urlsegment` varchar(20) DEFAULT NULL,
  `tx_paginatedprocessors_anchor` int(11) NOT NULL DEFAULT 0,
  `tx_paginatedprocessors_anchorid` int(11) NOT NULL DEFAULT 0,
  `tx_container_parent` int(11) NOT NULL DEFAULT 0,
  `tx_containeritems_a_firstopen` int(11) DEFAULT NULL,
  `tx_containeritems_s_aligncontent` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_framepadding` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_fullheight` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_textcolorselect` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_bgcolorselect` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_bgimagewidth` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_bgvideosound` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgvideoclearframe` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgvideoonoloop` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgplacement` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_bgfixed` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgoverlay` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_bgoverlaydark` varchar(25) DEFAULT NULL,
  `tx_containeritems_classes` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_valign` varchar(7) DEFAULT NULL,
  `tx_containeritems_s_bgoverlayfilters` int(11) DEFAULT NULL,
  `tx_containeritems_s_bgoverlayblur` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgoverlaysaturate` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgoverlayhue` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgoverlaybrightness` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgoverlaysepia` smallint(6) DEFAULT NULL,
  `tx_containeritems_b_style` varchar(25) DEFAULT NULL,
  `tx_personnel_titlewrap` varchar(2) DEFAULT NULL,
  `tx_pagelist_titlewrap` varchar(12) DEFAULT NULL,
  `tx_containeritems_siema_style` varchar(25) DEFAULT NULL,
  `tx_containeritems_siema_startindex` int(11) DEFAULT NULL,
  `tx_containeritems_siema_loop` int(11) DEFAULT NULL,
  `tx_containeritems_siema_pagination` varchar(25) DEFAULT NULL,
  `tx_containeritems_siema_nav` int(11) DEFAULT NULL,
  `tx_containeritems_customid` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_bgmediaeffect` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_contentwidth` varchar(25) DEFAULT NULL,
  `tx_vimeovideo_assets` int(11) NOT NULL DEFAULT 0,
  `tx_vimeovideo_colcount` int(11) NOT NULL DEFAULT 0,
  `tx_vimeovideo_titles` int(11) NOT NULL DEFAULT 0,
  `tx_vimeovideo_descriptions` int(11) NOT NULL DEFAULT 0,
  `tx_vimeovideo_url` varchar(255) DEFAULT NULL,
  `header_icon` varchar(120) NOT NULL DEFAULT '',
  `tx_containeritems_a_autocollapse` int(11) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `container_parent` (`tx_container_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=379 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (1,'',1,1679829793,1546914883,0,0,0,0,'',520,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','Home','',NULL,0,0,0,0,1,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',0,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\">home</value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">40</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">7</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\">#ffffff</value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n                <field index=\"bgvideobutton\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"overlaycolordarkmode\">\n                    <value index=\"vDEF\">#69008f</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,'left','0',1,'text-light','bg-dark','',0,0,1,'1',0,'','rgba(0,0,0,0.6)','home','bottom',1,14,148,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fade-in','wide',0,0,0,0,NULL,'',NULL,0),(2,'',1,1705996787,1546914897,0,0,0,0,'',521,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<h1><br>Power of TYPO3<br>in a Ready-to-go Package</h1>\r\n<p><a class=\"btn\" href=\"t3://page?uid=1#3\" title=\"Learn more about Microtemplate\">about Microtemplate</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,1,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(3,'',1,1705143368,1546915014,0,0,0,0,'',20992,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','Overview','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0',0,0,0,0,NULL,'bi1,mouse',NULL,0),(4,'',1,1705143401,1546915078,0,0,0,0,'',21248,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','YouTube & Vimeo','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,'center','0',0,'0','bg-black',NULL,0,0,0,'0',1,NULL,NULL,NULL,'center',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','wide',0,0,0,0,NULL,'bi1,camera-video',NULL,0),(5,'',1,1705143508,1546915121,0,0,0,0,'',21504,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','News & Events','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0',0,0,0,0,NULL,'bi1,megaphone',NULL,0),(6,'',1,1705143560,1546915139,0,0,0,0,'',21760,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','People','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,'center','0',0,'0','bg-dark',NULL,0,0,0,'0',0,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','regular',0,0,0,0,NULL,'bi1,person',NULL,0),(7,'',1,1705143591,1546915175,0,0,0,0,'',22016,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','Get Microtemplate','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlaycolordarkmode\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','wide',0,0,0,0,NULL,'bi1,cloud-download',NULL,0),(8,'',1,1706005141,1546915458,0,0,0,0,'',528,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Microtemplate','','<p><strong>is an open source &amp; easy to use TYPO3 website template.</strong><br /><strong>Install it yourself or have it as a fully maintained service.</strong></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,3,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(9,'',1,1678457509,1546915505,0,0,0,0,'',2050,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerColumns-1-1','Features info in 2 columns','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'extra-small','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,3,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(10,'',1,1705996961,1546915539,0,0,0,0,'',2055,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Possibilities','','<p>Automatic menus of languages, page sections or subpages with iconpack support. Endless options to extend on TYPO3 architecture.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,102,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,9,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(13,'',2,1706005779,1546915742,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<h2>Devices</h2>\r\n<p>Template works on mobiles, tablets and desktops. It\'s fully touch friendly.</p>\r\n<h2>Accessibility</h2>\r\n<p>Possible to get around using the keyboard only.</p>\r\n<h2>SEO &amp; META</h2>\r\n<p>Fully prepared for social media and SEO.</p>\r\n<h2>GDPR Friendly</h2>\r\n<p>It does not send cookies or collect user data by default but asks confirmation once it is actually needed.</p>\r\n<h2>Minimal design sub pages</h2>\r\n<p>Subpages are lightbox-like. It gives far greater possibilities for content editing compared to an actual lightbox. It works better on mobile devices and makes content sharing easier. Besides it\'s super nice and clutter-free to read.</p>\r\n<h2>Automatic menus</h2>\r\n<p>Main menu is automatically created of section containers, or first level sup-pages, depending on setup. Language menu shows automatically if translations become available.</p>\r\n<h2>Open Source</h2>\r\n<p>Whole template is fully open source and comes with no warranty what so ever. Still, any request of support is welcome.</p>\r\n<h2>Content examples</h2>\r\n<p>For more content examples go <a href=\"t3://page?uid=1\">back to the page</a>.</p>',0,0,0,0,0,0,10,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',1,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(14,'',2,1546917504,1546915775,0,0,0,0,'',128,0,0,0,0,NULL,0,'a:4:{s:6:\"colPos\";N;s:25:\"tx_gridelements_container\";N;s:23:\"tx_gridelements_columns\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,'header','Microtemplate features','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,5,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(16,'',1,1701863399,1546917717,0,0,0,0,'',21304,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"tx_youtubevideo_assets\":\"\",\"tx_youtubevideo_colcount\":\"\",\"tx_youtubevideo_titles\":\"\",\"tx_youtubevideo_descriptions\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'youtubevideo_pi1','','',NULL,0,0,0,0,1,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,1,0,0,1,0,0,'1','1','video',0,0,332,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(17,'',1,1678873227,1546918590,0,0,0,0,'',2432,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"pages\":\"\",\"tx_pagelist_recursive\":\"\",\"tx_pagelist_orderby\":\"\",\"tx_pagelist_startfrom\":\"\",\"tx_pagelist_limit\":\"\",\"tx_pagelist_template\":\"\",\"tx_pagelist_titlewrap\":\"\",\"tx_pagelist_disableimages\":\"\",\"tx_imagelazyload\":\"\",\"tx_pagelist_disableabstract\":\"\",\"selected_categories\":\"\",\"tx_pagelist_authors\":\"\",\"tx_paginatedprocessors_paginationenabled\":\"\",\"tx_paginatedprocessors_itemsperpage\":\"\",\"tx_paginatedprocessors_pagelinksshown\":\"\",\"tx_paginatedprocessors_urlsegment\":\"\",\"tx_paginatedprocessors_anchor\":\"\",\"tx_paginatedprocessors_anchorid\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'pagelist_sub','Pagelist to show articles','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'small','',NULL,'3',101,'','',0,'100','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','0','','',NULL,124,0,0,0,0,'','cards','pages.sorting',0,1,'','',NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,1,'2','3','pagelist',0,5,5,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'h2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(19,'',1,1679752657,1546921981,0,0,0,0,'',3073,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','People','','<p><strong>Personnell extension&nbsp;</strong>is a tool for creating contacts with vCard download. Besides it connects to Pagelist to use personnel records as authors, contact persons etc.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,6,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(20,'',1,1705742800,1546922012,0,0,0,0,'',3329,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"pages\":\"\",\"tx_personnel_orderby\":\"\",\"tx_personnel_startfrom\":\"\",\"tx_personnel_limit\":\"\",\"tx_personnel_template\":\"\",\"tx_personnel_titlewrap\":\"\",\"tx_personnel_images\":\"\",\"tx_personnel_information\":\"\",\"tx_personnel_vcard\":\"\",\"selected_categories\":\"\",\"tx_paginatedprocessors_paginationenabled\":\"\",\"tx_paginatedprocessors_itemsperpage\":\"\",\"tx_paginatedprocessors_pagelinksshown\":\"\",\"tx_paginatedprocessors_urlsegment\":\"\",\"tx_paginatedprocessors_anchor\":\"\",\"tx_paginatedprocessors_anchorid\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'personnel_frompages','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'medium','',NULL,'6',101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','0','','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,6,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'h2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(21,'',1,1705739208,1546922676,0,0,0,0,'',1538,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Website as a Service','','<p>Fully maintained package with everything prebuilt. Full LTS maintenance in a yearly package and no cost on the template development.</p>\r\n<p><a class=\"btn\" href=\"https://t3brightside.com/typo3-now\">SEE THE PACKAGE</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,31,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(22,'',1,1679752589,1546923013,0,0,0,0,'',2304,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','News & Events','','<p><strong>Pagelist extension</strong> introduces four new page types: articles, events, products, and vacancies. So creating different types of articles is as easy and dynamic as creating a page.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','extra-small',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,5,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(23,'',1,1678613629,1546923849,0,0,0,0,'',22272,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','Footer','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',0,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideobutton\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','wide',0,0,0,0,NULL,'',NULL,0),(24,'',1,1705739321,1546923876,0,0,0,0,'',1568,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p>by:&nbsp;<strong>Brightside OÜ</strong><br /><a href=\"https://t3brightside.com/\"><strong>TYPO3 development &amp; hosting agency</strong></a></p>\r\n<p><a href=\"t3://page?uid=1#329\">Data privacy</a><br />Made in Penghu&nbsp;&amp;&nbsp;Saaremaa &amp;&nbsp;Asunción 2018 - 2024</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,23,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(31,'',1,1639992607,1546940427,0,0,0,0,'',2144,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerColumns-1-1','Use It','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,7,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(32,'',1,1679752600,1546940456,0,0,0,0,'',2112,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','Get Microtemplate','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,7,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(33,'',1,1705739200,1546940509,0,0,0,0,'',1544,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Do it Yourself','','<p>Use \'composer req&nbsp;<strong>t3brightside/microtemplate\'</strong> or get it from TYPO3 repo. Help yourself with the documentation to get going.</p>\r\n<p><a class=\"btn\" href=\"https://github.com/t3brightside/microtemplate\">GitHub</a>&nbsp;<a class=\"btn\" href=\"https://extensions.typo3.org/extension/microtemplate/\">TER</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,102,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,31,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(36,'',7,1679752514,1547008799,0,0,0,0,'',64,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','Time schedule','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(37,'',7,1547010011,1547008808,0,0,0,0,'',128,0,0,0,0,NULL,0,'a:16:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:8:\"bodytext\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;s:25:\"tx_gridelements_container\";N;}',0,0,0,0,'html','Time schedule table','','<table style=\"font-size: 0.8em; margin-top: 1em;\"  align=\"center\">\r\n<tr>\r\n <td>\r\n <td>8:30-9:30\r\n <td>9:30-10:30\r\n <td>10:3-11:30\r\n <td>11:30-12:30\r\n <td>12:30-2:00\r\n <td>2:00-3:00\r\n <td>3:00-4:00\r\n <td  align=\"center\">4:00-5:00\r\n</tr>\r\n<tr>\r\n <td align=\"center\">M\r\n <td align=\"center\">---<td align=\"center\"><font color=\"blue\">SUB1<br>\r\n <td align=\"center\"><font color=\"pink\">SUB2<br>\r\n <td align=\"center\"><font color=\"red\">SUB3<br>\r\n <td rowspan=\"6\"align=\"center\">L<br>U<br>N<br>C<br>H\r\n <td align=\"center\"><font color=\"maroon\">SUB4<br>\r\n <td align=\"center\"><font color=\"brown\">SUB5<br>\r\n <td align=\"center\">class\r\n</tr>\r\n<tr>\r\n <td align=\"center\">T\r\n <td align=\"center\"><font color=\"blue\">SUB1<br>\r\n <td align=\"center\"><font color=\"red\">SUB2<br>\r\n <td align=\"center\"><font color=\"pink\">SUB3<br>\r\n <td align=\"center\">---\r\n <td align=\"center\"><font color=\"orange\">SUB4<BR>\r\n <td align=\"center\"><font color=\"maroon\">SUB5<br>\r\n <td align=\"center\">library\r\n</tr>\r\n<tr>\r\n <td align=\"center\">W\r\n <td align=\"center\"><font color=\"pink\">SUB1<br>\r\n <td align=\"center\"><font color=\"orange\">SUB2<BR>\r\n <td align=\"center\"><font color=\"brown\">SWA<br>\r\n <td align=\"center\">---\r\n <td colspan=\"3\" align=\"center\"><font color=\"green\"> lab\r\n</tr>\r\n<tr>\r\n <td align=\"center\">T\r\n <td align=\"center\">SUB1<br>\r\n <td align=\"center\"><font color=\"brown\">SUB2<br>\r\n <td align=\"center\"><font color=\"orange\">SUB3<BR>\r\n <td align=\"center\">---\r\n <td align=\"center\"><font color=\"blue\">SUB4<br>\r\n <td align=\"center\"><font color=\"red\">SUB5<br>\r\n <td align=\"center\">library\r\n</tr>\r\n<tr>\r\n <td align=\"center\">F\r\n <td align=\"center\"><font color=\"orange\">SUB1<BR>\r\n <td align=\"center\"><font color=\"maroon\">SUB2<br>\r\n <td align=\"center\"><font color=\"blue\">SUB3<br>\r\n <td align=\"center\">---\r\n <td align=\"center\"><font color=\"pink\">SUB4<br>\r\n <td align=\"center\"><font color=\"brown\">SUB5<br>\r\n <td align=\"center\">library\r\n</tr>\r\n</table>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(38,'',7,1679752522,1547009124,0,0,0,0,'',384,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Some more...','','<p>Pellentesque in ipsum eget odio condimentum hendrerit sollicitudin vel tortor. Pellentesque diam odio, vulputate in faucibus vel, viverra at arcu. Phasellus sit amet nisl quis massa porttitor ullamcorper non a dolor. Duis lorem turpis, rhoncus in lacus a, commodo posuere sem.</p>\r\n<p>Pellentesque nec malesuada elit. Praesent ipsum massa, aliquam ac dapibus nec, ultrices in nulla. Etiam a ipsum odio. Duis rutrum eros et efficitur vestibulum. Nulla rhoncus, risus sed eleifend sodales, sem orci gravida magna, eget suscipit ex metus in nunc. Cras pharetra fringilla dolor nec finibus. Donec sed metus in ipsum elementum luctus.&nbsp;</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(40,'',7,1679752504,1547010050,0,0,0,0,'',32,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p>Event pages are part of Pagelist extension. Giving you full control over start and end time, vCal download, event location and all the regular features of the page content type.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(78,'',1,1706005311,1548001796,0,0,0,0,'',4112,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p><strong>Did you notice there is no GDPR-cookie-spookie popup?</strong><br />As long as you\'r server is compatible it should be safe to go without.<br />Confirm with your legal department!</p>\r\n<p>There\'s an optional dark mode design – just activate it on on your device.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'medium','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,3,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(80,'',5,1705312562,1551407717,0,0,0,0,'',2076,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_a_firstopen\":\"\",\"tx_containeritems_a_autocollapse\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerAccordion','Accordion','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'extra-small','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(81,'',5,1705142634,1551407746,0,0,0,0,'',2590,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Second element in accordion','','<p>Fusce semper sed magna id semper. Suspendisse non diam tortor. Nullam eget consectetur urna. Curabitur laoreet lacinia lobortis. Vestibulum congue aliquet augue eu tincidunt. Proin et velit non eros laoreet blandit in ut velit. Maecenas porttitor venenatis leo eget malesuada. Lako ta reporio unta nema dscaredo.</p>',0,0,0,0,0,0,17,1,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,80,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'bi1,cart-check',NULL,0),(84,'',5,1705921307,1551408170,0,0,0,0,'',16,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p><strong>This is the Pagelist extension page type of article. It\'s a quick and easy way to build smaller scale news sections and blogs for your site.</strong></p>\r\n<p>Besides news/article pages there are event, vacancy and product types. Design your articles with all the content items at hand from media to forms just like regular pages. Authors and contact persons can be set from Personnel records.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(85,'',5,1706005888,1551760617,0,0,0,0,'',2077,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','First element in accordion can be set open on load','','<p><strong>Yup, simple as this, content elements in accordion container become accordion items.</strong></p>\r\n<p>Mauris fermentum sit amet est eget porta. Nunc accumsan scelerisque felis a posuere. Etiam faucibus sollicitudin tristique. Sed et lectus in nunc convallis rhoncus. Praesent sollicitudin sem mi, non commodo arcu elementum quis. In sit amet nulla tincidunt enim hendrerit dignissim et sed mi. Pellentesque auctor purus justo, ut accumsan libero ultrices non. Ut eu nisi felis. Vivamus ultrices tincidunt condimentum. Mauris condimentum tristique nisi. Mauris porta risus neque, vitae elementum purus vestibulum ac.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,80,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'bi1,mouse3',NULL,0),(89,'',1,1679752270,1559996344,0,0,0,0,'',22208,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','Get in Touch','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',0,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">4</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n                <field index=\"overlaycolordarkmode\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,'0','0',0,'text-light','bg-dark','300',0,0,0,'0',0,'','',NULL,'0',0,31,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0',0,0,0,0,NULL,'',NULL,0),(90,'',1,1679752626,1559996585,0,0,0,0,'',2064,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Send a message','','<p>Drop us a message if you\'d like custom setup or a&nbsp;<a href=\"https://t3brightside.com/typo3-hosting\">hosted package</a>&nbsp;of the Microtemplate. Bugs, feature requests and such, it all happens in <a href=\"https://github.com/t3brightside/microtemplate\">GitHub</a>.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,89,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(91,'',1,1679821022,1559996632,0,0,0,0,'',3592,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"pi_flexform\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'form_formframework','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.persistenceIdentifier\">\n                    <value index=\"vDEF\">1:/form_definitions/contact_us.form.yaml</value>\n                </field>\n                <field index=\"settings.overrideFinishers\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,89,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(124,'',26,1679752537,1568099852,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p>Thank you for getting in touch with us!<br />We will get back to you shortly.<br />&nbsp;</p>\r\n<p><a class=\"btn\" href=\"t3://page?uid=1\">back to the page</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(157,'',1,1705143445,1616346056,0,0,0,0,'',21408,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','Galleries','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">20</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,'center','0',0,'0','bg-light',NULL,0,0,0,'0',0,'','',NULL,'0',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','wide',0,0,0,0,NULL,'bi1,images',NULL,0),(158,'',1,1679749915,1616346184,0,0,0,0,'',21456,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"assets\":\"\",\"tx_gallerycontent_template\":\"\",\"imagecols\":\"\",\"tx_gallerycontent_cropratio\":\"\",\"tx_gallerycontent_showtitle\":\"\",\"tx_gallerycontent_showdesc\":\"\",\"image_zoom\":\"\",\"tx_gallerycontent_cropratiozoom\":\"\",\"tx_gallerycontent_showtitlezoom\":\"\",\"tx_gallerycontent_showdesczoom\":\"\",\"tx_paginatedprocessors_paginationenabled\":\"\",\"tx_paginatedprocessors_itemsperpage\":\"\",\"tx_paginatedprocessors_pagelinksshown\":\"\",\"tx_paginatedprocessors_urlsegment\":\"\",\"tx_paginatedprocessors_anchor\":\"\",\"tx_paginatedprocessors_anchorid\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'gallerycontent','Gallery of Roads','',NULL,0,0,0,4,0,0,0,4,0,0,0,'default',0,'','extra-small',NULL,NULL,101,'','',1,'100','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','tower','none',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,157,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(159,'',1,1679752575,1616346452,0,0,0,0,'',21432,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Galleries','','<p><strong>Gallerycontent extension</strong>&nbsp;is a breeze to create content with. Make it look good with the selection of predefined crop ratios and have a full control over titles and descriptions. Pagination and touch friendly lightbox are included.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','medium',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,157,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(163,'',5,1705734791,1616376872,0,0,0,0,'',1048,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"assets\":\"\",\"tx_gallerycontent_template\":\"\",\"imagecols\":\"\",\"tx_gallerycontent_cropratio\":\"\",\"tx_gallerycontent_showtitle\":\"\",\"tx_gallerycontent_showdesc\":\"\",\"image_zoom\":\"\",\"tx_gallerycontent_cropratiozoom\":\"\",\"tx_gallerycontent_showtitlezoom\":\"\",\"tx_gallerycontent_showdesczoom\":\"\",\"tx_paginatedprocessors_paginationenabled\":\"\",\"tx_paginatedprocessors_itemsperpage\":\"\",\"tx_paginatedprocessors_pagelinksshown\":\"\",\"tx_paginatedprocessors_urlsegment\":\"\",\"tx_paginatedprocessors_anchor\":\"\",\"tx_paginatedprocessors_anchorid\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'gallerycontent','Gallery','',NULL,0,0,0,4,0,0,0,1,0,0,0,'default',0,'small','',NULL,NULL,0,'','',0,'100','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','widescreen','default',0,0,0,0,0,0,0,0,0,1,'1','1','g',1,320,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(164,'',5,1705355914,1616377231,0,0,0,0,'',4975,0,0,0,0,NULL,45,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Column Two','','<p>Pellentesque auctor purus justo, ut accumsan libero ultrices non. Ut eu nisi felis.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',102,'','',0,'3','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,'','0','sorting ASC',0,0,'','','','0',0,0,0,'0','','',0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,166,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(166,'',5,1704828418,1616377231,0,0,0,0,'',4671,0,0,0,0,NULL,43,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerColumns-1-1','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'100','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,'','0','sorting ASC',0,0,'','','','0',0,0,0,'0','','',0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(187,'',1,1705742225,1638849396,0,0,0,0,'',2053,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Content','','<p><strong>Text, galleries, videos, news, events, persons, file downloads, and forms</strong> are all prestyled and ready to go. There\'s containers for slides, accordions, and tabs.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,9,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,NULL,'',NULL,0),(266,'',54,1705006060,1678368286,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p><a class=\"btn\" href=\"t3://page?uid=1#89\">Send us a MESSAGE!</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(267,'',2,1679823717,1678456780,0,0,0,0,'',64,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"assets\":\"\",\"tx_gallerycontent_template\":\"\",\"imagecols\":\"\",\"tx_gallerycontent_cropratio\":\"\",\"tx_gallerycontent_showtitle\":\"\",\"tx_gallerycontent_showdesc\":\"\",\"image_zoom\":\"\",\"tx_gallerycontent_cropratiozoom\":\"\",\"tx_gallerycontent_showtitlezoom\":\"\",\"tx_gallerycontent_showdesczoom\":\"\",\"tx_paginatedprocessors_paginationenabled\":\"\",\"tx_paginatedprocessors_itemsperpage\":\"\",\"tx_paginatedprocessors_pagelinksshown\":\"\",\"tx_paginatedprocessors_urlsegment\":\"\",\"tx_paginatedprocessors_anchor\":\"\",\"tx_paginatedprocessors_anchorid\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'gallerycontent','','',NULL,0,0,0,1,0,0,0,2,0,0,0,'default',0,'medium','',NULL,NULL,0,'','',1,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','none',0,0,0,0,0,0,0,0,0,0,'','','',0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(268,'',2,1705997147,1678466492,0,0,0,0,'',32,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<h2>Speedy &amp; lightweight</h2>\r\n<p>No CSS or JS frameworks used. Embed asset loading on demand gives amazing speed scores!</p>',0,0,0,0,0,0,0,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','none',0,0,0,0,0,0,0,0,0,0,'','','',0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(309,'',1,1679752713,1679029162,0,0,0,0,'',4118,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p><a class=\"btn\" href=\"t3://page?uid=2\" title=\"Edit\">Speed, Devices, SEO &amp; More</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'medium','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,3,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(320,'',5,1679752402,1679397016,0,0,0,0,'',1044,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Another gallery example','','<p>There\'s pagination with anchor setting to keep things in focus. Lightbox JS and CSS is not loaded to your page source if zoom is not activated in gallery.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(321,'',5,1705741440,1679397507,0,0,0,0,'',4157,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Columns','','<p>There\'s plenty to choose from to divide the content and keep it neat. Predefined two and three column layouts and not so difficult to add your own.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(323,'',5,1705088049,1679398251,0,0,0,0,'',4815,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Column one','','<p>Pellentesque auctor purus justo, ut accumsan libero ultrices non. Ut eu nisi felis.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,166,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(324,'',5,1705741405,1679398439,0,0,0,0,'',1050,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','Tabs','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(327,'',11,1679747972,1679747888,0,0,0,0,'',128,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p><strong>Requested page was not found…</strong><br />&nbsp;</p>\r\n<p><a class=\"btn\" href=\"t3://page?uid=1\">Go to main page</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(329,NULL,1,1701851485,1701851474,0,0,0,0,'',4,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_customid\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerPopup','Data Privacy Popup','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(330,'',1,1705739373,1701851508,0,0,0,0,'',6,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Data privacy statement','','<p>Effective date: <strong>Nov 1, 2022</strong></p>\r\n<h2>Declaration</h2>\r\n<p>The appropriate point in the sense of data privacy laws is:</p>\r\n<p><strong>Brightside OÜ</strong><br />Suure-Anno, Hänga<br />Saaremaa 9311<br />Estonia</p>\r\n<h2>What information this website collects and why?</h2>\r\n<h3>Information from website browsers</h3>\r\n<p>The information we collect about all visitors to our website includes the visitor’s browser type, language preference, referring site, additional websites requested, and the date and time of each visitor request.</p>\r\n<p>We collect this information to better understand how our visitors use the website, and to monitor and protect the security of the website.</p>\r\n<p>This data can not be tracked back to you.</p>\r\n<h3>IP addresses</h3>\r\n<p>We collect Internet Protocol (IP) addresses in web server logs.</p>\r\n<p>We do it to address possible attacks and security issues to our servers. Web server logs are not used for any other purpose and have strictly limited access to the qualified personnel only.</p>\r\n<p>We keep collected logs&nbsp;for no longer than 30 days.</p>\r\n<h2>Contacting us and submitting forms</h2>\r\n<p>If you contact us by e-mail or by using the contact form, information provided for you for the purpose of processing the request or order and possible subsequent questions will be stored.</p>\r\n<p>If we receive an e-mail from you we are assuming that we are authorized to respond to your request by e-mail. Otherwise, you must indicate explicitly that a different method of communication must be used.</p>\r\n<h2>Use of cookies</h2>\r\n<h3>The cookies we set</h3>\r\n<p><strong>fe_typo_user</strong> – On subbmiting forms for preventing spam. This is a session cookie and will be removed as you close the web browser.</p>\r\n<h3>Third party cookies</h3>\r\n<p>For loading external media that could send cookies your concent will be asked in advance.</p>\r\n<h2>More Information</h2>\r\n<p>If you looking for more information then you can contact us sending an e-mail at: <a href=\"https://microtemplate.t3brightside.com/#\"><strong>info@t3brightside.com</strong></a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,329,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(331,'',1,1701862953,1701862953,0,0,0,0,'',21280,0,0,0,0,NULL,0,'',0,0,0,0,'text','YouTube & Vimeo','','<p><strong>Youtubevideo &amp; Vimeovideo</strong> extensions&nbsp;integrates videos in a GDPR friendly way – no intrucive popups on page load but just consent after clicking \'play\'. Set custom cover images, titles, and descriptions, and create a fully paginated galleries.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,4,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(332,NULL,1,1705742494,1701862999,0,0,0,0,'',21296,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerColumns-1-1','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'medium','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,4,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(333,'',1,1701863373,1701863361,0,0,0,0,'',21356,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"tx_vimeovideo_assets\":\"\",\"tx_vimeovideo_colcount\":\"\",\"tx_vimeovideo_titles\":\"\",\"tx_vimeovideo_descriptions\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'vimeovideo_pi1','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,102,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,332,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,1,0,1,0,NULL,'',NULL,0),(334,NULL,5,1705142665,1704809019,0,0,0,0,'',3373,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"tx_containeritems_classes\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerGather','Multiple content elements combined','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,80,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'bi1,bug',NULL,0),(335,'',5,1704823725,1704809134,0,0,0,0,'',3765,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'textmedia','','','<p>Using the ‘gather’ container type multiple content elements can be combined into one accordion item.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,334,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(337,'',5,1706005844,1704810384,0,0,0,0,'',3777,0,0,0,0,NULL,163,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"assets\":\"\",\"tx_gallerycontent_template\":\"\",\"tx_imagelazyload\":\"\",\"imagecols\":\"\",\"tx_gallerycontent_cropratio\":\"\",\"tx_gallerycontent_showtitle\":\"\",\"tx_gallerycontent_showdesc\":\"\",\"image_zoom\":\"\",\"tx_gallerycontent_cropratiozoom\":\"\",\"tx_gallerycontent_showtitlezoom\":\"\",\"tx_gallerycontent_showdesczoom\":\"\",\"tx_paginatedprocessors_paginationenabled\":\"\",\"tx_paginatedprocessors_itemsperpage\":\"\",\"tx_paginatedprocessors_pagelinksshown\":\"\",\"tx_paginatedprocessors_urlsegment\":\"\",\"tx_paginatedprocessors_anchor\":\"\",\"tx_paginatedprocessors_anchorid\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'gallerycontent','','',NULL,0,0,0,4,0,0,0,4,0,0,0,'default',0,'extra-small','','','',101,'','',1,'100','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','0','','',NULL,124,0,0,0,0,'','cards','pages.sorting',0,0,'','','','0',0,0,0,'0','','',0,'0','square','none',0,0,0,0,0,0,0,0,0,0,'1','','g0',1,320,334,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,'0',NULL,0,0,0,0,0,'0','0','0','0',NULL,NULL,'0',NULL,NULL,'0','',0,0,0,0,NULL,'',NULL,0),(339,NULL,5,1705741511,1704823821,0,0,0,0,'',1563,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerTabs','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'extra-small','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(346,'',5,1705389318,1704824802,0,0,0,0,'',1691,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'textmedia','Text','','<p><strong>Gathering content into tabs is simple. Just put em into ‘tabs’ container. </strong>Pellentesque auctor purus justo, ut accumsan libero ultrices non. Ut eu nisi felis. Vivamus ultrices tincidunt condimentum. Mauris condimentum tristique nisi. Mauris porta risus neque, vitae elementum purus vestibulum ac.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'100','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,339,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'bi1,text-left',NULL,0),(355,'',5,1706006615,1704829893,0,0,0,0,'',1595,0,0,0,0,NULL,0,'{\"colPos\":\"\",\"sys_language_uid\":\"\",\"tx_container_parent\":\"\"}',0,0,0,0,'youtubevideo_pi1','Video','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'100','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,1,0,0,1,0,0,NULL,NULL,NULL,0,0,339,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'bi1,camera-video',NULL,0),(357,'',5,1706006574,1705044035,0,0,0,0,'',1659,0,0,0,0,NULL,0,'{\"tx_container_parent\":\"\",\"colPos\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,'uploads','Files','',NULL,0,1,0,0,0,0,0,2,0,3,0,'default',0,'','',NULL,NULL,101,'','',0,'100','',1,0,'',1,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,358,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'bi1,cloud-download',NULL,0),(358,NULL,5,1706006574,1705047155,0,0,0,0,'',1627,0,0,0,0,NULL,0,'{\"colPos\":\"\",\"sys_language_uid\":\"\",\"tx_container_parent\":\"\"}',0,0,0,0,'containerGather','Downloads','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,339,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'bi1,cloud-download',NULL,0),(361,'',5,1705069930,1705069922,0,0,0,0,'',2008,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','Accordion','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(367,NULL,1,1705350940,1705313433,0,0,0,0,'',455,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_customid\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerPopup','Popup three','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(368,'',1,1705355882,1705313443,0,0,0,0,'',487,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Popup three','','\r\n<p><strong>Enough for now!</strong></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'1','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,367,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'bi1,heart',NULL,0),(369,NULL,1,1705580042,1705343668,0,0,0,0,'',7,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_customid\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerPopup','Popup one','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,'','0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(370,'',1,1705355827,1705343681,0,0,0,0,'',263,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Popup one','','\r\n<p>Some text and a link to open another popup…</p>\r\n<p><a href=\"t3://page?uid=1#371\">Open one more popup</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'1','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,369,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'bi1,suit-spade',NULL,0),(371,NULL,1,1705580057,1705343701,0,0,0,0,'',391,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_icon\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_customid\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerPopup','Popup two','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(372,'',1,1705386434,1705351047,0,0,0,0,'',423,0,0,0,0,NULL,370,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Popup two','','\r\n<p>Button style link to open another popup.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',101,'','',0,'1','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','0','','',NULL,124,0,0,0,0,'','cards','pages.sorting',0,0,'','','','cards',0,0,0,'0','','',0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,371,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0','',0,0,0,0,NULL,'bi1,suit-club',NULL,0),(373,'',5,1705741392,1705355634,0,0,0,0,'',1049,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Popups','','<p>Popups are simple containers on the page pre-filled with content. Opening one is just a matter of creating a link to it. Multiple popups can be opened on top of each other. It\'s fully keyboard friendly!</p>\r\n<p><a class=\"btn\" href=\"t3://page?uid=1#369\">Open popup</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0),(374,'',1,1705917244,1705386262,0,0,0,0,'',431,0,0,0,0,NULL,163,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"assets\":\"\",\"tx_gallerycontent_template\":\"\",\"imagecols\":\"\",\"tx_gallerycontent_cropratio\":\"\",\"tx_gallerycontent_showtitle\":\"\",\"tx_gallerycontent_showdesc\":\"\",\"image_zoom\":\"\",\"tx_gallerycontent_cropratiozoom\":\"\",\"tx_gallerycontent_showtitlezoom\":\"\",\"tx_gallerycontent_showdesczoom\":\"\",\"tx_paginatedprocessors_paginationenabled\":\"\",\"tx_paginatedprocessors_itemsperpage\":\"\",\"tx_paginatedprocessors_pagelinksshown\":\"\",\"tx_paginatedprocessors_urlsegment\":\"\",\"tx_paginatedprocessors_anchor\":\"\",\"tx_paginatedprocessors_anchorid\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'gallerycontent','Gallery','',NULL,0,0,0,4,0,0,0,4,0,0,0,'default',0,'small','','','',101,'','',0,'100','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','0','','',NULL,124,0,0,0,0,'','cards','pages.sorting',0,0,'','','','0',0,0,0,'0','','',0,'0','portrait','none',0,0,0,0,0,0,0,0,0,0,'1','1','g',1,320,371,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,'0',NULL,0,0,0,0,0,'0','0','0','0',NULL,NULL,'0',NULL,NULL,'0','',0,0,0,0,NULL,'',NULL,0),(375,'',1,1705386459,1705386446,0,0,0,0,'',443,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_icon\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p><a class=\"btn\" href=\"t3://page?uid=1#367\">Open another popup</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'small','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,371,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,NULL,'',NULL,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT 1,
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(11) NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `update_comment` mediumtext DEFAULT NULL,
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_personnel_domain_model_person`
--

DROP TABLE IF EXISTS `tx_personnel_domain_model_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_personnel_domain_model_person` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `firstname` tinytext DEFAULT NULL,
  `lastname` tinytext DEFAULT NULL,
  `profession` tinytext DEFAULT NULL,
  `info` text DEFAULT NULL,
  `phone` tinytext DEFAULT NULL,
  `email` tinytext DEFAULT NULL,
  `images` int(10) unsigned DEFAULT 0,
  `selected_categories` text DEFAULT NULL,
  `linkedin` tinytext DEFAULT NULL,
  `xing` tinytext DEFAULT NULL,
  `responsibility` tinytext DEFAULT NULL,
  `twitter` tinytext DEFAULT NULL,
  `github` tinytext DEFAULT NULL,
  `instagram` tinytext DEFAULT NULL,
  `youtube` tinytext DEFAULT NULL,
  `facebook` tinytext DEFAULT NULL,
  `website` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`sys_language_uid`),
  KEY `parent` (`pid`,`sorting`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_personnel_domain_model_person`
--

LOCK TABLES `tx_personnel_domain_model_person` WRITE;
/*!40000 ALTER TABLE `tx_personnel_domain_model_person` DISABLE KEYS */;
INSERT INTO `tx_personnel_domain_model_person` VALUES (2,6,1679821425,1546922417,0,0,0,0,'',48,0,0,0,NULL,0,'{\"title\":\"\",\"firstname\":\"\",\"lastname\":\"\",\"profession\":\"\",\"responsibility\":\"\",\"phone\":\"\",\"email\":\"\",\"images\":\"\",\"info\":\"\",\"linkedin\":\"\",\"xing\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"sys_language_uid\":\"\",\"selected_categories\":\"\"}',0,0,0,0,'','Lennart','Meri','2nd President of Estonia','','','example@domain.com',1,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,6,1678817249,1546922491,0,0,0,0,'',40,0,0,0,NULL,0,'{\"title\":\"\",\"firstname\":\"\",\"lastname\":\"\",\"profession\":\"\",\"responsibility\":\"\",\"phone\":\"\",\"email\":\"\",\"images\":\"\",\"info\":\"\",\"linkedin\":\"\",\"xing\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"sys_language_uid\":\"\",\"selected_categories\":\"\"}',0,0,0,0,'','Barack','Obama','44th President of the U.S.','','','example@domain.com',1,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,6,1705569587,1678816831,0,0,0,0,'',32,0,0,0,NULL,0,'{\"title\":\"\",\"firstname\":\"\",\"lastname\":\"\",\"profession\":\"\",\"responsibility\":\"\",\"phone\":\"\",\"email\":\"\",\"images\":\"\",\"info\":\"\",\"website\":\"\",\"linkedin\":\"\",\"xing\":\"\",\"twitter\":\"\",\"github\":\"\",\"instagram\":\"\",\"youtube\":\"\",\"facebook\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"sys_language_uid\":\"\",\"selected_categories\":\"\"}',0,0,0,0,'','Tsai','Ing-wen','7th President of Taiwan','','','example@domain.com',1,'0','','','',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tx_personnel_domain_model_person` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-24  8:54:58
