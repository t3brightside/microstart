-- MariaDB dump 10.19  Distrib 10.4.31-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.4.31-MariaDB-1:10.4.31+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` text NOT NULL,
  `icon` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) NOT NULL DEFAULT '',
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(120) NOT NULL DEFAULT '',
  `widgets` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `identifier` (`identifier`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES (1,0,1679746975,1679746975,0,0,0,0,'42665470a9c3895c2d16c053830d9aca01eb8d38',1,'My dashboard','{\"9284cd702261205da755f534caea4ac67aa597c1\":{\"identifier\":\"t3information\"},\"a26e27d5a173032ac7d16539cc132f06f7089b08\":{\"identifier\":\"docGettingStarted\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `non_exclude_fields` text DEFAULT NULL,
  `explicit_allowdeny` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` text DEFAULT NULL,
  `db_mountpoints` text DEFAULT NULL,
  `pagetypes_select` text DEFAULT NULL,
  `tables_select` text DEFAULT NULL,
  `tables_modify` text DEFAULT NULL,
  `groupMods` text DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `subgroup` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` text DEFAULT NULL,
  `mfa_providers` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(255) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `email` varchar(255) NOT NULL DEFAULT '',
  `db_mountpoints` text DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) NOT NULL DEFAULT '',
  `userMods` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `TSconfig` text DEFAULT NULL,
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  `mfa` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1679747327,1546914362,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$dy5vTDhTVTk5dE5lRi5neg$XSX4NN8VmEuCSjto0LWYzcMBoBJFVhU+vHC/aH3TJV4',1,'','default','',NULL,0,'',NULL,'','a:58:{s:14:\"interfaceSetup\";s:0:\"\";s:10:\"moduleData\";a:23:{s:10:\"web_layout\";a:3:{s:8:\"function\";s:1:\"2\";s:8:\"language\";i:0;s:10:\"showHidden\";b:1;}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:4:{s:32:\"37f78eded394840abf86f69fe8a46286\";a:5:{i:0;s:69:\"by:&amp;nbsp;Brightside OÜTYPO3 development &amp;amp; hosting agency\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:24;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B24%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:24;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:99:\"/typo3/module/web/layout?token=3d04a2d4c338b98c279bfe3e4ca747b8800231b2&id=1&#element-tt_content-24\";}s:32:\"f7949cbd88aa56b509fa7bfffa9d0636\";a:5:{i:0;s:19:\"YouTube &amp; Vimeo\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:331;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B331%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:331;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=3d04a2d4c338b98c279bfe3e4ca747b8800231b2&id=1\";}s:32:\"c72d4a5ffd106794d45e5a4a941814ba\";a:5:{i:0;s:19:\"Microtemplate: Root\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:2;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:73:\"/typo3/module/web/ts?token=10e3e4df5d7502900bd55fac104a966fc16786fd&id=1&\";}s:32:\"89d69eba9db95cbbec6ec9fef6ab4ef1\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:332;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B332%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:332;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:100:\"/typo3/module/web/layout?token=3d04a2d4c338b98c279bfe3e4ca747b8800231b2&id=1&#element-tt_content-332\";}}i:1;s:32:\"89d69eba9db95cbbec6ec9fef6ab4ef1\";}s:6:\"web_ts\";a:8:{s:8:\"function\";s:85:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateInformationModuleFunctionController\";s:19:\"constant_editor_cat\";s:7:\"content\";s:15:\"ts_browser_type\";s:5:\"const\";s:16:\"ts_browser_const\";s:1:\"0\";s:19:\"ts_browser_fixedLgd\";s:1:\"1\";s:23:\"ts_browser_showComments\";s:1:\"1\";s:25:\"tsbrowser_depthKeys_const\";a:1:{s:13:\"microtemplate\";i:1;}s:6:\"action\";s:25:\"web_typoscript_infomodify\";}s:9:\"file_list\";a:2:{s:13:\"displayThumbs\";s:1:\"1\";s:15:\"bigControlPanel\";s:1:\"1\";}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:21:\"1:/user_upload/vimeo/\";}s:16:\"opendocs::recent\";a:8:{s:32:\"a3b9454ecc0d182884b26f9c529ddb87\";a:5:{i:0;s:7:\"Youtube\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:4;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=3d04a2d4c338b98c279bfe3e4ca747b8800231b2&id=1#element-tt_content-4\";}s:32:\"89d69eba9db95cbbec6ec9fef6ab4ef1\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:332;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B332%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:332;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:100:\"/typo3/module/web/layout?token=3d04a2d4c338b98c279bfe3e4ca747b8800231b2&id=1&#element-tt_content-332\";}s:32:\"1edd15adf43123aaf034d44a97cf558b\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:16;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B16%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:16;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:99:\"/typo3/module/web/layout?token=3d04a2d4c338b98c279bfe3e4ca747b8800231b2&id=1&#element-tt_content-16\";}s:32:\"2c8bcc2ecdf0e00749212494d97482bf\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:333;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B333%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:333;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=3d04a2d4c338b98c279bfe3e4ca747b8800231b2&id=1&\";}s:32:\"fbbf55c4c23af80e96ddebe5d483b32b\";a:5:{i:0;s:22:\"Data privacy statement\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:330;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B330%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:330;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=3d04a2d4c338b98c279bfe3e4ca747b8800231b2&id=1&\";}s:32:\"f25e7575dd41165044204b151a78a7db\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:329;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Btt_content%5D%5B329%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:329;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:100:\"/typo3/module/web/layout?token=3d04a2d4c338b98c279bfe3e4ca747b8800231b2&id=1&#element-tt_content-329\";}s:32:\"c72d4a5ffd106794d45e5a4a941814ba\";a:5:{i:0;s:19:\"Microtemplate: Root\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:2;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:73:\"/typo3/module/web/ts?token=10e3e4df5d7502900bd55fac104a966fc16786fd&id=1&\";}s:32:\"c312013d83c1a6ad7fec8b36a37ba3c8\";a:4:{i:0;s:4:\"Home\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}s:8:\"web_list\";a:0:{}s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:337:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:3:\"php\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";s:9:\"clipboard\";a:5:{s:6:\"normal\";a:1:{s:4:\"mode\";s:0:\"\";}s:5:\"tab_1\";a:1:{s:4:\"mode\";s:0:\"\";}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:5:\"tab_1\";}s:8:\"web_view\";a:1:{s:6:\"States\";a:1:{s:7:\"current\";a:3:{s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:4:\"1366\";s:5:\"label\";s:8:\"iPad Pro\";}}}s:20:\"system_txschedulerM1\";a:1:{s:8:\"function\";s:9:\"scheduler\";}s:12:\"system_dbint\";a:5:{s:8:\"function\";s:8:\"refindex\";s:8:\"language\";N;s:19:\"constant_editor_cat\";N;s:6:\"search\";s:3:\"raw\";s:22:\"search_query_makeQuery\";s:3:\"all\";}s:13:\"system_config\";a:2:{s:4:\"tree\";s:8:\"confVars\";s:11:\"regexSearch\";b:0;}s:18:\"list/displayFields\";a:3:{s:5:\"pages\";a:2:{i:0;s:0:\"\";i:1;s:7:\"sorting\";}s:15:\"tx_formvouchers\";a:2:{i:0;s:7:\"voucher\";i:1;s:7:\"is_used\";}s:37:\"tx_formvouchers_domain_model_vouchers\";a:3:{i:0;s:7:\"voucher\";i:1;s:6:\"tstamp\";i:2;s:7:\"is_used\";}}s:9:\"tx_beuser\";a:2:{s:15:\"compareUserList\";a:0:{}s:6:\"demand\";a:5:{s:8:\"userName\";s:0:\"\";s:8:\"userType\";i:0;s:6:\"status\";i:0;s:6:\"logins\";i:0;s:16:\"backendUserGroup\";i:0;}}s:7:\"history\";a:3:{s:8:\"maxSteps\";s:3:\"100\";s:8:\"showDiff\";s:1:\"1\";s:15:\"showSubElements\";s:1:\"1\";}s:28:\"dashboard/current_dashboard/\";s:40:\"42665470a9c3895c2d16c053830d9aca01eb8d38\";s:15:\"system_BelogLog\";a:1:{s:10:\"constraint\";s:337:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:3:\"php\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";}s:21:\"system_BeuserTxBeuser\";a:1:{s:13:\"defaultAction\";s:5:\"index\";}s:17:\"file_FilelistList\";a:5:{s:13:\"displayThumbs\";b:1;s:9:\"clipBoard\";b:1;s:4:\"sort\";s:4:\"file\";s:7:\"reverse\";b:0;s:8:\"viewMode\";s:4:\"list\";}s:29:\"web_typoscript_constanteditor\";a:2:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:2;}s:16:\"selectedCategory\";s:7:\"content\";}s:25:\"web_typoscript_infomodify\";a:1:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:2;}}}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:11:\"startModule\";s:0:\"\";s:8:\"titleLen\";s:2:\"50\";s:8:\"edit_RTE\";i:1;s:20:\"edit_docModuleUpload\";i:1;s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";s:3:\"500\";s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:7:\"default\";s:19:\"firstLoginTimeStamp\";i:1546914370;s:15:\"moduleSessionID\";a:21:{s:10:\"web_layout\";s:40:\"4933cbf9f3ffc81597d11dbcca2b72c006655b1b\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"bf3611c7c8e2ca5054b25e2a8b3565f4d8e11ccb\";s:10:\"FormEngine\";s:40:\"bf3611c7c8e2ca5054b25e2a8b3565f4d8e11ccb\";s:6:\"web_ts\";s:40:\"4933cbf9f3ffc81597d11dbcca2b72c006655b1b\";s:9:\"file_list\";s:32:\"52ff1f65c1cba2e66fea415df93d3bb8\";s:16:\"browse_links.php\";s:40:\"bf3611c7c8e2ca5054b25e2a8b3565f4d8e11ccb\";s:16:\"opendocs::recent\";s:40:\"bf3611c7c8e2ca5054b25e2a8b3565f4d8e11ccb\";s:8:\"web_list\";s:32:\"915e62de633e5aadb08b86a78e4a8ed2\";s:47:\"TYPO3\\CMS\\Belog\\Controller\\BackendLogController\";s:40:\"fadeba90b88117b59327d13f4b810b88f449299e\";s:9:\"clipboard\";s:40:\"f13cb896781437c7ef1d8eac9145c95e3a0cac74\";s:20:\"system_txschedulerM1\";s:32:\"dae1e42614ba664515ee9ab224ead9f9\";s:12:\"system_dbint\";s:40:\"f13cb896781437c7ef1d8eac9145c95e3a0cac74\";s:18:\"list/displayFields\";s:40:\"264e997d607b3a8e5a5691656b5cc5900e509b33\";s:9:\"tx_beuser\";s:40:\"88c3eaa9a32da3688ee413efe73dc6e6723d355f\";s:7:\"history\";s:40:\"da9c26a28c74e4a3c9443c1f84aef1bb6ddea3c6\";s:28:\"dashboard/current_dashboard/\";s:40:\"5df8d7c7ca0f85bd32f91747cb555f0d4c7e5074\";s:15:\"system_BelogLog\";s:40:\"4933cbf9f3ffc81597d11dbcca2b72c006655b1b\";s:21:\"system_BeuserTxBeuser\";s:40:\"4933cbf9f3ffc81597d11dbcca2b72c006655b1b\";s:17:\"file_FilelistList\";s:40:\"4933cbf9f3ffc81597d11dbcca2b72c006655b1b\";s:29:\"web_typoscript_constanteditor\";s:40:\"4933cbf9f3ffc81597d11dbcca2b72c006655b1b\";s:25:\"web_typoscript_infomodify\";s:40:\"4933cbf9f3ffc81597d11dbcca2b72c006655b1b\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:3:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:14:{s:3:\"0_0\";s:1:\"1\";s:3:\"0_1\";s:1:\"1\";s:3:\"0_3\";s:1:\"1\";s:3:\"0_8\";s:1:\"1\";s:4:\"0_13\";s:1:\"1\";s:4:\"0_16\";s:1:\"1\";s:4:\"0_11\";s:1:\"1\";s:4:\"0_31\";s:1:\"1\";s:4:\"0_39\";s:1:\"1\";s:3:\"0_2\";s:1:\"1\";s:4:\"0_43\";s:1:\"1\";s:4:\"0_44\";s:1:\"1\";s:4:\"0_42\";s:1:\"1\";s:4:\"0_49\";s:1:\"1\";}}s:17:\"typo3-module-menu\";a:1:{s:9:\"collapsed\";s:4:\"true\";}s:15:\"FileStorageTree\";a:1:{s:9:\"stateHash\";a:8:{s:10:\"1_59663721\";s:1:\"1\";s:11:\"1_152885149\";s:1:\"1\";s:11:\"1_187737036\";s:1:\"1\";s:10:\"1_29192813\";s:1:\"1\";s:11:\"1_121078957\";s:1:\"1\";s:11:\"1_225696005\";s:1:\"1\";s:11:\"1_251141525\";s:1:\"1\";s:11:\"1_107375831\";s:1:\"1\";}}}}s:11:\"browseTrees\";a:2:{s:6:\"folder\";s:50:\"{\"25218\":{\"62822724\":1,\"14248556\":1,\"68957090\":1}}\";s:11:\"browsePages\";s:5:\"[[1]]\";}s:10:\"inlineView\";s:1577:\"{\"tt_content\":{\"NEW60577c1273235876873405\":{\"sys_file_reference\":[42,43,44,45,46,47,48,49]},\"158\":{\"sys_file_reference\":{\"14\":\"47\",\"48\":\"\"}},\"157\":{\"sys_file_reference\":{\"1\":\"\"}},\"NEW6057f41634eff525068365\":{\"sys_file_reference\":[66,67,68]},\"81\":{\"sys_file_reference\":{\"1\":\"\"}},\"NEW60632bfce2d12259479883\":{\"sys_file_reference\":[74]},\"16\":{\"sys_file_reference\":{\"0\":75,\"1\":\"76\",\"2\":88,\"8\":\"199\",\"10\":\"\"}},\"167\":{\"sys_file_reference\":[78]},\"165\":{\"sys_file_reference\":{\"2\":\"80\"}},\"188\":{\"sys_file_reference\":{\"8\":\"\"}},\"1\":{\"sys_file_reference\":{\"6\":\"\"}},\"102\":{\"sys_file_reference\":{\"1\":\"135\"}},\"4\":{\"sys_file_reference\":[138]},\"13\":{\"sys_file_reference\":[\"\",149,150]},\"3\":{\"sys_file_reference\":[154]},\"NEW640b37b7d0e27229881503\":{\"sys_file_reference\":[156]},\"267\":{\"sys_file_reference\":{\"1\":\"\"}},\"NEW6413ef522cc90371415456\":{\"sys_file_reference\":[198]},\"163\":{\"sys_file_reference\":{\"9\":\"\"}},\"NEW65705fbcb40e1914303380\":{\"sys_file_reference\":[220]},\"333\":{\"sys_file_reference\":{\"1\":\"\"}}},\"site\":{\"1\":{\"site_language\":[\"0\",\"1\"],\"site_errorhandling\":[\"0\"]}},\"pages\":{\"1\":{\"sys_file_reference\":{\"1\":\"207\"}},\"2\":{\"sys_file_reference\":[]},\"5\":{\"sys_file_reference\":{\"1\":\"\"}},\"7\":{\"sys_file_reference\":[\"\",211]},\"47\":{\"sys_file_reference\":[197]}},\"tx_formpdf_domain_model_htmltemplate\":{\"NEW63413a7411e41052229740\":{\"sys_file_reference\":[141]}},\"tx_formpdf_domain_model_pdftemplate\":{\"NEW63413a815f61e708885424\":{\"sys_file_reference\":[142]}},\"tx_personnel_domain_model_person\":{\"7\":{\"sys_file_reference\":[\"\",218]},\"2\":{\"sys_file_reference\":[\"\",217]},\"3\":{\"sys_file_reference\":[\"5\"]}}}\";s:17:\"systeminformation\";s:45:\"{\"system_BelogLog\":{\"lastAccess\":1679749971}}\";s:10:\"modulemenu\";s:2:\"{}\";s:11:\"tx_recycler\";a:3:{s:14:\"depthSelection\";i:999;s:14:\"tableSelection\";s:0:\"\";s:11:\"resultLimit\";i:25;}s:17:\"tx_formtodatabase\";a:1:{s:8:\"lastView\";a:1:{s:9:\"contactUs\";i:1678953203;}}s:8:\"realName\";s:0:\"\";s:5:\"email\";s:0:\"\";s:8:\"password\";s:0:\"\";s:9:\"password2\";s:0:\"\";s:6:\"avatar\";s:0:\"\";s:25:\"showHiddenFilesAndFolders\";i:0;s:10:\"copyLevels\";s:0:\"\";s:15:\"recursiveDelete\";i:1;s:18:\"resetConfiguration\";s:0:\"\";s:42:\"dragAndDropHideNewElementWizardInfoOverlay\";i:0;s:17:\"hideColumnHeaders\";i:0;s:18:\"hideContentPreview\";i:0;s:19:\"showGridInformation\";i:0;s:19:\"disableDragInWizard\";i:0;s:25:\"disableCopyFromPageButton\";i:0;s:10:\"navigation\";a:1:{s:5:\"width\";s:3:\"300\";}s:6:\"beuser\";a:1:{s:13:\"defaultAction\";s:5:\"index\";}s:21:\"recentSwitchedToUsers\";a:0:{}s:12:\"mfaProviders\";s:0:\"\";s:18:\"backendTitleFormat\";s:10:\"titleFirst\";s:21:\"tx_enhancedbackend_uc\";s:0:\"\";s:12:\"enba-presets\";s:4:\"none\";s:26:\"enba-global__enhancedIcons\";i:0;s:25:\"enba-global__enhancedFont\";i:0;s:31:\"enba-global__enhancedScrollbars\";i:0;s:24:\"enba-topbar__customTitle\";s:0:\"\";s:33:\"enba-topbar__enhancedSearchWidget\";i:0;s:32:\"enba-topbar__enhancedWidgetOrder\";i:0;s:36:\"enba-sidebar__collapseButtonPosition\";i:0;s:28:\"enba-sidebar__enhancedMenuUI\";i:0;s:32:\"enba-pageTree__enhancedToolbarUI\";i:0;s:33:\"enba-pageTree__enabledContentTree\";i:0;s:36:\"enba-contentArea__enhancedOverviewUI\";i:0;s:33:\"enba-contentArea__enhancedToolbar\";i:0;s:37:\"enba-contentArea__enhancedEditingForm\";i:0;s:42:\"enba-contentElementWizard__enhancedToolbar\";i:0;s:37:\"enba-contentElementWizard__enhancedUI\";i:0;}',NULL,NULL,1,NULL,1701863583,0,NULL,'',NULL),(5,0,1679749610,1679749610,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$L3F0c01xSHRPNzBta3JDbg$rfRlZaRf2eGXogySwzq98eZNZ+YX5h0mxXBkMLne3gc',1,NULL,'default','',NULL,0,'',NULL,'','a:5:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";}',NULL,NULL,1,NULL,0,0,NULL,'',NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--

LOCK TABLES `cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes` DISABLE KEYS */;
INSERT INTO `cache_imagesizes` VALUES (1,'0ef344ce26a8b6bade52e4e1ddc3a4d176f24188',2145909600,'x�-\�A� Dѻp��\�z�*EX�\�ą\�\�q7\���kWu�n\�\�a\\��\���c��\�H9A\�\�\��K���\�\���\�jg\�Gh�\��P��\��L\��b!p'),(2,'b0e46324ecb074e00b559d8022ba7d226fadef9f',2145909600,'x�-\�K� Eѽ�j����\��$�{g/\'7�	\�\�dHU\�UsjR^������F��\�\�\�MX�\�\"6�f\�..\�nq̇F\�,��kj��\�\�\�\� �'),(3,'225fe0a5872984cec2e76471bf85583ba981233c',2145909600,'x�-\�A� Dѻp��B=\rR\n,\\a\�\�xw!q7y��\�+?��M���}L\�&Q\n�<��nv��΋J@��$�p\�F\�\�X\�\�\�\Z�N��kn�^\�\�\�\�!!'),(4,'5cd0b7cbf356a4ff9abd66e3adfaa50d917d62c9',2145909600,'x�-\�K� Eѽ��DK]M�\�8\�āq\�q\��s\�_�\'6Uz5\��H\�B\�\�%�(\n�\�m	ަHJ4S~{}ۥ\�\�\�1\Z�\���j+\��<�\���!�'),(5,'03704b2726b6e5287e1c87d536503a0f93812ee5',2145909600,'x�-�A� �\�\n�\�k+p\���\�߅\�\�fv2IP�.^LM��uL\�0��\�\�\�19�\�1����w�v�\�LE\�_�\�$��폫�R�\�}\\\���\�'),(6,'e4d2e8997dae4e5b33153dc3e4d452c94e46bbb6',2145909600,'x�-\�K� Eѽ�>m]M�8�āq\�B\�\�\�\�\�1z\Z�­�}LK&�pX\�!ŀ�\�/AQAx�gtv\�n\�\�\�w�>*E�\�~.Zs\�\�a\�\�\� \�'),(7,'2e63f44ce2aefda1307cbec46d64719c610bdb3c',2145909600,'x�-\�K� Eѽ���R�e5U\�g\�Hƽ������B\�\\\�U��Kc�8cTF\0�ye \�Jf���-b\�}�\�\�G\�N-v����&K��?Wk�\�\�\�\��\0\�\� C'),(8,'d2b4fb0206ed175c3cb0762117f91cdba4ae9e06',2145909600,'x�=\�K\n�0Eѽt��\Z\�j\��Zp \�\�\n\�\���<+WS���	b�-s��99\�\'\�mZSBr���\�\�\�\�\�9�5\�\�P	\���ĚK�\�~\0�R!u'),(9,'029a4722e96d027d40dc05584680948f5ae9b5e5',2145909600,'x�-�9� �\��\�5\�\�@�\n�Q��ҭfG���3��hy4q�)A$��\�)�R9!.\�ؙ�h\\\�D�)o_-�_���\�\\�)\�\�\�\�[\�\�}8\�\��\�\"%'),(10,'e7dd3775e483865f86b436e3fe969671be2225ad',2145909600,'x�-�A� �\��B���R8x�ă\�\�B\�m3;���N�T\�^\�1�&MFkQ�f\��\0��ȧ\�9���|3�vq\�wKc\Z�7?���:\�\�,\�6�!'),(11,'21751e9f66e1511dc76a031c6f2ba23a7be40cce',2145909600,'x�-��\r�0w\��1�0\�\������;�D\�t\�tQyN!q=�\�\�c��-���\�%���\n\�DU\�s\0`M8}?|;b+�\�kLar�\�^�\�kLa?/b \�'),(12,'bc6f279b8cf4704e9d3043d3379862fbcf6e1e59',2145909600,'x�-�A� �\��\�\�k@�p\�$�\�߅\�\�fv2QP�K��\Z�j�^�kWFRΔ|\�\�.�D~�>)�B�>��\�л\�>\nM�yr�y\�v\�>@\��\0M�!?'),(13,'bb17db6d6358d8d78728730321d879b2bff4d493',2145909600,'x�-�K� \�\�	�Z>\�4H\�g\�\nƻ���y��\�t\�I\�ث:\�ԤBF���\r�8o(9�\�[\�00\�7\�oW,r7�\��_\���J+u�\�}�Z\"!j'),(14,'9fdca74a41aa522f314585517d4e93d12a6caa67',2145909600,'x�-\�;� Eѽ���\0긚F��\�\�¸w!�{ɹy*,\�)^\\ճ��OWRV-�)�)a�0�g.\�f˰E�\r\r`\�\��v\�nw+WhBa��C��\�k.\�\���!�'),(15,'cc6fb11e62adce047c18f27c82e38d15264a88b0',2145909600,'x�-\�K� Eѽ���>e5U)0p�\�\�E\�\�%\�\�	[�:/l�\�jҜ�FDԃGU��k\0�T�ָ�#K5�=ξR\�\�\�1\Z���Ps+u|B\0\�~\0�O!�'),(16,'7c3b40749f1a17caa296ab77b193ea3b25c258d6',2145909600,'x�-�A� �\�(\�\�5E@8x\�ă\�\�\�\�fv2\�\�\�ɞM���U�e�J�bl!dr\�e\�\�&�]\�PN\��\�\�\�\�\�\�dir�y�c\�\�<���\�;9 \�'),(17,'fb2216b53c322f9a9b6be440c9eed3f6bd9c78d4',2145909600,'x�-�A� �\�\\�\�k\Z\�\�Iƿ��\�\�dT�<�x1U�j☋�;\�F\�����/k�]�\�2L\�o��n��Bf�?���\�.��~\n 0'),(18,'7f2fe0046e89d391a6d3c5776035ca0413bfdc94',2145909600,'x�-�A� �\�Z���Z*p\���\�߅\�\�fv2L��N�ʽ�mL #��Wf\��\'�\�H��U^�EY���\�\�\�\�\�EQh\�b�^��z\�#$\�\�^!{'),(19,'eb96633732d35896edb4d4d8f4684da0ef32fa0d',2145909600,'x�-̻\r�0�\�]2�Y1\�41Ϋ���;ѝ\���(^�]X\\�{uK�\�3��BS�<4d�<y�WeS\��\�\���Œ\�fGhB�@?\�\�J=>��\�~\0��!�'),(21,'750d417f338971b3d4085701f894523adae5e894',2145909600,'x�-�A� �\�\\��\�5�\���&�o�\�\�~N&v&���ω�GR��L�fɐ�\�g`AĮ Zc>�\��\�nz\�B\�\�\����V\�\Z\��\0h\�!6'),(22,'6510133d712ed144fdf6765b8a4a3183de8c7fd5',2145909600,'x�-�9� �\�0�\�\Zs(R��\"\�\�R�\�\�h�4=��γ���$�9ae�<�\�h[\����1ҫ\�\�\�\�\�\�ŭޣ�]d�:~\�\�h}�\�K\�L\�!'),(23,'f804ff6d0ba5f59debec0babd207a3ba8b3be8ec',2145909600,'x�-�K� \�\�	���\�4�\�g\�\nƻ���y�F~\Z�l��b\�1�MtH�@D\�\0��T�\0\�kPX ��\���~�$�w�}*c�۟��\�\�\�\�6\�\�%\� \�'),(24,'6aff7d7e9af6f7495bcd0f1f4fa273417796d698',2145909600,'x�-�A� ��\�6�\�5��p\�\�\�\�I�\nO|Ll�\�Ď�fvV�4\�`�L�k�\��\�)���P�\�\�m�-_-��\�	`�E\�m�\�g�A|^z�!e'),(25,'334e8368c14700b721b4a063b7270d0c30bd8186',2145909600,'x�-�A� �\�Z�\�k�T\�\�	ƿ[o�\�\�?��&��\�&���T4\0%��,1\�E0��CH\�\���\�\�S�{��Э&ǟ7\�G�\�0�\�. �'),(26,'1648ce35c054046ecb495588ca14777ef7093d7d',2145909600,'x�-�A�0��\�1���f��\�\�H����\�\�jv40�\�e������O����|w\�T^�\�I2\n\�ҹ,;Ӂz��\�\�8\�i~\�B3U���F;\�=�Y\�\��\�!�'),(27,'e830dabc8a9112111d934c2940f8616fb3c9e711',2145909600,'x�-�A\n� �\��\���\�&\�\'�J�^�ކ\�a�=�<�ƣ��Вq�\���\"ɳE\\�Tūz4@\�=��_\\\�\�\�\\�\\�\�\�\�\�\�\�B��~B.!5'),(28,'690771001aac23ef10ff3320b1a6c5a809df2cab',2145909600,'x�-\�A� Dѻp�\�\�i\�a\�Jƻ�\�\�$\�g��!q�\�\�9A�\�R���\�֕\�ЫV_��RD\�\�q\�}/��]\�|\�\��Ьom|�~\0�\�!\�'),(29,'c312df19631a16b5342a4965e375cdedd3eaa4c5',2145909600,'x�-\�A� Dѻp\n�\�r\Z@� qa�����\��L+OUC�\�ϩE���\�\�M�M��2�#b\�)GX=̾]\�\�w;\�|h�\���\�vֱdw\�\�0� \�'),(30,'56290b2ce42ec10ff307502354b9f66598161e8d',2145909600,'x�-�I� �\�D\�\�\�0,O�x0�]H�u�*-\��9l��\�\�}Nl\�%\�\ra^]FԼ$Q8\�0A\�)�\�\��R\�n\�\���%\Z\���j+\�\Z�\�\�yq!�'),(31,'e08f67f34502da7f2aa0734e52c7138a56249d74',2145909600,'x�-�A� �\�\nE\�\�\�PA\�\�	ƿ��\�\�d��<M��[1ۘ$\�H�:u�����\�\0�\��x����~�\�\��(TY��۟�\\\�\�\��\��/� \�'),(32,'b0718e250bfec3800a9a8ca23817f6f7b2fe6b14',2145909600,'x�-\�K� Eѽ��򇲚��0p��\�\�\�\�%\�\�Z�t�\ZM�1\�Z)�*p6lER�9G��]&S�\�Af�G\�wږ�\�9:j0A�Ж��\�\�P��+!u'),(33,'3396adce217ffee7b95c30622916e0f3cba49cb5',2145909600,'x�-�K\n� \�\�	j\"�\�4i��EW\n]�޽\n}��\�3ȑi<�I2\�\n`T�\�轜rd(\�R$\"+{\�a\�v\��\�w\�s=t�k[\�_4\��\�m<�\�~��\"'),(34,'a55a0f6fa4b9a21d7470f12106b4cb3e84b26126',2145909600,'x�-\�K� Eѽ�ʧH]MC�0p�\�ޅ\�\�K\�\�c\�\�t\nd*\�j\�9-/�X��KbN�C�\�k\�I#H�z8�z�}��Իɘ�\0�U\�Y\����p\�!�'),(35,'c5e6c6920430a94aa29ab3bc10eed1885a779472',2145909600,'x�-�A� �\��(\�5�-p\�\�߅\�\�fv2�����M+g3˘�\rmQa͒$�\�\�\n��\0�����!\�\�\�\��Q�\�}�F�s �\���I�\�xZ\�Q�!A'),(36,'9a398f2bb828e59a9dc3f55499087532c0481396',2145909600,'x�-\�A� Dѻp�U���B+,\\I\�\�xwѸ�\����\� $S��&�	d���3¢\�8����(󚽖�!���\�v\�m\�M\�V�xhd��\�U\�V�\'�\��j\"8'),(37,'4226636c830b483137f27e7ba208ab3b28341d6d',2145909600,'x�=�9�0��88�yMJ$\n\�\�	�[͌6\�5H�\�at��	$\0B��ת�\�\�.UeC\�\Zc2\0F۷��\�#�rr�\�1\�+\�\'z\�\�\�o\�a%!'),(38,'76e4eb29872072f53ce36a2fe5cb850c86fa90b2',2145909600,'x�5��\r� {��\�\\\rw��#�X\�\� \�\�jv4\�4�GcǚrK��,Y��B0DS09\�꜄\�\�\Z�}��~ƚ��\�*t��o.>\�r�m�\�\�u�!�'),(39,'aaf49e7f6ac2099311e5ff748c6716039834f8ad',2145909600,'x�5��\r�0{q>�;�j\�v@�%D\�	�\�\�h F�C�����uN-\n)\���\�\�\Z\�q���\��Ј\�ſ>M�\�\�\�\�\�.\�\�\�\�[\�[�q?��\"9'),(40,'b88fa62918da7b756845a20e7ac2798e69983bcc',2145909600,'x�-\�K� Eѽ���B]M�\�8\�āq\�q\��s\�=_;#�&{3\��&�R\�H���qZ\�\�|����5r���}ߤ\�\�\�1:[x��д\�v|\��s�!V'),(42,'ca3f27a653d347712d214c978c428d8ff55c52c3',2145909600,'x�5�K� \�\�	(�\�i*a\�Jƻ�\�^\�MF\�>�\�=�Y��b\0�\�m��\�N9/�����\�a�\�\��\�\�=]5�^�\�l���T\�\��\�y,{ \�'),(43,'525fdfb0106f4d39aeec2bd4de272451fb7a3682',2145909600,'x�5��\r�0{q\�?G5��D�D�\�[�l5;\Z�滳aQѫ\�\�$q#�\�\�\���r\�y\r���*[��˗\�o\'J�Z�\�8����xM�\�\�\�0\� \�'),(44,'5ad0eff351fe658e880cf1c69160c41a79e0de31',2145909600,'x�5��\r�0w\�1\�46vH\n�D�@\�N��{ݟN��<r\�RsX��\"7qP\��i�}д�\�i2\�d\��\��r\�\�g�\��\�\�\�\�\�˞\�\��\�\"Z'),(45,'403fefc386b487d8f6a2686043e7bffb3f0f0bfa',2145909600,'x�-\�A� Dѻp��Ԃ\�4�EX�\�ą\�\�q7\����^�]Y]M{uS��\�H\�\�˔�d\n\\�=E\�a!�Q�\�\�c\�ۖV;\�r􇦈_�����0�t?`{ \�'),(46,'489773621b26768f2534d9e2e2b0e1a4f8c581af',2145909600,'x�-\�K� Eѽ�+�ֲ�\��$q`ܻ�0{ɹy*V�KPLի\Z?\�\"��vK��\�\r\�m\�%ĠI\�\n\�\�T�F\�N=\�\�RM\0�\0jnG\�Sȿ��!\�'),(47,'322dd20c577045e6d431276f2162397d4cfe27c1',2145909600,'x�5�A� �\�\n��\�5-�\���$��mf\'\�4\�}R$W�,n\�ȁ`\n��1�	M�k\�\��\�<\r\�w��\�Us\�J�0��xѺ�\�\��(\"�'),(48,'d871d70739cd098a29ec070999cddcecc553cb4b',2145909600,'x�5�9�0��\�qȼƐ\�QP�D��;A�n5;\ZS\�kנ�\�^\�\�\'�|6p\nX\�$�\�ѯ	\�1�h�\�2�\�\�o��-�\�T�^\��h��q?W!c'),(49,'acd5972aec03c547c00d45c8634c053e6ce2f2f9',2145909600,'x�5�K� \�\�	(�z�B�-\\A\�\�xw1\�\�˼\�0Y�:!�ʽ�}NMJ�!\"󺀘\�|�\�d�\�[A�7��\�o�t6�\�ȁy9|��V\����J\Z!)'),(50,'1d359af56d4506ff8aa74ffec081d57c237c4bec',2145909600,'x�-\�A� Dѻp\n�XOSZ,\\A\�\�xw1a7y�B�OÀ�P+\�ӢIk\n\�\�Գc%f]8Z\�\Zi	v\�\�\�a\�\��|\�U�x�\�\�\�0��5�>��\0>t!�'),(51,'a0635ae086831ad48108a73248fd4700d36688fc',2145909600,'x�5�K� \�\�	��POӆ]��ą\�\�B���y�Appw\�\Z\���95(G�\�\�:ІQ���\"�>[�\�^Ҷ|3}9�\�%ŷ��zq\�\�\�R\���\�W1!s'),(52,'0cf5150d457180ddb9d54a8bc0bddef01a441a42',2145909600,'x�-\�A� Dѻp��@9MQ� qa�����\����᧳eU�W\�V�8ț\�\"�B�`L\�\�\"Q)\0\� @��RX=ξ]r\�c>4F\�a�Ps;\�X\�4\�\�U�!'),(53,'3322db2ef7635de8264b18d27694a06726cab1bc',2145909600,'x�-�A� �\�h�\�k� p\��\�߅\�\�fv2*N�&$�h+fӊA\�\"s�\Z\�\�#�N\�ˡ6\�D�d��\�\�a�\�Ҝ\�\Z�(T\�\�\�\�%\�\\�<�\�\�ހ�'),(54,'704731a1162a25b94078b0d143fe35039adde758',2145909600,'x�-\�K� Eѽ�*-��\Z�8\�āq\�B\�\�\�\�\�ev�tF65\�j\�1-���WҰ���Fݑ�E+�d\"\'i\�0�v\�w�k<4�v2�\\��zMGZ\�\r\� \�'),(55,'2a2633ba9fbef0d87b2379d3a210829b792f8e2e',2145909600,'x�-�;� \�\�	\�\�r\Z\n+M,�w�7�\�K\���*jZ:��c���7,X�=-P�?@Ȧ�R\�%;\�\�\�\�\�\���\�z\�r���dL��h�\�\�E �V	 \�'),(56,'faf0cdd8b740bc384866c8546d4554802f08ddfc',2145909600,'x�-̱\r�0D\�]2�mLH\�4\���\n$\n\�\�$\�I\�\�TyNa	E\�\�6Aŉ3\�x�D�9(e3E\�\�5E̽\�\�\�Cw�\�z��*H	:\�\�\�^�.��~c\�!u'),(57,'2815899fde170dbe2a501cf2e6697f36b3a68054',2145909600,'x�-\�K� Eѽ�~V��i�0q`ܻ�8{9�y���M�^\�>�E\�|\�Ī9��@tJ\�g�L+���\�\�\�\�\�IG�[�\�C\�\�Nv?\�ҎzM�\��~^�!�'),(58,'142420e6adcd769fdc6036451df99a699b31c421',2145909600,'x�-�I� \0�\�XZ��\Z�8x�ă\�\�b\�m2�L\"GO\' US�j��I�>�Xϒ\�Y\�3\nN\� \�S\�\��\�ߛٷ+�|7\�\�\�\�f\�[�c�\�\�X �');
/*!40000 ALTER TABLE `cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--

LOCK TABLES `cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES (8,'1_ac10a8d08a86daab8976b893857ffae86a9fa955',1701885108,'x�\��\�r\�F�(�<�0�lJ6\�N�liFV_��\�m�\�\�\�\�P��$8\0�KӊXO;\�<�8�\"\�\��y\�y\�2_r2�����\�^��홆�BUVVVfVfV!\��\�M�\�\�?�\�\�3��ƈJ�d����\�,۲���=xq\�\����\�j>;�w�(3q~؉,��\�\�޽�\�h\�+�\�O�hu\�Y�&���?RU\�ޟ>{�����(\�\� MV\�|9\�W\�\�Y-�\���<.J��5N\�\�\�*�\�H�94S>{\�\�\��\�\�4Δ\�h�ūH�\�er�Q��� \�KQ�x�-\�4^�+\�(Y\�\"e�(#��Sh\�+�4��d-�,Y�A��0�+\��\�\�o��<�L\�7\04^\��lv�i\��\�ϖQ���\��t�����P�\�A�\�\��z³\�_}{\��\�3M\�:H�\�D\Z\�<\�\�MKI&U`�\�\�\n\�\�\�dئ�\�*��Q�*iM�U|�\\Di\�<]L�t\�|�\�\�5+X哵�^&���\�\�T�f\�g�2M�\�a\�\0�E�\�(p\�9�\0��JҎ\�\�\�t\�����j�Q�\���\�?B��P\0K%�\0�\��k��5 �ў\�\�\�U��\�!*�(\n3�\�\�E].�t%\�v��\�a]�|�\��\'&Q\�\Z�^\�&��\�3	��#ޓy�G\\T����W�(~\ZJ��\�|\�\�T�\��Y�x�$�Y\�\�\�Z�Ga\�~�\�u�\Z����;K`i ��3?\�\��\�x\�M\�0ṟEv\�\Z}\��}\�\'�\�?8ɲ�,\�#u�\�3N�� \��l\�uô��\�\�\0\�\0�\�\�,ʦQ� ~\��\�\��g\�?�\�\��\�\�?;\�:\�\�3?c�^\�\�\�\�çLt�\r�\�_&0`u\�Hm�\�<�]�\�$N}5\��\Z]�\�(����\nč��\�\��\n\�\�Ƴ$x3\�\�`��\�\�^7{F\��1&�\�\�\�r��\�f�/�\�\�\��\�v\�U�L&��?��\Z��ٛZ��\�Ӏy\�Ix������5JjOQ4�3\�<M\�ˣ�?�f=E#aKf*��1(�5\�\�>R� \0\����x5�g7${\nUɢ4�ܐ\�|\�\�OG81|���A��d��W��-(\�\��R\�\�h�S�8WW\�r؏\��\�q�Z%s*\"�\Z��\�h�d4\�C`\�HL\�d]�@k\r�\�*�)z\�&�>Uy�,�\r�1\�?��\�+����\�U\�\�M2�\�\�I�\Z\�E��xA�	�Y�1I�Ea�%�\�*\Z\�@\�\�,�����\�r�P�MiX\�	�4\�w\�Аl#\�\�\�j�[k3N�P\�(.#�H8�\n�I��r\�\��)S}x���N�X�\�\�\�\�D�C��g�&D\�]\0 s4H#�\�Q᠂�	��\Z/6@� ^]\�T��,�$\�BE�3%�u*�ɺ��$\r5o\�\0�\�\�\�H���b���h\�R\�\�\�n�x�{	���E˟\\Y}$\�\�h�ύMUQ�`\�^��0�[\�d�\�\�jn\�D���]k\�:ن�\�\�f{Wn�3˶\�\�oi��^K�\Zz\�$���P�yzP��ߪ`���\�\�U%\�F�f:�R�Vٯ\��\�w��3ԜB\�ď\�\�:��\�T\�I\r��`�F\�w�ΆS\\6�:͒t�L\�\ZM\�-��s�75��\�\�T\�F`4q������*e+}�j)�m&\�l6�x2��:klb-Y��\�\"?�5\�KW\ru\�z2io>�\�\�\�ު\�|\�i�c!\�\�X+Rr�\��\�\�Ã&f+=_\�[��6,+�K6s�X��W�NyH����	\\��-�fO\���&�\�:����V�d\\\�6s�T\�\�b:�\n�?\n\�.�tOU�\�<\'\�b��|�@\�}\\\�tBY��c�\�$M\"W��6�ʲ\�\�$��>Z�>⤩��nM]r��,{\�\�!�<M�M\�o6\�e4~���\�@6O\����0W5)��\�j<\�7�1\\\��\0�$3P|\�dT�x!h�\�=��\�\r\�\�(bq�=\�\�3\�\�\����\�\�8���L1h2 \�l&\�\�ۡ\\��d*K,\�f5\�%!\�Ȟ�S\�l�\��\\�0�\Z\�C�u,\Z���\�\�ͅF3R\�\�b\�G�憦´\�-\�60Z�=]�\�\�\�x-\Z0\�n�&sΡ�nG\�0)\�$@�=C\'wHw�\�år�.}����\�\�d�\�H\�\0\�\�m��\�F�q4K.?\��\�mS\�\�\�cFYe.X{\�4�Di\�t��\�h\rQ\�\�o>櫙jԕXz>\�0�Os\��+��\�9��e�����I\�8�����\�ܜ�\�2g,��k\��\��2\�F�\Z\�\�L5G\0��<\�\�d\�\�\�娴�ח\�\�>�/�J\�\0�.\�kf�翯�S21FM�/�UuרX�r��Tq��D�T둀��\���\\I\�X\�&wJy\�Y�	��ʔN(\�\�h\�	`�J\�\�Hv�m\�\�)c���\��!\�U��	�|d\�n�\�CsP\�\�(na��˫�y�,�ٵfy\�UĪٔ2~\�(�!\��!��9-C\�\Z!MV�l\'�\�\�k\��Zm�W\�.~�i�CpΎbhN}f6l\�4�|:yF-M����\�ͪ�!`��6��[r\�n�*���(\�P��\�EE\�c�s?^`���\�1[x�\�\�/Ωo�\�T�q~R�?\�qz⟮\r\��Z̬\�\��\'�=�!\0\�@ݒ�$�\�9�p�;T:>\�u�������{\r/H(\�j\�����2U�k^e��\�;�2//�\��\�\�<\�1J\��Wg\�\\\�\�\0za|\�\��,^�\�aO\�%�:��\��\��\�{\��;n\�D=\�G�\�Q���a\�{\�b�^���^F�o4�ǫ\�O�\�4\�\"(��Pr��\�S\�ՈfO��ѬͫTԥp�\�<qD��(稦~�3P\�\�\�fg`%#՘>��Y\�\�\���F\�\�&\�iO���\�> *���?�E����%�w\�\�>��\�\�Ȇ9���\'�Uv\�VGG�*\\���V�h�Γ�j�]U뜧�5\�\"�\�M�ܖ��\�{�sm\�*\�j0�aun��\�:2\�m*N�f\Z��tߔ<�F�eT\��ȥ��2)�~��\�\�PV�±Jp\�V�Jc\�܊Щ�7v3\�e�4Y�o\�q\�a\�~\�^\�xD d�FA�Ҟ�,$�\��\�ؿ\�y0�ڊ6\�\n74!%\��,K���\�4�ٶa1\�p$\�n%�Q��¯y�\�Y&GR�� �6\0DA\��\�ZM{�p�� \�\�\�J%\�M�\�F~�uM\�\�&\�h�T\�f�p\�| V0�g!\�-�ڔz�\�/tQB�U*�RpM\�\�a�\0J{nt\�\�T\�jz��W�^r6j�V�ydR{nE��\�Z-� c\�cW�!I\�\n�j\r�:\r\0�\�\�\�\�%c��\�a�dR$4\�{��\�XQL�\n�_M,F\�V!#��h̋\�H`\�\�\�-B\\�\�~\�Ѣ���\�٭��b��UI\�e�\�)�J��7����s+Rr�>�����\�\�*���\�\�\���J�\n�\�*�E�\"\�}��\�[�\�F�X�\�Z\�0vZ)b�b��b��uP赱2)b1X]����Z���k-��m�\�\�\��x�Y	<KΓʮ\Zs��>\�\Z�\�v@N����й�u`T�\�\�UC�\�VU�\�Vw\�$�\"Hjg7\�\�\�\�\�>\nþ���=[\\�Ye\�H\�9.\�f�b*\��\�\�Q\�T�Ru\��j\�~\r�\��	f�*��ܶ�\�@�f�\�j�.�:�Z�\�nZ�\'��[�[�\�l�nsm�\��_�\�\�Ƴu\�\n\�6E\�\'\Z�K\��a�e\�?Np{\�\�a*�\��:\�d\�U\Z��f��Ɔ�nz��,n\�\'#Ys�M�\�\�\r.5H�\��Hs\�:wK\��q>�C�<\�I5\��Q]w\ZǳII\�\�f�Y\"\�z��\�K<c�U\�D\�~\�q��2�\�\�Z\�\�\� 5�fv\ZR��dH\�ַ\�\"╇\��\���]\�ث�V�k\�+g\�\�v�	Q�\�\�XH?\�I<��g!n�\�V\�|�:kS३b0d�`[�Ԫy����Eu\�,Z�e3�1\0�僻Cӡ@`\�(h\"ڨ�D�6�e�\�pt���1��%߭�6t\�r]\�~g!\�\�F\�\��eG�\�v�\�㥕�\n:\���\�G�X$\�8U��:O\��F\�8-�8U\��\���~Nc�E\�\��\�j\�(K]Tq\nF\�M�&\�H)Ѳqɋ�Ö\�n�lޓ[$\�nu $ê�W�]r��RаO/aa�f�\0p\�\�zuw�N\�V\�{\�ضr|�F᪃ *h<�[G\�0`b�\��\�#\�\�b_��\�dǶ6a�ݖ(�x�\�\�\�E+4j\��u$C#�\�лK\�`;���\�zQ\�\�\�\�\� \�\\��[o�vo�z�b!w@d\�\�>\�.���b\�t+g�\�bﶽ�Ð��P\�\�\�\�\�\��\�\�\"�\��A�݁T^\�a9(2\�\�\�\�zdDz*bY\�Ш�[i�ENa\�\�?9��\�\�E���mX\�*;��Ex\�X��q5=\�\�\�.�[�j\�M\�ڪ\Zp�\�\�v�����v=�^\�a\�\�X�\��Ih��x��Lf\�簴�\�Ф!P\�\�Q�x1Iz\�o�\�a�Z��>\Z\�P9^P\�\�h��[Æ\�A�e�f\�b\�r��\'@\�CyeUY\�vn�m\�z_ \�H\�0�\�\�\�yZ��m��5\�(\�pJ\�t��\�\�rȻ1&\�j�2���B��\��ʉ>�8b-���\�B�\�\�@EU�\�n�\'��Փ�偔\�1q?���KzZ<�c:UJ\�B�Y�|[�цR	l����\�Z�����\�J\�vǑ���\�~q�gWÜ!R	\�8M\�\�\�ª�\�,<\\;\�.y[�$ m\�\�\�\�cҤ�\"\�\\��\�\�1u��y�\�a�\�\�O9:T(̑M\�4Y⢀/Ўg\�t��\�\��A{�һ{\�^�LY\r\�A<VJ!yV�,�\�\�_�m\�K\�U\�o>/m\�$hr94nhJ�C�b>\�2cQ-v�M\���@*\�٦��߾\�W�\�\����\�\�kX��\�\r�\�@�ְ��Tգ\�\��]\"z\r\�\Z�{�\�٦G-\�~E�6�l\�7����7lz���\��/|%%��\��ݗ*��\�Tۊ)\�\�s���Q�\��)	6\��q���\�� �K߫�Ղ\�	�\�+\0i#\�6$*�Һ�<�\�gh\�6\�KH�g�+�Lh��\�W?Ѐ\��xI\rpDT\���6\�Y`\�t3�~\�a���Rl�\\�e@ Íaq|#7��C�\�,�|5Ô\�W\�oVX\�A\�7e�L\�e0ny\�z\�3�\�\�ZQlA�{�=R\\\�\�}R�\�\'#���\�Al1�ev\�\n�@`�F��\���\�����O\�#�7\�<_y�\�`�ή�� &\�Q�R\�\�r���a\�&(\�C`Z�G\"\�W�0�C\��\�\���\��u�h\�\�\";\�b��\���\�\�v\�҅`H+w�b�k�]�ѕ\�c2�/��îlg�\��\�\'\�C\0{�\�+\�a�x�@�=CQ]\�ڿ��\�\�j\�=Q)���\�\�zOb��-\���C��q\�5o`\�w�\�a\�\�\Zx0�{�����h0���f1�~`\�\�\�\�e�`\��2�A\�0�A��\�э-\�Ĉq2\�N?\�(\�li�!:m�S��~[2\�\�\�0�\�00\�\� \�tg\�4	\"�\���\� \�\�gy��3Ì\"/�/Ж�\�࢒v,\�\�2\���3�<�\�A�\rC�c\�\��+\�\�/1�\�*YS\�ף�o\�~�\�2<�\n�aJ����u\0uv�\"��YiXN��MĬ.>*��t�8<\�\�\�L>j\n�קQ�\0\r\n\�\�i\�\rj�\0\��Ge��9\��kP�F\'WT��k�b�\�\�s\�\�<7��f[=K�ښ\��f\�\�\�N�ۚc��d\��\�g�@55�g��\�\�WVnb[\�=\�\�L�_�G���\�İ����\�	B\���=)\�\r�?�\�ʩ�c�\�7{\�\���yC@�\r^��=�Z�\���A�\rڀ��/\�빚5`Vnj.\0\�5�ϯ\�ش��\�3=\�dV�9=G\�[Xd\��JOT\���X.��\'�\�=�؅!�|X\0߳4\�\�}\�\�6{\�\�\Z\�\ZÜ��\�w^[��\�4��f\�8�����u�kլ�6 <\�ǁY=v�g!�6`V\n\�\0<\�\0\���򾪹V���9\�qpHX\�f>7��f\�4Z􏳅=P�S\�Q�c�9\�х�wL�\�G\�]\�\�dh}/�\n��,��\�PM�\�\�\�!^�\�4y\�\�K3A�Y�]\�\�A�6L\"]��\�8\�.r�Ep�m\0\�]�w�\�\�@.\�E �\�/\�	p�1��@��C\�\�z\�\�\�@�#�P�\�	���\0W\04�_D9̃\�3a4�\�.\�r�e�\�?�\�\n�{=\���a��\0o\�j���l\"k\�\�3x�rf\"=��PO3�Ao�\�\�!b!n��(��\�\�.\\\�l�KP\'�9<v\�s܈�\����o\�#\�4���r0TQ\��{&�\n`�V\�\�$H��\�0��U�)\�\�5�6\�\�Uy뻠�z:I�\�cW��4��0`Vl!Ea\�l\�m҈��\r=��\�cW>q}`��\�\�\�+�7P;����T\r�\n9����v2m\"�\��1({�G\��\�\0@\n��ؕ=\�\0 hfW�>u\�/:r�q_Cuw\�\�\�\�&��59�\0\rf%����\Z�.b\nuP3}d�_D}\�\�BJYV�]�\��g\�GӇ�\\�\n]�BV;�\0tq\�A.�*�\�o5:\��*tO�Bx�r�\�d��}X\�E\�LX\�]s2\"G�\�ıP\Zr\���~ט\�fU��\npY?6\�\�\0Y��=��Y4,\�qR�}v�i�0\�s\\]``M7�\'p��\�.��$�41�\�IjN�i\�(��\'Ȣ&��cLQ �u����ф�w\�\��� \"*C�(@�\�e,�X�s\�.B\'8��\�\Z\�d$4,�*	���q��p~BE\�)��d\�:碤\Zd\'��A\Z\0.���C\�\n�ްUiu-]D\0�Px(�6�#\����\�꣭�\�m�]�*p��\�.\�\Z�}4h�pM���\�Q\�҅? \"\�}�����\�#l\0�\�\"L\'\�u�s�_\�\�\�\�\�n`\�+dњ\�Qp`��\�\�8�O\�\'�f\�+.,KZ�\�\�|�I\�\�\nl��0��]��\0i\�Ċl\�$\�t\�ѽ\0�Lqa�YwQ��8��@\���>�� E\�\�\��_�g�Oopl��&t\'4!]\�\Z��o�\'��\r�\�(�ωj��\�zmXOt¬\�s�\�1�\�	�\�㉩;�I�`��JT�A\�Ce�3l9\�\0U\0סňU\Z�\�m4!Jd\�\0�\��&8�Hdu�9U$�\�0E*NN\�]�YUiV-�Z�]4i���ZH�#\�褨\�L�{.-\�n�H2\�q\\eSSG\�an��Xf^]\'S\�\�5�`�d#p���\r\�o�6�8g0�wUTA���\��\�e?ԗ��.��\�H\�K��G��\�\�\�-\�\\��C\�\�.�\�\�	��0CH),�=Ů~�����2\��\�f���~�A\�\������v\�m\�`��x\���@-\�{B\��\ZPutb\�\�\�\�\�Пe�t%��\�^�\�\�\�g?;\'\�l\�/�HIR%�Z\�n\�j\Z)\��~Fg�;�t\�BV5�>&�,�R��v\��\����ast?�/%�#>+����`�8��\�{��^\�0\��\0[\�\�WV��6\�;��>�<X\�\�\"Jч\��;�\��,.@\�\�@\�9�\�\��\�8R>\�\�ˑ\�:�GI稡�ށ\�\��u��E\'�\�${e����\�\�\�Ɂ}]f���6�sT+�w�ws\�/)yu\��-�\�,�D��@\�;Eq`�n\�,\�{$�&�z�R�/Z�\��p\�z�R\�(n�\�x\�\�T�\���W\�\�W\�W/���!\r�{q\�\�Q\n��\�񔞰\�\n{.��N%�b镫17�u��\�\�\�wZ�\�j\�\��\�\�Վ�\�y%T\�\�(\�\�\�}9dݑB\�ܮ1P`\�@\�ݗC[&\Z\'`��ׁ������\��B��0�\0VT\�2@ǡcjQ��LQ\\�|\��i�\�CY\���h:\"�\���\���\��¦h��N�\�ˍ	�\�`@\�/��a\�\�NV\n�\�P\r���\�B�.�}p�ؕ�\�0D�\�p\�5_\"mZk\�ǧbe��m�\�	�\�\�k\�}\�Za��\��\�F\�\�G\�B�_Ū\�\�J�\�p&\�\�P\'Ă! �0\�\�9��c�00�\r\�Q]t\�`�rp\�w\r\�0`eE\�S��\Z�p�t\�\�ζ��T\�\\\�\�(.\�¨$�X�%4(�\��\�6\�c�a\��\�\�g�\0�7\�\0�f.:\�=\0\�]�\�<p/_n\�)`h\�y�ʞ�PM�l/\r�571`�3@Q\'GM\�����7\r\�\0:��m`\'D�O���c\�\��\���AOq�\�( S�\�Y�F0�>\�&�Ԅ�\�\�o`\0\�OEM00\\�x:\'��ƌ\�-��@�\��0la|\�z\�\�\"\�ǋM�mš�a�\�=\0\�\'\0ӥO4�r\\\n\'��o\ZD$��;�\�30`d��\�x\�\�w�&�hZ�\���0h�\�փU9 ӟ~\�ѕDQ�\�=�\�\�沇\�.\�\�?�/\�P�t��n?]�\�}�N�5\�\�9\�1��\����\�~��\Z��A\�)\�W�V��8^=Y��j�<^M\�\�\�\�ʃ>\��B+܊Jf��+\�XlR4W���`?\�?�t���S�\�\�`�\�\0}HduGܣ\Z5I�0u�0�\�C:\�dP\�@6|\0�f|!d\�~\�x\�C\�����|	\�\"\����]��\�\�\�\0�b�:EU�{xJ��C1t:��\n623<\��6Fmm���0\'\�lD\�\rT\n��(MTЖJP\��y��\�U\���f���d0A\�\0:.P�\�\����8�\�\�\�a\�\�\n@\�9�\�F\�\�.���\�1禧��H��M�\�C��\�\��\'�N��\�A�zt)0��f@!��Njdâ 	�\�\�:\�8��c{�5Б\�~����\�T�^΀\�\0w\�\�\�-�\�!oٌ9�=��+ι?th\�VM\�(c��8	ò�R��\�\�\�(���\��\'P��!��\�\�Z��ѡ���S	o��B�_\�\�3\�\�\��<C��\�-̫\�7E*м��+�ޢ8\�\\�冟��\�@�x~^�R\�Y��4?\�>�X�#�H�\�\��\�J�\�\�ͭ�t�\�sМY\Zܺi��{�\�<^��(=co��\�R�\�qr�^$)�S���a\�z�*\�/��\�\�A\�1v\�+\�<\�Ǖ�\�5-\�ē���\�T\����lπ\�+\�u�\�C�:\�U2�N\�\'\�)\�\�w\Z�\\\�e\�\�A�Qc_m\'D�>K!uH[!\'\�;�J.��~%?\�����qt��\�O!\�ǁhK\Z\�\�\�`��gg�<;��?��t�̓4R�1tV>Y\�9j(l\�\�\'+\�ƺ��iP3�e>����7�w\�\�=��>R�\\Qąj�[�4e!�GY�\Z\�\�e\�:*��oi�P�>\�t�\�\�i�w�ؗ�`\�Z�O\�K\\\�J�W\�zIuʢ\�D\�CnyV\�\�\"\�j��\�/�䗏\�ei\n\"M��L�r��F�*\�\rq\"@�F)\�:��5�ş��b\�P�{��n\�n\�\�Uy`S?C��O<;����\�|\"3�\�\�?�[؀�\�n�\���h6S\�(��B��J4�O�e\�FCT|��>\�3�Hp\�\�0J��r.Bn�O\�l9ZD�P\�>�\�S\�[D\"FR�|v5\�x��2��3\�e\�j\�\�ȁMR�V�V\�=\�i���\'�7hn6O\�\�\��\�\�\�\�ĳ<M�<��\�l&�&�\�%�=��\�\�yX�f\\@�j�_3x8\�u0��@S��\�{\�<��,@q�\�\�*�\�;|\�i\�\�Di\�EQ�%+\� \�\�\�<��bT���\�\�\�G\r6�&\�\�ӑ5ك8D-�,zİF��H�\�^~��$ɛ8RO�\�W����K\�\�8�.\�Q-�nJ�	Va�\�\��\�x<����_\�O\"�%��z&�H#���<\�)|ǀS��Q\n\�V�\�\����;A3\�Z�\'r\�_Dl{!�\Z�Xa�\�Sy,{�֤-}\�+6�)Ē\�hX<\�U\�\�tEaOy@��>|�9\�9���%aK�\�aag\��3\nz�KvK\�\�\�c]X�\�\�\r\�6�߳w}e}E�� =i�a	�z�|\�\�\Zv~�F�\r\�K��\�\�\�\�BeDB��\�\��\�[���~CE���\�Í�7�]\�.n\�u5\��\Z��̖=�Z���\�3&\�\�\�0y	��(~�t�\�\��\�\�c�\�Z\�oo\�0\�=�r�����\�\�Ե\�g\�ب3���\\Y��\0�C�K1\�q�\\.�>���\�e\�\�\�@�_q5|#W�F�\��AnZ�mےț`/k^6\��V\�yN\�\n1gQ\�Ot\��z3\�\�.�~=��X^ge@�\�4\�VE$㰜��mnRkc�5V*=\��\�\�L\n#�\�O\�{�1c/#���b\�j�&Y\�û\�2\0i4\�\�\�|�ʱ\�o\�H\ZL����g\�\��8Be?�h\\�\\	0\�D\�8�&j3f�\�Α�\�{:��\�[�i��n\�ޙ�Ǯ廑���<��(\�\��\�\�ğE��\�T\�H26ٻ�L\�F|@�%\�dR\�J\�?\�(Pu=�Ԫ���b{E\��\�\�P�%\�p�\"|��5u|ޡ\�\�e���6\�\�P�6���\�\0c\�л�18q<��yp�.���Gu�\�Š�\�8\�	��\�\'>�\�+\�\�NNt<0��h��\�IQ\�\�X��\rV\����\0ѡ-<8��mV۸kd�ַ��M�F�\�\�	c�7�\Z�r��FE\0q���Q{\�\�\�>���\�\�e\�\�-���r�mA��,}\�)%\�\�;��}���v_\�@\n����e�Ƙ\�h�C\�\�~��\�\�\�p��<0��\�L��iۭ�М��xQ�9\�o\��^,\�E\�\�\�6I���8SXh�\�~a�Y�Ϡd\�\�ad5vT����} B�j�X\�U\�;>O�\�\�\"�@1u��� Z��م#*ԇ\�O\���kf�5v�b\�z�a���٭h�P5\�\��\��\'��\�v\�SP?�Fʡ���Uك\�4\�`Y֮�\�En-\�j)Uw��\0eG�����d*0��\nT\�\�+v����S��ݜ\"v��\�&v�\�+%\�P?\�n\�\�}\�\�i\�*5\�{��\0�\Z�\n�\�؆Q��\�\�	�B\'{\��\�^\�\�\�@�x��\��Mt=N\�c\�Os��=\�\�t[,�o����\�b�4V�\�}^��&d�\�<��o١\�۟��9q2�\�0��\�1�<\�1;U�mZ\��\�\��\�\��5\�B�Z9u���}\�ީ\��5��\�m�9�\0����\�B�)H>��\�/#�e3�\�6T.p;�8u���\�T��\�<Z5>Y5\�<���ͨ)u|\�\r�����\�j��^\��xJ�\�B���\�I�w��\Z\���\�_\�5��Y\�-�ʪ_\�[v\"h�\�Qy\��\Z\��\�oiw��\'E+ڭQ��o\"ܐ��\�*\�I�}%\�}\�\� ��\�4ZĴS�B����\�vzp\�\0���,ZZ�j\�\�<\�\"S�n�\�\�9�pk%\�~�j�)rj8;o&��Iv\��I�����r���\����9\�^A\0V\�J�\�|��q�\���\�\'�\�\�-	E\�y\"�Ł���+\�B\�C>\�\'1\r\�+\��j4��%�0�r\��U�`\�\�ap�E\��d���y�=v=38NE1�:9?�\�|ʘy\�\�O��\�s`\�H֡�\\�\�{}\�\�\\[\�Lcl\���c\�<o&x�\�\�t:\�Ee;��\�=�\�Qi�{���M\�\�`@\�\�\r\�8\�\�8\Z�vd��x�4F=p|&v\�ݑ߾�\��\�J�\rLkพ:\�x\���\�k͊\�\�\��n���lp\�犃\r\�\�2cfxg\�\����u4\\\rсm��\���ߍ�kYN=\�\�_˩Y,W4�3c0\��0t\�\�u\�\�v;�wJ\�\�? �\�0\�m\�\�pk\�E\�\�Ɂr�8\�Z?\��>G�o5�w\�jo\�\�\�;�\�\�\�^�I\�50x�\�TYD�\�\��$�C��:\0�m��+~\0\�\�G�\�y(�\�\�\�c%a<�D�ܔ�AwJ@�c��\Z\��I\�\�\�\�>\�\�\�\0\�|�Td\�?\�\�\�\�~Ɏ�\�v	.\�S<\n(�\Z\��\�GP�,AO�\Zz~���^��\�\�\��0�3<X\�\�\�1�D1�\�\�啎\�O\�\�u\Z}\0�`�>�R�`�{g�kF�\�xl�IA:�A\�mE\�\�)�\Zv�mFL%\�\n\�\�,\�\�f��A\"ibx\�8�J\�\�m\r;��̉��$�^��~]H�\r��\�%���\"�\�2+�c\�����\�zw�?,!\�W\�$��H~\�,Z,��\�Q\Z�vu��b��r��~<]����\��!yxR,�}\�3��(��~�G����\��|H7���\�\�t�\�d\���r��)��1p�i\�ƥ����\�,�d\�\�\�x6��\���\�\�|�\�)���\�_4�m\�;�ئ\��z\�\�\�#h+��\�N1\�\�	\�\�je�,;�\�k)�¸`\n.71($�J�Ӵb��\�`F\�C�\'�\\\�\�^M,�\�\�tpua\�U�\�܃��kI1}H�\�|`�\�.\�1�U\�hR�;���\�w��\�A�\�\�\"�\�\�\�\�\�dy\�\r��X��4x\�\�賉�\��U�\�p\�jU^S>�V-\�\��F\�ke\�ǒ\���R-T(�\�\�ɘV(t<\�cG&X�/S\�BP�`�>\�V\�\"\����\��\�2X\"�\Z\��xV��*�\�\�C=X�J\�U\�&Z\0�\�N\�d�Ax�v��	P\0:i1+׾\0YHRR���x��y���x\�h��\�K\��R�bz�\�/=\�\�\0\��z\�d\�iiz\�8\Z�\�\��x�\�S�;�\�W\�\�\�s]?�\�OCx�=ǎ^S�\�\�z3\�.�\�\�S:��\�\�,G\�;��S�`�\�T.e�**U91\�\�MW\�W\���\\ʝ)��ȫ\�rD\�(1�\�ת�o\��&I35\�b9\�0\�$&\�s0�\�\�YJaD�\�\�0U۠H�ic�.K\�̿4̿b\��v�7�\�\�\�\�5�Z_\�\�\"\��G	7)\�1�4`\�\��\�\�\��!�>�\�\�\��\�}���\�S$\�&\�_\�߭Ǔ\�\�\ne\�#?e�\���vL**@e\�;\�Y*�\nʑ��\0UʳC��\�>4ɛ�T\�\�я\���M\���o�1��^ߘX�4�\�x\�\�cg`~\�=\�Ű0{\\��\�A�=x�\�0Ձ�iR��Q\�`Yo�^�\�\�`RL�\�\�HO\�\�\\��\��V1m1\��x�G54kf\�\Z\�\�A\�E6lʷ�\�l_@;�\��<���\�1\� <7�y�(I!\�\�t0�9�A;\�2`l\�r.a�`\�L���`\�K�~ۼ02���=h:�\�H�Y\�3\�>�h�*e\�t�_c@I�]Sh��)1D\�\"\�\�\�R\Z��򼊔��G)z�5O�\�1\rK\�\�Ez@�wl\�ȮB-�\\\���c\�J�\'�@b�)�\�\Z�B\�I&m���a�l(\�s�)G��ֱI�?ym��R\�}�\�\0]<̃��\��N�\�S�@fk�\�\�\�arSve\0�� \��\�>\���}�IѠ\\$H��HmJ9�\�4�\�T�r<�~PqBg\�׆N\�B1�\�r�gQf�\�h�\���\�\�Ґ\��2c�e\�0H1���=$/�cA\�휐4+=�̚,M\"��&\�d��Ǧ]f����Ec\�Z^�\��g|\�z�tI���|ʨ\�A\\��y\�Fhy�)\�<\�⌬�\�\��-\�]fS\�<�/{�	P\�\"+\�S9\��R!OI�(y-\�\�d�����\�@O\�M�Q�\�h�R�b��^�\��,dWT̾��L\�b��%r\�1��\�cW�g([%f�\�\�R\�&����9+VR\�\�Šl3�Jv�y\�������v6\��cs\�\��d�\���OǮ^`�\Zt/!�â\�<ݳ\�\�\�Q\�by\�6�B%\�O�|��j؞؞��ٞLh\�Hh>�\�i�ٞ�;\�,w<�\\s\���շ\�IF��\�\�(\n��=��=��=��=��=7��\�\�^e~��\�\�C{�\�\�6\�\�TV�.\�\�\�h\�M\�2.�\�7\�n?p�\��<eL�X���\�\�6|�0;�0;�O3;Qbθ\�|`��\�fv��\�t30ܾ\�\���\� 4�\Z\�uk\�~\��\�\��\�\��\�\��\�\��\�\�\�\�\�\�)�_\�\��ҧg��OϲC&\�xv\�qT\�\�\�K5)Y�M�Z}\�d\�\�9\�\��\�n[z\�\�\�ܴ�,7m��\�\\��(\�ZT4r0��\�\�\�\\Ot�׫)�Y�\�x\r\���`\�٫S\�*Z\��,\�\�u䧔F���\���\�Q>H��\�\�z��n_b\�V\�:)N-K\�\�\�H�k`\�o��\�\"�k\rS\r�u6��h�\�Y靃E��4�\�\�\�\�Çʫ\'��\�\'�z��a���\�S���\� �\�W\�\�\�\�\�y\�\�,R��$4\�\�u�\�\�|2�	0��\��\�-�\')eV�\�d\�S/�\�2є\'ѬH�\\��&�\Z���U\�3��\'�k;0D˧<\�\�ݑ7\�GC�%x\�\�N�T�\Z\�Y\�ya�\�;v�\�\�7\�py��:�||�/!�\�*6�P)���a��b\�W\�Q��\�~\����Ί\�<�n7Tf\�H�\�̢\�z�\"\�pf�~\�T� OuV��\�,�!|���&k\�\�\�\'r��\�XGϿ���i\�\0&��b��e@�P�Ej�v^v1\�\�^�\�2I\�\�\0+\�\" \��3\�\�OWX�b̫��&�\�	(\�\�?z\��o3�\�I\n1���:�\���\��\�\�\�p���EZj\���(\��\�飔D �b~����z\�Z�c_\�^\�[�>��q	G\"\�\��x�\\��`\�\�0\�0)$;���(\��\�ǳ�?k\�S?��\�o\�M޾x�į;~\�\��\�k\�x\�ׇ?\\s#�\�\�`\��w�\�_}i�\�,\�߽���ǯ�ҿ�\�7��?\'\�/��/~~j����\��\�\��J�\�\�\�m\��j\Z}\��ͷ�-~�v��\�\�k�\�ϫ募���\�\�\��\�$>>I� x?L\�O^ς\��\�_%�\0s0��\�\�	=g\09��9Ѓ���?�v\��\�`2�MӲ\�\�w�\�\�\�*]�x�i�\�UeU6,��L;�^�?1��~�l�x\�\�/_�\�X\��\"\�\�c7�P�J!�sk�X\�O#�\�\�\�,X��\��\�\�nn\�㉡��~?4��7��\�n\�c8sb\�s\�\�\�`&/4)f\�\nF\�4\�R���iU^\�\�\"\�[\�.\�\�\�g`���ؤ\�y�b�LW\��`\�G�\�G\�h\�\��;0t&?\��\�:&��j�.�ٜ\�\�C~3;\�7W�\�\�u~e���07\�\�)Q]\�	�t\�e*�u��B��\��\n�\0q\Z���\�\�L�gd��`\�Fj-*\�\'T�\�\Zx�#\�\�\�Z(�n�\�Fq.Ý��x\�Js�\n\':\�,ڝ\���d����Q�S�\�w\0�\�P~w�׻�\�\'LLw��sS\�=\�W�k�\�y��E�sz\r~�W◡\�E�C[k\�\�\�Q\�X��\�y?wK&��þ\�+�~\�\�>�Q�\n~��\�-��\�\�\�\�V�M �%fS�����@\� [�\��\�JX��`\�%\�L���\�\�w2��ո���ݨ�\�����i\�l%\\�jY�;{�\���\�\�1vj\�\��\�\�\�\����\"\�������Zu�o��S\�\�7R���-\�����\�W\�\�B5�17s\�9z\0n�q\�\�\�R9��\"zY\�\0��\�\� �\�[�\�k��\�5\�\�y��\��\Z\�\�SV�&\�\\\rfI	�f��>mO�\�9kk D\�5��\�a\�\�\"Z!ώBۼ\�3\\\�\�K0%\�\�}\Z+�Ѡ�����\�|��Y\�\�qB�m\��|\�\�\�\�y�?�^��\�\���,\�n4O��F�9\��Ȏ\\�\��c�o\�ı�_��)�9\�b\�FT�F�UQ�9��\�\�\r\�\�[n\�\�)�w\�\�\�/\�{��-{^Q?��g\�w�c2�\���\�{�\�S\�.�\'�5���\�d\�D�#MN(�\��T�p\�M\���&g\�\�`&\�	h\�!s�F�\�#v\�h�os�	�7�\ZeI:\\&�l\�\��gI\�fT\�\�X\�S��\�^���k�\Z\���-�\�ց\�$��\�Y%ˡ>µ�J�R\�\�\r�\�ⷠ��oSJ\Z�-\�+���\�Ӕ�\�t����\r�}\��g@ݏ�\ZM�?X\�f#\�?>�\n�5J\�}�Uq\�^�gM.Y�>�\�9��&hz;M����\r\�\�t�Q;��\�7\�ZC�\�h\�\�{��=\��\�\nr�\r\�\�Sf\0}yUFNi@So�V\�̓\0�\�\�\"\�p;D��{�\�c�o7\�\�\"9�l\�P�\�j\�8�=\�dӜW�H\�Ӟ?_�E&\�S\�A˿2\�x2\�\�x�U9�}|\�b�\�(C��Eecy��DǡB�YbEd>͉\�\n�b�\�Q�r�x\�shzi:\�\"C�\'��$y �8\�\�f�fe�8aN\�]\�;��<˳E\�\0�3�;\� [�@&G�n`Ö�܄ڲ\0\�J�]I\�\�\�.á\�M��\�\�.;`^\�\�\�u�\�\�\�>�\'%\�@\�B�\�5�\�2\�E�s$e\�g���k^��4/E\�H�rf%m`\�*G\�2�m\�WyԌ仍]\�M/w��>tYL�8k�z\�8c;^��V}$;�Q�\�F\�d+��/sڻ1\0\�C�\�QMIZ���\�w�=�4\�w��2 Z�+\Z\�\�q\\\�n]i\�\�l\�\��40i\����\�`j7\�nÉ��\�z7w4:�\�.[\�\����G�\�\�\�\�c\rp\'{b��4�M�)\�/�&v�\�\����:,��\�/\�`�]F�\�Z,-\��\�\�7(�	\�2T��\�HÔ��\�G\�o�\�\�W�4B\�\�\�\�\�Z4B+�Y�\�p����4��{\�b��Ff��}k#�\�Ȼ��Sod跶rZ���\�7��}X^C+w�\�\'�\�ƹ\�\�\����%��2��Y0�\�\�Oz\�o��d���ے7U3\rKƯ�\�!7\"v\�`S\"D\�~}�RB\��|�\'\"Ň8�\�\�\�\����uc�\�ڤ�[\�a`\��b-\���G��\�\�O��WC\�\�1�m\�D<`[�\�X�\�\���\�n\�\�\0v��\�\�������ܜ{�m��\�\�\�M�׿CK\�\�\�\�o1\�\�\�ߗ�~Oo��3���w��;�y?��\��\��\�\�\�~UB����\��x\����\�xg\�^֑�\���\��{\��P�a4i\�\��\�\�bܯoxP\�\�k��|�-�\�<�-M\���-Mڼ�-MZ}�-mZ=�-mZ��-m>�\�\�=\�\�÷��w\�\�w�w\�\�w���\�O\�}\�\�H\�T\�m\�\n�G\�\�\�j#HS\��y[\�\�ԼW+�kc��V{��\�$>|�\�b\�.>��\n�\�:i\�\�;5\�\�\�%�\�Q�\�F�E\�j�����m���~�\�h�ߪ9\�\Z�����:���\�FM򯴴JA^�X���W�A��\Z�\�\�\���\�f�A\��\�,|E�Tu;gK�d\�\��\n$\�2,~#\�׫\rg~�bdߔ=�.~I\�v�\�����!�i,\�h��>t�\�\�/j�ួ9=d\�!\�\�	P\�J\�u\��\�\�\�)&��\�{\�$\�\�g@\��\�\�J˴���h���\�Q�^�\��J\�q�6��<K\\8*�d\�6�sxB\�4\�m�AÏ\��2IW�b\� �\�\�E ��\�C\�\�\�L�N^#�8�\��r�cR\�y\��ģd���2^	��%A\�\�(GN��[�3�7� \�\�\�p��͇�_G!�E0����p�=j�f\�������\�gSY\0\�Zn�̢�^\�K\��x,+�D���y��\�ɵ8\�\��R_GTQVaŔ,ꐻ^Z\"(kJ�be�r}�\�\���e�&�V�\�Yx\�\�K�C�\�s�J	i�V������!ͮ\0��\�5��zM\�Bِ	\"4M-�Z�\�\�KT\�	�P\�\�F-xɴ&M\�V��\�l\�\�\�KK���\"-\�YBZ\�\�b�+<�j�F\�\0@�	�\�a8�j\���o\Zksn���i\�I\�\�,Z\�\�՗�x��ǒ\�\��s\��jѬ�Mvr��j \Zu��4f}\�,��/\�,\�h�\�l\�tb�>7a|�]�h\�\�Ei\nk}��X]�H�K��q\�|d\�e�\�\�\�\�\�\�\���a=7�\�s��YW\�\�\�L\�r�����6�6^-6%\�\�s�Q1a�׳�╬\�t\ZW�&�\�\n�B\��ޥ\��H\�~�^�\�J�V\�\�\�\�`\�y�\�\r��C�C\�\"P��E\�\�mCaV/KjE\�\�ͱ�b?\n�N���\�\�r<%\�T\��\n��_r\����6�Z\���=Uc�Az[�m\�g�3Rd\�u:\�\�\"�\�S}~5�RY\�ڽ�O�2��\��\�_�\���_�W\�~~�x�d�\Z?v޾<\r�\�\�7�/b\�\"�B\�\�\"x�l>��\�ڻ~�\��\�\�\�豑�\�\�\�\�\�r<\�_�S=|r\�>�@�`�}�[_.��}\�x\�\�׃~\�\�O�I�\�\�N�s�\�\�\�\�V�\�Y�y=\�\�O�/�>x�\�/\�\�^\���\�|1\���ʠ�\�_=�Z�\���7�\�W_]\��\�ߟ\�_��\�\�\�\�x\�\�\�\�\�ߕ����\�\�W_\�\�\�W\�(�\�\�\�\�\�\�\�x\�ڇ�\�SG߇�G�|\�)E�U��`���l���T��Y�[\�ԑ�V\�\�_Aː\�b�#{0�F���\�O=�8\��$Ġ0I�\�F�S\�p-)M���\"\���P\��*\�\�ͨ\r\�6\n�C\�~T\�~�|�A����\��\�BT^TI%5\�0\�:p���\��w�\�5�\�\"\�l\��1Ŭ\�+�=M�V*l\�g*{��\�G\�*(\�\�\Z\Z�>��\�Y�D�3�D\�/�\�\�LX�g\�6\�\�\�\�\�!�Y�~�.c n�.�+�/0}q��\Z�tA�\�zʀiUyS��\Z���x#�\�\rWM6�3�+[�\�\�O04\�\�6\�炶�*|��\�Qy۲���\�B��\��ӭ�\�\�\���\�\�ꡀRs1�ʵ=�$�:k{��\�E�i^,h��\�u��s�\�Y���{���F͞i\��R\�\�aZ\�\n\�\�O܄��ɉt�\�\�\�,H�hA	�\��}BW_^\�o\�f=lȮ\�\�\���x\�\��\�\���W�gL�=��0�L��M\�\�~\���]O\�\�\�!d\�V\�9T�-U\�\nP�\�#@�\��\�\�d� OA	�\�ӽ�\�,Z)\�\�KЁɥF��	�\�g��#�}N7g\�\�F$\���\�\�z�\���\Zd\�n\�\��es1�Y^�\��\�=ć�\��\��\�\�b\�n�\�!\�4���u\�:o�g\�\n\ns����=14>*�\Z�`<\�{\�\�+UV\�\�\�����\�\�\�^\�R\�ܑ[Ї[\�\�g\�\�\�\�8�D�<\�\�?\�X��\�8�R��=h�\�Qvx�\�w\�$=\�)=��r���N�\Z��`�㬀�8\�߰\�\Z�ΌtB�\�u��@��Ͳ�^�P\�\�\�\�U�*g\�l�˵\�\�\�	�\�\�7� \0\�\�xտ��\����\�$=�\�\��\Z9\�t\"�����S4��`477�@��]���\�\n\���\�\�W�KK\�\�\�\�\�:\�ё�n���pN\�V\�F.iX�|~�١\�n\�4f;|���|[\0dX7Q㩵j�\�\�j�!��0<\�ʙ2�\��O(\�>R4N\�꼖\�S�\�:��\��\�8:^\�O�g��`\�\�G�Y}|\�H�\�7(\�5(\�$I\�\�\�\�#\�7~*2���\�\�9\�U\Z\�ĉ�R%\r֜x�GU��\�\�\�\�\�x\�Cs?�V\�t��j\�d���7\��\�4��\�p\�3L1HU\�\�\�\�^�\'�\��v\�\���k%&�\�\�+K�ށ\�`�~��6F\��XP�x�10}�\�z��\�+\�T␾�~\nSK;�\�\�s@�|�\�+\�a�\�ng�:�\\!\�a�\�\"\0r.��1���ÃQg\�\�<\�\�\�\�9�\�0�\�ԩ�,�kOjE\0\�v��(j�\�3\Z\�>����-\�\�|\��7;�\"�O�Z�m+�o�\'��s\nӏ\�V<\�۽\�\�,oG?�<}\�*��l�����e��\�\��8\��-�\�_z�\��\�ݛ��$[\�\�\�G+@\�`\�}G�\���\�$�\��_~٫\�U�X\�\���\n\�f]3��_Ҵ\�qcK�\�k\"��BZdp\"�\�\�\�L�B\�F\�\�j\�$�+���\�^`��\"\�\�^��9d��k�\�(\�\�M8\�({\'\�\�_\�L�M\�4[��)�\��Qd_\\\�L@X\�\�Ө\�R�*�.#�rB�\�;\�\Z\�F�2|1&,d?|�J\�\�B�z\�\�Z�\�c.Y׵\�x\�i8,��|8,�Ǡ�l1a\�W6\�t�\�7�^w�ɂuK?{P~�iwN��\�<*�J�hn\�I|.�\�_>%@{��H�	5Đ%\'	O����\r\��g\�B�G_\�aI\�	�R��\�6\�(�*\�� Z�E9�\�|ƣ�+\�\�H\'(?\�J��\�cŠ\��ySn��>�<f@\��\���D�˾\�%�J�xR\'\�T\�~��\07�+M���HW*7AԹ��\�����\�\�\����Jh�wI�ܷ��\�\�vdvG�MF-Y�x\�R0\�\�GFɆ}��m^�\�{_�p&7�\�r\�\�e�^�\�\�-�u�_M\�:��\�\�\��\'�|\0Qg\�l\�\r�ݻ\r~U\��L>`@{\�+\n[\�K\�d�Ȩp�f7���Bs�\"���A���h���iI\�U��>h�`f\�8	�5J��\�q@�\�\�D6x}������Iғ�L�\�/QK�V\�r��׀�\�\�\�\�&�E%>!7��HL\�>�s��\�9\n����E5>���\"\�\�f3WU@&�y�^bp^�\�pEG���V^A5\���,\�{�H\�N3_\�\�\�O�\�G�\�\�o\��\�D�iD�P\�\�q� W\�\�~\��\�c��{B<\Z��Q�p��\�\�A�/\����T\�\��F%\�%*\�3�&����\�A|\�ƖhT�\�e�du\�ٔ� ж\�+���\�,��B\�\�!h\�\rzD�\�-\"v#\�\�j\�Zp枮xZ�k\�u?&H�e�\��\�\�\r� \�v���\��}sx9���B:P�V9�\�SX\���C�\�^\�7\�\�\���0Ŏ(m%�̜\�\��\\i}S\�;ܶ�3�\�D�\�6j0W�hux\�\�\�Ɣ�\�va�\�fK�\���\�\',\�Ƽ�Ҍ�Շ\�{v�=zW~k��=\�4�\�\�\�\�\�\����݉A*\�\�!\�\��\n�Q\�\�\�\�o7S[�;Z\�;�k�wS�\�K~�\�d�	\�EV�Z\�\�\�\�G\�	��\�e����\�\� L\�\�\�G�]\0:\�\�\Z\'+7ܯN>�Õdn2])E��˶H\"��lJx�\�i�,�]\�\�\�\�X�h+x>��s�\�A鎋\Z\�\�\�(V`:\�>��\Z��b�Dw��\�C\�\�ߔaܮ�I)\�=\r	z�\�w9\�\��^��ύ|3�m��M��(m�}�\�\�\�K�\�\�\�\Zw\�\���vOt�\�ߦ3�\�UG�a��\���\�O�\�H\�nl�o��)�\�|�/�\�Ϳ���\\�^k\�u6��\�\�\�\�\�\�D\�hԼ�\�xMś{9{�D\�;\�[WRӔJ�U�|�d+�ûJ�s�E\�qӃv�\��\�O)��jP�b=GI\�\�\���\"C�\�\�Lw�\�\�\�$�\�-늜ާ\�Q\��\0\�|	|�\"\�8d\����k\�\�\�\�\��\"\�w��aS�=�FM`o��\�@pbF�&\r�L�\�CU��u�\�٠��L+8��ef,�\�\"Ղ�Xj\�ݓ��\�\�\�̈́�g\�\�]��X\�斍\�7\�5~����\�-e��6\�\�,\�hEV\�ߴ��]%oP�$\�a�#��\�\�\�N�l*�\�\�@�~}\�f1L\�\�\��\�d>,{\���\�\�\���T\��Lr�w\r,�\�-߾\�\�\�J\�\0\�\" ��Oq���k^%�\��\����\��Ea�ǾU\����傄/\�\0����+>���\�\�ݚ�z��P\�ݻS\r\�\�&\'r٭\�P���\�@\��ß��\�\�8\�OS\�\�\�|S]e�\�\�\�|TV��;\�J;�\���{�\�.�Pt\�\�)\�sL�p\�\�s}\�(p\�a\���V�\�`S�;\�k*;~\�K\�!�\�Ǽ��]td����\�P�ѤZ~D\�\��\�\�ǝ�r�ľÚ���\�d\�r��@��8i#��\��,��\�Hŷ\�\�b�@in����9ײNUXԄ��|�y_\�H\�\�P\Z�6�g+�S6\Z\ZA2�\0\�����?���q\'G5~�����\�\�r\�T�\"5;\�?X�S?q�駭�ӢE�}�c#ot\��\�&\�)��\�\��?Az��\�:?\�\�ͽ�|[4L�Q�\�P��F�\Z%강�4_\\\�\�=�\�;χ\0�YoH\'ݚU\���-�m��\�W#!Pm\��R9��\�o\�iW��MIŖZ^\�;�ط�\�\�\�\\��{\���k\�s\�_�<��GS�\"N\�a7�\'\�jڽaNk��g\�O\�se;�:\�WQ�7\�~\�)��{�X�̪\�*�b\�e<\�\�\�rpA��^\�K�1X$�y\��\�<#\�\"�d��\�2�}^��\�\�\�\�\�>^�k\�|�K�x\��+�\�\�\��u�\\�\�JӴ�T��\r	\����\�Lޘ�uІ�o\\�\�H\�5IFFꑩ��Wؿ\��;[\�B���{md]ف�r�O\�aW���yYm�\�\�\�s�\�n\�\�_��-GpA��\�S\�Fd\�+�\�\r�T\���cw�HgZ����k�#�XgTB\�U��\�V�Տ\��XXz\�{۞�?\�\�u��y�JP�J(�\�\��\\4`>\�Qg�\r\rc(�u\�\n\��L{H�]�J#%�\"��\�\�j�z\�D�& �\�}{\�\�\�&�h�S��E\�`\��\�+̱F�aț\�s\�Td`�-xE\�ˆ\�\�����<?�\�	0\�\�^\n���ھ�v\�\�@\�a\'����*܁\�4J$�\�����Q2\�\�?�\�\�\r�\�\"ɛ������f\�%\�I�e<3\\]\��q\�M4y	\�N|E8B\�z�\�c�t\ZD\���o\�Y\�\�\�\�\�\�.\�\�\�	}˭\�܄β�?�__V\�\�\�\�0\�*��\"\��RM\�\�R\�\�_�\�\n\�A��\Zx\�\Z`ڎI��F-b�\04\��}Y\rrX2_\"�\�\�MT<_f���e}��\��J�\Z�\�\�/O�\�\��&���\�7\�x��k�P:\�\�8N\�G�\�\�\�Є>\�[WQ5_E\�\�8\�]�^]��\�!ZĴ2-\�\"(��a5M�K\�\�d\�_^{xDt�\�\�\�\�\��H\�M�r�E?7�\�0S��AT��	�a԰4ˡ�+�\�;�P�#b\�\�7�Q��\�\�\��\�5���\�\�\�K>\'\�\�9)�L�rj|���+\�!�􈒂<]|Q\"�\��\�\�ea\�Q�~\�o@\"$�n\�T�O�$s�I�=\0\�\���w\�3EQ�\��\0ˬ1T\�q�y\\�j\�\�u\�[q\��}�\�\�\n\�\��$Xq5^\�zX+DV\�3Mt�\�\�qa\���؂��<Jc �\�Zy	\�\0\�S,e\�H\�ܐrNA����p<⡎�I\\S��a��~�\�/cDW\�E��%E\r\��\�2�J\rQJeQ3�\�\�:\�o\�_��J# (\�\�T\n�}�S\�,�+\n\0��\�e���<\�%\n\��j�4�\0\r\�\�}���m�L�&o،3*ᔞ�\��+���2Vr/�\�:dˀ#y�\�Wù\�\�\'Tq\�r\�\�\���M�^j\�M\�\��\�\�\�,W\'T��9&<�\�Y6/<Kf�\�\�D\��\�?\�|6\�\�Պ>p��\�\��8�\��^\�A��f\�l�/��f�\�P+[\�J�b�R�aT7lN��q\�(�_\�<\�\�=6�+�\��2\�Z=\�\�|\�L\�if�\0\�O\�3\���\��');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES (8,'1_ac10a8d08a86daab8976b893857ffae86a9fa955','pageId_1');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES (59,'1__0_0_1_1',1704455506,'x�m�Mn\� ��bq�&�\�?��\�]\�H\�]!bH���\�&Js\��퐲\�r>=\�͛�Ӓ�]6�V5=ZS\� \�Ȧ*\�U�\�#%P\�3��(�	~����\� �E�@chuOI��z�e\n^�x%�\�\�bŻ=\�M\�3|`\�\'hE\�.��g\�͏6BrB𥄐&셣x\0\�_\��	\�3\'�l%\�y]ֽ\�n\�\0�m\�:n��\�\�\�\�d\�\�hם5[�#\�\��5f\�t\�{�I�?Zګ\�[��Ӹ�\�\�$����f�B�v���A:��˒U`A�\�\�Bv�\�F,�cYe�Y�x�lp\��\�d�2-��ǘc!n�\�ᧀ\�bওb�s^n\�!\�YU��\n\�\"*\�\��x\�s�\�|��-\�\�'),(60,'1__0_0_0_0',1704455508,'x�m�Mn\� ��bq�&�\�?��\�]\�H\�]!bH���\�&Js\��퐲\�r>=\�͛�Ӓ�]6�V5=ZS\� \�Ȧ*\�U�\�#%P\�3��(�	~����\� �E�@chuOI��z�e\n^�x%�\�\�bŻ=\�M\�3|`\�\'hE\�.��g\�͏6BrB𥄐&셣x\0\�_\��	\�3\'�l%\�y]ֽ\�n\�\0�m\�:n��\�\�\�\�d\�\�hם5[�#\�\��5f\�t\�{�I�?Zګ\�[��Ӹ�\�\�$����f�B�v���A:��˒U`A�\�\�Bv�\�F,�cYe�Y�x�lp\��\�d�2-��ǘc!n�\�ᧀ\�bওb�s^n\�!\�YU��\n\�\"*\�\��x\�s�\�|��-\�\�'),(61,'2__0_0_0_0',1704455508,'x�ݒMn\�0���\0�$\�YVeW�D\�\�2\�@-۲\�D�{\'�A�ʒU�\�e�f\�\�I^\��\��D\�\��KΜVlұS���\�3,�\��\�٘X>\�gHh>Ѐa��D56T��\�$F�\�\�Fn\��3ɲ�EJ\�\�q\�Ƚ�8��\�J�\0i\�X��\�\�\�{\����\�+ko�K\�sR�Roeq\�\�\�ﬡ\�\�H�Z\�֬\��Mf\�s\��\��M\�Dս��x��\Z�[�ɲ���K\�+(l3\��\�X\�zCۉ\�ahY\���\���wB��45���\�yX\�]\�U\\\�\n1m:vs�Fc�+\Z���Q��\����̴\�d6\��n\�ٜN��\��\�B�\�%\�oou\�-B\�\Z\�j\�tj�^��f4�a\�b\0���16\�^;d���_;k݌\�^�R��V\�r�����wS�\�\�\�'),(62,'3__0_0_0_0',1704455508,'x�\�R\�n\�0���kKB�OA�ޚ\Z�ɉ�ŵK�\"	r�\�H�\�]YV A��丣\�\�\�p$���\�\�R\�\��לy�\�r�\�S\Z���gX\���9a\�|\�-\'4�D�\���j44\�\�gή\�\�@,���,F6�Xً�E`\�(-3\�gF]���Z)�@\\t@@\�\�\��V\�\�ζ v�%���\��\�ƭ\�\�\�ČC�=���\\,F�f\�:�\�;���8\�8\"B\�\�$50\�^\�\�QD��\�\�\�\�%�\�gQV(��\��\�\�vO\��1a\�\\a��٠gexR\�Ҷ�α\n`�\�-U\�\�BL�\�A\�\�r\�_��|\�rT]s��Q\���4\�4\�bE�\�\�iM��$d��\�\�5�\�mp�7�\�\�\�y1�\�\�يĚ\�,&��d\\l�\�\�^oX�\�\r4�f\�϶=w\�/�#Z\�},�\�\�\�t�\rF\�P'),(63,'5__0_0_0_0',1704455508,'x�\�T�n\�0��C\�ڒ�����H�&���Z�]\"I����\��\�\'\�r�h�K�靨{wǃ�\�o\�\�Z��\"�\�kIkͪ�8�q��i�(T�\n܍\��b>�O1C�	� @M\�\r�\ZΑ���@�F���u��v�\�FE:.��\�\�opi:%�Ƞ[F�ػ\�*~i)��\0\�B-@wg=�UV\��\�(�\r.���@6�Cy�q��\�b;\�;sH\�{\�(�ۑ�Y���\�\��~ �SG�kۚ$��ST:\�A\� �۹d��,\�2�3^b k\�>�>>��-\�\�F\�\�d6\��)츐����\�X�j�w����p �\��ڻГ\�EO�k\�d�\�ԓH>��K\�^˱X�\�\�_(\��E9���D0�\�\�\�\"\�A��6͞,\�0\�\�;�\�J�F\�\�ݏ�u�\r�;1�\�\�\��hggK\\֬fQA\�q��m\�\�\�\�nذc\��ca֯������\�\�\�?\�{\�և\�_\�S5�'),(64,'7__0_0_0_0',1704455508,'x�\�T��\�0��C��ئM��ʲ�5\rć\�$\�%}�-	\�\�Mh\�\��l׋��Kn~\�x�f4H\�R�BYl�,�+\�(<\Z�AYnƩ��Ok)�\�!(7aK\�\�\���	�\�h$M0\�\�Ejxf\nk?\�`)��n�\��{\�Jbq1�ׂA�@�h\�\�u4k3\��;�\�\���XI֤\�G)��N�u>Q\�Y\r\�\�\�\����\�\'���q\�t\�F^�&�j_;{ē\�lfQ���n:3(l�f�QE$\�Qr\�\�u��Ob,P�f\�\�\�g>��RP���\Z\�Il\�\n:+mzmk0c�\�8\�9eWX�KI/l\�JE\�7)o^\�S ��ٻllK�Ӛ�\�wZ�\�?\Z�ʱ�R�\�r\�.G�\�U\�w_\�m��\�\�fs\�vl�\�\�Nk\�%a#\�\�\�[%[��#\�G��Z<�\�.hBg;^V\��\��\�\�:�\'q�a��6\��RT\\�í��\��ξ����z��\Z1\�'),(65,'26__0_0_0_0',1704455508,'x�ݒMN\�0��|\0\�$\�\�]\"\����,7��Ķ\�qiUzw&MFT�a\�ҟ\�of��\�\�j�O$/J�\r�\�\�i\�&۟b*\�\�x\��+\�\�\�pL,\�5$4h@�0\�3�\Z:~\�\�,\�5�p\�zm#W\�\�dY���e�\�9k\�\�FT	<k������G\�\�G\�\����\�\0Ko�K\�sR�5Rmegq\�\�B��\�n�F5��Y\�%�\�wϩCO�6uU\���\��\"ho-&ö6\Z.��H��\���c.\��N\�CÊV\�$K\�_2\\�V\�Ԡ\��\n\�a�\��,Eq� \�\���\�\�=\�/�\��:YW=M\�L�Lf�^Ӛ\�&�\�\�\��?$�mr\�X\�V\�\�\"��!�F\��\�\�%jkFSjV\�F0�SjcC\��Cv<a�_\'�\�\�\�AP`濦\�3�?D�d�\�[v�\�\�&�\�;\�~\�'),(66,'11__0_0_0_0',1704455508,'x�ݒMn\�0���\0%	\�\�,+�+E\"�ve�\�P�Ķ\�q\n�ܽB���vê\��l��y~�\�t�h6\�4ҝ�CJ�dܲC�U[\�S\�F:f:�\"\�\����f=\��A\��\Z��\n\�\�\�9\�Q::֚7\�t���{RK�x�n(��\�\�e�)!�\�ja_�\�S\�[J�1��d)\�ʙ`#\�\�\�\�na\�aa�J�HC�5l�\�B�b^\Z�T+2��\�\���0�\�*�\��\�h�\�\�+�\����M\��l\�_Af��\�hǂ�k��u0�òJ6����\�$�a\\4\\�RLe\�ɥ\�t�\���>\�\�m���H�G\�҉\�Ѻ\�u\�<L�Nx\�\��Ym�.��\��C��\�&���֪tdm+\�j\�p�e\�`�͊��K\�\n\�_:e��OXv鄵=\�}�3\�\�ϴ}e\�ȡ,\��H�\�\�x��x�');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES (115,'1__0_0_1_1','pageId_1'),(116,'1__0_0_0_0','pageId_1'),(117,'2__0_0_0_0','pageId_2'),(118,'2__0_0_0_0','pageId_1'),(119,'3__0_0_0_0','pageId_3'),(120,'3__0_0_0_0','pageId_1'),(121,'5__0_0_0_0','pageId_5'),(122,'5__0_0_0_0','pageId_3'),(123,'5__0_0_0_0','pageId_1'),(124,'7__0_0_0_0','pageId_7'),(125,'7__0_0_0_0','pageId_3'),(126,'7__0_0_0_0','pageId_1'),(127,'26__0_0_0_0','pageId_26'),(128,'26__0_0_0_0','pageId_1'),(129,'11__0_0_0_0','pageId_11'),(130,'11__0_0_0_0','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` text DEFAULT NULL,
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(2048) DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(11) NOT NULL DEFAULT 0,
  `keywords` text DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `newUntil` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text DEFAULT NULL,
  `module` varchar(255) NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` text DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` text DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` text DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `canonical_link` varchar(2048) NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_pagelist_images` int(10) unsigned DEFAULT 0,
  `tx_pagelist_datetime` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_pagelist_eventfinish` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_pagelist_eventlocation` tinytext DEFAULT NULL,
  `tx_pagelist_eventlocationlink` tinytext DEFAULT NULL,
  `tx_pagelist_productprice` varchar(255) DEFAULT NULL,
  `tx_pagelist_notinlist` int(11) NOT NULL DEFAULT 0,
  `tx_pagelist_starttime` int(11) NOT NULL DEFAULT 0,
  `tx_pagelist_endtime` int(11) NOT NULL DEFAULT 0,
  `tx_advancedtitle_prefix` tinytext DEFAULT NULL,
  `tx_advancedtitle_sufix` tinytext DEFAULT NULL,
  `tx_personnel_authors` tinytext DEFAULT NULL,
  `tx_advancedtitle_absolute` tinytext DEFAULT NULL,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `tx_pagelist_eventstart` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `tx_pagelist_shortcut` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `slug` (`slug`(127)),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1679823674,1546914440,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"tx_advancedtitle_prefix\":\"\",\"tx_advancedtitle_sufix\":\"\",\"tx_advancedtitle_absolute\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"tx_pagelist_images\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"tx_pagelist_notinlist\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,1,31,27,0,'TYPO3 in a Friendly Package','/',1,NULL,1,0,'',0,0,'',0,'',0,0,'typo3, template, open source, free',0,'',0,'Free template for TYPO3 CMS. Easy to use and configure for your own needs.',0,1679823674,NULL,'',0,'','','',0,0,0,0,0,'pagets__home','pagets__sub','EXT:microtemplate/Configuration/PageTS/setup.typoscript','',0,0,'','',0,'','',0,'',0,0,0,0,NULL,NULL,NULL,0,0,0,'','| Microtemplate',NULL,NULL,0.5,'','summary',0,0,NULL),(2,1,1679820847,1546915678,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"tx_advancedtitle_prefix\":\"\",\"tx_advancedtitle_sufix\":\"\",\"tx_advancedtitle_absolute\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"tx_pagelist_images\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"tx_pagelist_notinlist\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,1,31,31,0,'Features','/features',1,NULL,0,0,'',0,0,'',0,'',0,0,'TYPO3, template,features,speed,css,js,html',0,'',0,'TYPO3 template with good looks and lightning speed!',0,1679820847,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'TYPO3 Microtemplate Features','TYPO3 template with good looks and lightning speed!',0,'TYPO3 Microtemplate Features','TYPO3 template with good looks and lightning speed!',0,'',0,0,0,0,NULL,NULL,NULL,0,0,0,'','',NULL,NULL,0.5,'','summary',0,0,NULL),(3,1,1639989524,1546917831,0,0,0,0,'',512,NULL,0,0,0,0,NULL,0,'a:20:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;s:23:\"tx_advancedtitle_prefix\";N;s:22:\"tx_advancedtitle_sufix\";N;s:18:\"tx_favicon_favicon\";N;}',0,0,0,0,1,1,31,27,0,'Articles & Events','/articles-events',199,NULL,0,0,'',0,3,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,0.5,'','',0,0,NULL),(5,3,1679761638,1546919175,0,0,0,0,'',80,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"subtitle\":\"\",\"slug\":\"\",\"tx_pagelist_datetime\":\"\",\"lastUpdated\":\"\",\"abstract\":\"\",\"tx_personnel_authors\":\"\",\"tx_pagelist_images\":\"\",\"seo_title\":\"\",\"description\":\"\",\"tx_advancedtitle_prefix\":\"\",\"tx_advancedtitle_sufix\":\"\",\"tx_advancedtitle_absolute\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"keywords\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"tx_staticfilecache_cache\":\"\",\"tx_staticfilecache_cache_force\":\"\",\"tx_staticfilecache_cache_offline\":\"\",\"tx_staticfilecache_cache_priority\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"tx_pagelist_notinlist\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,1,31,31,0,'Article for content examples','/article-for-content-examples',136,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1679397244,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,1,1546775160,0,NULL,NULL,NULL,0,0,0,NULL,NULL,'2',NULL,0.5,'','summary',0,0,NULL),(6,1,1679747808,1546919223,0,0,0,0,'0',2304,NULL,0,0,0,0,NULL,0,'{\"title\":\"\"}',0,0,0,0,1,1,31,25,0,'Personnel','/personnel',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,0.5,'','',0,0,NULL),(7,3,1679761611,1546921754,0,0,0,0,'',160,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"subtitle\":\"\",\"slug\":\"\",\"tx_pagelist_datetime\":\"\",\"lastUpdated\":\"\",\"tx_pagelist_eventstart\":\"\",\"tx_pagelist_starttime\":\"\",\"tx_pagelist_eventfinish\":\"\",\"tx_pagelist_endtime\":\"\",\"tx_pagelist_eventlocation\":\"\",\"tx_pagelist_eventlocationlink\":\"\",\"abstract\":\"\",\"tx_personnel_authors\":\"\",\"tx_pagelist_images\":\"\",\"seo_title\":\"\",\"description\":\"\",\"tx_advancedtitle_prefix\":\"\",\"tx_advancedtitle_sufix\":\"\",\"tx_advancedtitle_absolute\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"keywords\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"tx_staticfilecache_cache\":\"\",\"tx_staticfilecache_cache_force\":\"\",\"tx_staticfilecache_cache_offline\":\"\",\"tx_staticfilecache_cache_priority\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"tx_pagelist_notinlist\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"fe_login_mode\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,1,31,31,0,'Event example','/event-example',137,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1679388709,'Event introduction, just a short summary for vCal and lists.','',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,1,1639908000,1644249600,'Longmen Village, Penghu, Taiwan','https://www.google.com/maps/place/Longmen+Beach/@23.564886,119.683584,15z/data=!4m12!1m6!3m5!1s0x0:0xc6f5020858fbe74a!2sLongmen+Beach!8m2!3d23.564886!4d119.683584!3m4!1s0x0:0xc6f5020858fbe74a!8m2!3d23.564886!4d119.683584',NULL,0,1,1,'','','3',NULL,0.5,'','summary',1643709600,0,NULL),(11,1,1679747798,1546940212,0,0,0,0,'',912,NULL,0,0,0,0,NULL,0,'a:49:{s:7:\"doktype\";N;s:5:\"title\";N;s:4:\"slug\";N;s:9:\"nav_title\";N;s:8:\"subtitle\";N;s:9:\"seo_title\";N;s:23:\"tx_advancedtitle_prefix\";N;s:22:\"tx_advancedtitle_sufix\";N;s:8:\"no_index\";N;s:9:\"no_follow\";N;s:8:\"og_title\";N;s:14:\"og_description\";N;s:8:\"og_image\";N;s:13:\"twitter_title\";N;s:19:\"twitter_description\";N;s:13:\"twitter_image\";N;s:8:\"abstract\";N;s:8:\"keywords\";N;s:11:\"description\";N;s:18:\"tx_favicon_favicon\";N;s:6:\"author\";N;s:12:\"author_email\";N;s:11:\"lastUpdated\";N;s:14:\"backend_layout\";N;s:25:\"backend_layout_next_level\";N;s:16:\"content_from_pid\";N;s:6:\"target\";N;s:13:\"cache_timeout\";N;s:10:\"cache_tags\";N;s:11:\"is_siteroot\";N;s:9:\"no_search\";N;s:13:\"php_tree_stop\";N;s:6:\"module\";N;s:18:\"tx_pagelist_images\";N;s:5:\"media\";N;s:17:\"tsconfig_includes\";N;s:8:\"TSconfig\";N;s:8:\"l18n_cfg\";N;s:6:\"hidden\";N;s:8:\"nav_hide\";N;s:21:\"tx_pagelist_notinlist\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:16:\"extendToSubpages\";N;s:8:\"fe_group\";N;s:13:\"fe_login_mode\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,1,1,31,27,0,'Error 404','/error-404',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1679747798,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',1,0,'',NULL,0,'',NULL,0,'',0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,0.5,'','',0,0,NULL),(26,1,1639989513,1568099806,0,0,0,0,'',656,NULL,0,0,0,0,NULL,0,'a:1:{s:5:\"title\";N;}',0,0,0,0,1,1,31,31,0,'Success!','/success',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1639989513,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,0.5,'','',0,0,NULL),(54,1,1678368278,1678368255,0,0,0,0,'0',2560,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,27,0,'Menu content','/menu-content',254,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,'',0,0,'',NULL,0,'',NULL,0,'',0,0,1678368131,0,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL,0.5,'','summary',0,0,NULL);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext NOT NULL,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(32) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (2,0,1679820308,1546915254,0,1,'2',0,'/user_upload/bg/anime-city-desktop-wallpaper.jpg','de68a4318de14ea1e74203b3a36a189520745c95','77461e349bd1a778aff63a4f8603b4eea691eee5','jpg','image/jpeg','anime-city-desktop-wallpaper.jpg','c12bf83567b5269bab05cd9b474564fb8e9c4cef',189664,1679746821,1639832671),(4,0,1546918619,0,0,0,'2',0,'/typo3conf/ext/pagelist/Resources/Public/Images/clear.png','0c091a9e69750ff60eb7d39f0f8f27ce72bf912b','3f394c4cb51deb9535eadbaabea7d3ad79b89ed9','png','image/png','clear.png','3442a95fe890ce4769b36b2ecc611b801a54cfb5',95,1546914103,1546914103),(5,0,1679823273,1546922224,0,1,'2',0,'/user_upload/persons/obama_.jpg','01a0fc8121f105920d517a223298e48d4a35d674','3d43b9840044b5156cff303a1b06302bd6f6a36e','jpg','','obama_.jpg','01614a09a7615af8dfd9d5040c1efb0aecda8dd9',255391,1679823273,1679823208),(8,0,1679820326,1546994332,0,1,'2',0,'/user_upload/icons/favicon.png','7d0fe513c43b2d60d399a63579f3792b0669b20c','0254dba25222ae8bfa0ee1b38a90ca349548b97d','png','image/png','favicon.png','fe8efedb19d5e6930fcaa365301bc76fd33fec51',1921,1679746821,1639832671),(10,0,1547775392,0,0,0,'2',0,'/typo3conf/ext/news/Resources/Public/Images/dummy-preview-image.png','9f596bc172c8537a3ddc2d6efbb7e3212094e837','e70c7d8d1f511f7ac68ed0154b9a7ded896e72f2','png','image/png','dummy-preview-image.png','b069aa085f06da6743b904400b0e412c3b0b5b07',25896,1547775045,1541485963),(13,0,1679820318,1548056315,0,1,'2',0,'/user_upload/corporate/favicon.png','9a47a353dabc3c622193f9d366e30efe326aad6e','7b3ad4c23dbc86c6810a63003b6c61874d24c721','png','image/png','favicon.png','fe8efedb19d5e6930fcaa365301bc76fd33fec51',1921,1679746821,1639832671),(16,0,1679747678,1559996683,0,1,'1',0,'/form_definitions/contactus_1.form.yaml','35839f76d665a569c0f3569bcdfc97ef304c5c0c','c62e3e70a526a59f0f0b7687864947eab72d7d3f','yaml','text/plain','contactus_1.form.yaml','2728ba22b8ea09807059499c1a8dc3eff5f06f4a',3194,1679747678,1679747678),(21,0,1568973233,0,0,0,'2',0,'/typo3conf/ext/microtemplate/Resources/Public/Images/ico_soundoff.svg','4d3ed9adfebdd0dd5786740890c5d44f98a0b73e','c9fb5963292375e0421dc583abec37994351f306','svg','image/svg+xml','ico_soundoff.svg','81fa3d3c500cc6cded40dd084fc5a791f560cb0f',765,1568972570,1568972570),(22,0,1568973288,0,0,0,'2',0,'/typo3conf/ext/microtemplate/Resources/Public/Images/ico_soundon.svg','a93c4417a903b6c84f33d9f0e28b356a2b97061f','c9fb5963292375e0421dc583abec37994351f306','svg','image/svg+xml','ico_soundon.svg','667f7de07184068ce5fd8e94801932ed17eb2aa3',692,1568972578,1568972578),(29,0,1569484601,1569484601,1,1,'5',0,'/user_upload/00045_04.pdf','c4779495e5a58902cee8dfa912052f623755949a','19669f1e02c2f16705ec7587044c66443be70725','pdf','application/pdf','00045_04.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1569484601,1569484600),(30,0,1569484724,1569484724,1,1,'5',0,'/user_upload/00045_05.pdf','a6ac66390076d277664ba9d285e447f6ae86962e','19669f1e02c2f16705ec7587044c66443be70725','pdf','application/pdf','00045_05.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1569484724,1569484724),(31,0,1569484753,1569484753,1,1,'5',0,'/user_upload/00045_06.pdf','d12b0878e4163a9fab5cc30b27130693e1c01a16','19669f1e02c2f16705ec7587044c66443be70725','pdf','application/pdf','00045_06.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1569484753,1569484753),(32,0,1569490843,1569490843,1,1,'5',0,'/user_upload/00045_07.pdf','67e7412f0bafac75bf4ff9beb68a84cec3b942ff','19669f1e02c2f16705ec7587044c66443be70725','pdf','application/pdf','00045_07.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1569490843,1569490842),(33,0,1569490861,1569490861,1,1,'5',0,'/user_upload/00045_08.pdf','8ecf0f4ce53316d3561da95af5c4fe9f5e0f981a','19669f1e02c2f16705ec7587044c66443be70725','pdf','application/pdf','00045_08.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1569490861,1569490861),(34,0,1642087033,1569493073,0,1,'1',0,'/form_definitions/form_definitions/contactus.form.yaml','f16aa372d5957600fdeef976b48cbcdd884459f5','b35cda9a1f5ead13e2f6e66bed83771f8ba7faf1','yaml','text/plain','contactus.form.yaml','39e73eb11918765927762c24249da7ddde5e7e6b',3163,1639832671,1639832671),(35,0,1642087033,1569493073,0,1,'1',0,'/form_definitions/form_definitions/contactus_1.form.yaml','62eaf8d84c2b8ef9c094e32379c605cffbf8f3b8','b35cda9a1f5ead13e2f6e66bed83771f8ba7faf1','yaml','text/plain','contactus_1.form.yaml','0912913ae0d2c8f31aeffad6747a38bfff598da3',2230,1639832671,1639832671),(39,0,1638523729,0,0,0,'2',0,'/typo3temp/assets/online_media/youtube_ca47273252cbacf9a8ca1d3b474276f4.jpg','2011a7baaf3e4d96393b832c29be91c2a49e16ae','4cc752e47a34a774308932666b4f77c095218aab','jpg','image/jpeg','youtube_ca47273252cbacf9a8ca1d3b474276f4.jpg','b48caf7a58305e93cc60feaffcd30e77ae5cd091',64864,1638523729,1638523729),(40,0,1638529925,0,0,0,'2',0,'/typo3conf/ext/microtemplate/Resources/Public/Icons/Extension.png','62da83939620080f0bcf609d089f1132c444f95a','45a0b8fd6fe6aadf4b87c40f70f2f28bdd557299','png','image/png','Extension.png','cf0ddad4ae5378b12bdcb6a8ac32c860e60e19d6',2448,1638529682,1638529682),(41,0,1679820704,0,0,1,'4',0,'/user_upload/youtube/the_claypool_lennon_delirium_-_blood_and_rockets__live_at_the_current_.youtube','177f29837cc551cd50405a7da9dffc023437cdbb','31542a34fbcfcd9a7c75e20990cbec18cd6f34cf','youtube','video/youtube','the_claypool_lennon_delirium_-_blood_and_rockets__live_at_the_current_.youtube','f585d0dd70808500974b07be57fbcfaa0c32d514',11,1679820704,1639832671),(42,0,1638776310,0,0,0,'2',0,'/typo3temp/assets/online_media/youtube_5e976ac5f7f6502a38f08f65d5b629a2.jpg','8c0d56b9a75b8323d006665b903c38362d40c1c1','4cc752e47a34a774308932666b4f77c095218aab','jpg','image/jpeg','youtube_5e976ac5f7f6502a38f08f65d5b629a2.jpg','274a562de06eb646397a5ab5c3291bf5a95a46c0',15712,1638776310,1638776310),(46,0,1639949398,0,0,1,'5',0,'/user_upload/user_upload/00045.pdf','ae90f8ca42911aaaaf5034368283b541cc1258b7','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(47,0,1639949398,0,0,1,'5',0,'/user_upload/user_upload/00045_01.pdf','88e98b53f237a1b7a6aecd287aef0b006a647424','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_01.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(48,0,1639949399,0,0,1,'5',0,'/user_upload/user_upload/00045_02.pdf','f5e0706912dcdc151e9a9bd22e3a632ba19636d6','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_02.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(49,0,1639949399,0,0,1,'5',0,'/user_upload/user_upload/00045_03.pdf','8a297e18d6a0c8784603dcc3411c0fc23966b67c','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_03.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(50,0,1639949399,0,0,1,'5',0,'/user_upload/user_upload/00045_04.pdf','c0ccae3074d52075d509521bb0c00f155b8a94a1','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_04.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(51,0,1639949400,0,0,1,'5',0,'/user_upload/user_upload/00045_05.pdf','0c9b83e001e8b596a3fec4956c2e2f973e1bd3e7','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_05.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(52,0,1639949400,0,0,1,'5',0,'/user_upload/user_upload/00045_06.pdf','4a2fba044aba94c53d442430c0a73fbefdce3eda','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_06.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(53,0,1639949400,0,0,1,'5',0,'/user_upload/user_upload/00045_07.pdf','03797ae7b0d933337ab02d0db831daae60805092','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_07.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(54,0,1639949400,0,0,1,'5',0,'/user_upload/user_upload/00045_08.pdf','30677a8341ea5b81d4063cc653ae36ff320fe618','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','pdf','application/pdf','00045_08.pdf','929e6cc1d88e21e0587131df27d921914f43d6cf',31578,1639832671,1639832671),(74,0,1642087033,0,0,1,'4',0,'/user_upload/media/video/cityscape.mp4','0c6546111d6bf211d9eae9b5cece158204ee3b06','d9c66617c830db5765b3cdedbe585dd99e85f4f8','mp4','video/mp4','cityscape.mp4','e833a337b2f772c15a4119f26bcf36c5260c6a17',3334253,1639832671,1639832671),(81,0,1642087033,0,0,1,'5',0,'/user_upload/user_upload/_temp_/index.html','5ba4b9055ef5f636e670775269e51f762c75e804','a34b977abbe38f57b102296673b84f2bedf1860c','html','application/x-empty','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',0,1639832671,1639832671),(82,0,1642087033,0,0,1,'1',0,'/user_upload/user_upload/_temp_/importexport/index.html','72606fa22bef4d75b8f8aca7e26742311b9bddd0','0b424920f998855ea7209e85f5329d9e6b894b29','html','text/html','index.html','344e8d2f838769251206d105d6977c1e6b5dab44',110,1639832671,1639832671),(83,0,1642087033,0,0,1,'5',0,'/user_upload/user_upload/index.html','b1377759ea12f03a6c1cb93e90306abdc7f01d75','ae1c994a817aadc38e1397a582d9a4e6a2f3b5cf','html','application/x-empty','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',0,1639832671,1639832671),(84,0,1642087033,0,0,1,'5',0,'/user_upload/_temp_/index.html','a3ef597b554ed2a28c720b3e90e51edc9ec642b1','4e0743c93934dd9a02564d8e654d714bd2dc3d20','html','application/x-empty','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',0,1639832671,1639832671),(85,0,1642087033,0,0,1,'1',0,'/user_upload/_temp_/importexport/index.html','68614dc2826769e93d8a8ead62af30ac99aaa83a','0795cf796b4fc959be0ec00b183c0f47609dd9a5','html','text/html','index.html','344e8d2f838769251206d105d6977c1e6b5dab44',110,1639832671,1639832671),(86,0,1642087033,0,0,1,'1',0,'/_temp_/index.html','1cd5eec12b9b11599c0b4c6b2d43342c4fb53a7b','0258f8a5f703dd44c350fbfcddeecb1634d46ad4','html','text/html','index.html','344e8d2f838769251206d105d6977c1e6b5dab44',110,1610276839,1546914266),(92,0,1642087033,0,0,1,'2',0,'/user_upload/media/images/pic.jpg','fad056d37762940b7c1596e4a0e0336f56b3b3d7','1dcf72b02574755552c4f8b8e43e44a0e8dea5fe','jpg','image/jpeg','pic.jpg','ecc9203ed78ff8f7234ee5abf74da710efe3cb21',3974321,1639832671,1639832671),(93,0,1642087033,0,0,1,'4',0,'/user_upload/user_upload/img/bg/sunset-lapse.mp4','25c72d23ddce3fadf9b8a5f55bd8cd99ea340e80','260c52f5f2d1b027d200c5aead280881514d5de2','mp4','video/mp4','sunset-lapse.mp4','a723ef48863180f29849665bc7979a15cd794d51',4302509,1639832671,1639832671),(95,0,1642087033,0,0,1,'4',0,'/user_upload/media/the_knife_-_a_tooth_for_an_eye_-_official_video.youtube','984e291f624c91decf594ad6bb768a634fa5f3a2','df6d8fdb269ee2f04a4c68ac639c0e4d8d670990','youtube','video/youtube','the_knife_-_a_tooth_for_an_eye_-_official_video.youtube','4546de77bc886ca62f815b7d46f1d533c92011ea',11,1639832671,1639832671),(97,0,1642344307,0,0,0,'5',0,'/typo3conf/ext/microtemplate/Resources/Public/Fonts/fira-sans-extra-condensed-v5-latin-500.woff2','0976a1dad2f49bf41dfdebc335318af869275fd8','c0d6295a7e4642af3e3b5aaf435a1d3b143ee6ef','woff2','application/octet-stream','fira-sans-extra-condensed-v5-latin-500.woff2','88b0869975ab2c233978f45f37b928ca1daeb16f',22848,1642344287,1642344287),(101,0,1658668023,0,0,1,'1',0,'/form_definitions/emails/voucher_Plaintext.html','cad29742ba6c3396644039eebfb2a61d9b58b2fb','803db7e6f0fdbd7b26f6105c0cd02e15c14e9f29','html','text/html','voucher_Plaintext.html','084c23d84a5accc7d559e2c6e246b49f04cd63a1',1712,1658667949,1658667949),(110,0,1667121975,0,0,0,'2',0,'/typo3conf/ext/favicon/Resources/Public/Icons/Extension.png','2a11b604b7f36243469d95c225d7ca09033384e2','d834b898cbb4b9c9be7812a50c0aee7aafe06832','png','image/png','Extension.png','61b97166a62b1638c489ec02f2ecd33756b191b8',10160,1662534349,1638784693),(114,0,1679820308,0,0,1,'2',0,'/user_upload/bg/rainbow-vortex.svg','266472da28a8fb1aebc27342bd245503458ad4b8','77461e349bd1a778aff63a4f8603b4eea691eee5','svg','image/svg+xml','rainbow-vortex.svg','9830dbdc09114af9f0ce16dd3a7cdb6a3b2ef229',1063,1679746821,1678444624),(119,0,1679823005,0,0,1,'2',0,'/user_upload/gallery/20200904.jpg','c77b5b57c9f7906b56a834e6f24fd79cd8a1cb72','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20200904.jpg','cfaa7238405f4ad167fc0129e86eb178ff532016',277573,1679823005,1679821529),(120,0,1679823015,0,0,1,'2',0,'/user_upload/gallery/20190721.jpg','1a075e3cf7ead3098dd6a1a33976773820e5450c','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20190721.jpg','4ba1fc4d1734f28c3fdc4d4df8cece1f4f292644',382812,1679823015,1679821529),(123,0,1679822992,0,0,1,'2',0,'/user_upload/gallery/20221216.jpg','c3c783be375a3c152a5d4a7397ba80c5dcac3514','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20221216.jpg','7504bcf9338bd71e2425fe6d6b18be2be9c7561c',438310,1679822992,1679821529),(125,0,1679822974,0,0,1,'2',0,'/user_upload/gallery/20221029.jpg','c3407df36fa390dd7b343a9c81e2744660929843','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20221029.jpg','f49c3c6c1cb66386c6527661b76c80047d0dea52',849099,1679822974,1679821529),(128,0,1679823037,0,0,1,'2',0,'/user_upload/gallery/0101.jpg','99e99154dde229869c1cdecdfed8664091aca3f6','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','0101.jpg','850d0495b08cee17183c55d591b7e4a4ab5de371',560528,1679823037,1678612743),(130,0,1679823055,0,0,1,'2',0,'/user_upload/gallery/20180501.jpg','b3e02df0f9c2cae5aa2a0d7bda585585d90d0ed4','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20180501.jpg','e0daa8a670a43462aeb2bf38970a55ba3d3fbe8d',229412,1679823054,1679821529),(134,0,1679823066,0,0,1,'2',0,'/user_upload/gallery/20170823.jpg','82791449b2dc2229b681cfecacc264aaf931abbb','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20170823.jpg','03dc979559f32f3c9910f346d820a3f5794fb972',330966,1679823066,1679821529),(135,0,1679823078,0,0,1,'2',0,'/user_upload/gallery/20170728.jpg','0f55ba1c6ab095fbb984a6751e6a8af676726395','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20170728.jpg','61733e05cb0ad3bf9c063b01cad48e839d682e13',334898,1679823078,1679821528),(136,0,1679823090,0,0,1,'2',0,'/user_upload/gallery/20170714.jpg','df9357e4a0c0db41b493300f9f677f12d01734b2','784fc7cea532839db92fdc9506f532ecc82705b9','jpg','image/jpeg','20170714.jpg','c3e85b4c2a680ca8cfc89b5834c63d7e2313fcc7',491756,1679823090,1679821528),(141,0,1679823639,0,0,1,'2',0,'/user_upload/content/a3822210348.jpg','049d29039387d08301960a5b701974047a4f0810','a5fd4827bb8bc1413fbc5bd229aa5341605e28fb','jpg','image/jpeg','a3822210348.jpg','0b61b63d12412eb3d1d482905d96caa082738a05',413487,1679823639,1679823617),(142,0,1679820718,0,0,1,'4',0,'/user_upload/youtube/VisionVersion__Why___These_Few_Presidents_.youtube','5e8968732d93a7f79536e85fcd2432d22a7f8e3a','31542a34fbcfcd9a7c75e20990cbec18cd6f34cf','youtube','video/youtube','VisionVersion__Why___These_Few_Presidents_.youtube','5b99ebba9e9a48405e99fddf56e8395fcf5d1db0',11,1679820718,1679055662),(148,0,1679393492,0,0,1,'1',0,'/user_upload/user_upload/_temp_/importexport/.htaccess','af872ce5a33388a520dd41447cf7a53027b8763a','0b424920f998855ea7209e85f5329d9e6b894b29','htaccess','text/plain','.htaccess','88d1ddbb5d89f89d8c7c859f10f9c328acd9b1cf',372,1658686725,1639832671),(149,0,1679394204,0,0,1,'1',0,'/form_definitions/contact-6419859c5ebc18.73862340.form.yaml.deleted','803216dd859b1988e91168881a8084cd5d7fbdbe','c62e3e70a526a59f0f0b7687864947eab72d7d3f','deleted','text/plain','contact-6419859c5ebc18.73862340.form.yaml.deleted','96760a9d17c2c3833a0214ad45fcbf0c1d1c41e0',2010,1679394204,1679394204),(150,0,1679394323,0,0,1,'1',0,'/form_definitions/testVouchers-64198613a79748.51076883.form.yaml.deleted','1ab7771aa530a68be92253cbdc0f927b90141b23','c62e3e70a526a59f0f0b7687864947eab72d7d3f','deleted','text/plain','testVouchers-64198613a79748.51076883.form.yaml.deleted','d1b33b9663e87f7c4f66aec1539f7918072dae7b',1479,1679394323,1679394323),(151,0,1679394327,0,0,1,'1',0,'/form_definitions/testFormtoPDF-64198617aee0f7.59668425.form.yaml.deleted','ed1b2a35d960b9275909f8dcb65799bb272ec19d','c62e3e70a526a59f0f0b7687864947eab72d7d3f','deleted','text/plain','testFormtoPDF-64198617aee0f7.59668425.form.yaml.deleted','dcebdf1ab67d187d3e68fce8576d9a911b20bd5d',1176,1679394327,1679394327),(152,0,1679394340,0,0,1,'1',0,'/form_definitions/exampleForm-64198624c53938.97863058.form.yaml.deleted','27cdf066326689518bca39097d6894fcb985240c','c62e3e70a526a59f0f0b7687864947eab72d7d3f','deleted','text/plain','exampleForm-64198624c53938.97863058.form.yaml.deleted','3cc3e0858d6709ac3bc51b58f62de0d5ce740ae9',2877,1679394340,1679394340),(153,0,1679751450,0,0,0,'2',0,'/_assets/cde4951fa6e7de365908c2d0c98cbd49/Icons/Extension.png','f8fc58353945fab2344e3509b82304a3aaf7340b','8124ec2b0f30fdc1220fdcc3250a433df1151aef','png','image/png','Extension.png','cf0ddad4ae5378b12bdcb6a8ac32c860e60e19d6',2448,1679732862,1674517891),(155,0,1679821045,0,0,1,'1',0,'/form_definitions/contact_us.form.yaml','76622669dfb7d96a8145f5d35bd491afa86c1631','c62e3e70a526a59f0f0b7687864947eab72d7d3f','yaml','text/plain','contact_us.form.yaml','1cd44b5d2c916308ff569675a2d1c2410678adbf',2791,1679821045,1679821045),(156,0,1679823495,0,0,1,'2',0,'/user_upload/persons/meri_.jpg','7b3cc4ca14e78923c4820a66222220a6b22fb64f','3d43b9840044b5156cff303a1b06302bd6f6a36e','jpg','image/jpeg','meri_.jpg','e04798ad281fbefe9487983358c96964f0c29462',280302,1679823495,1679823208),(157,0,1679823260,0,0,1,'2',0,'/user_upload/persons/Obama.jpg','540af462614eef77352d6cf6e5c59950fd474cfa','3d43b9840044b5156cff303a1b06302bd6f6a36e','jpg','image/jpeg','Obama.jpg','01614a09a7615af8dfd9d5040c1efb0aecda8dd9',255391,1679823208,1679823208),(158,0,1679823374,0,0,1,'2',0,'/user_upload/persons/tsai_.jpg','9d89ae26851dc401d8ccb6ca1053e084cedbb463','3d43b9840044b5156cff303a1b06302bd6f6a36e','jpg','image/jpeg','tsai_.jpg','f5bfdb0bc54683eaa2ccaf0d4d3d8c6fa117d019',167788,1679823367,1679823367),(160,0,1679823622,0,0,1,'2',0,'/user_upload/content/speed.jpg','a7b2286a99ad9b58cfa06c35086ef6647d62d2c1','a5fd4827bb8bc1413fbc5bd229aa5341605e28fb','jpg','image/jpeg','speed.jpg','7a94a912b8e817f9fc068ccdeb871cd6c46976c6',216245,1679823617,1679823617),(161,0,1701863262,1701863262,0,1,'5',0,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','application/x-empty','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',0,1701851203,1701851203),(162,0,1701863295,1701863295,0,1,'4',0,'/user_upload/vimeo/Windsurf_-_Hardcore.vimeo','f63a57ee462ba178b65211a971b1f6b663e0c14a','95fcbf31dfb04bca94ddc6d533a7b57cf30d9ada','vimeo','video/vimeo','Windsurf_-_Hardcore.vimeo','da410b3f1fdcb74896b5fdddfdd5b755b5dc9178',9,1701863295,1701863295),(163,0,1701863363,1701863363,0,0,'2',0,'/typo3temp/assets/online_media/vimeo_cea34da3337fa12f6caff318115f1e12.jpg','5ba383b450841d5d94221406818ed6dd895215b1','4cc752e47a34a774308932666b4f77c095218aab','jpg','image/jpeg','vimeo_cea34da3337fa12f6caff318115f1e12.jpg','13fcd5b8cc9eb4991e4f4923d111d9f93c4e549e',40131,1701863297,1701863297);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (2,0,1679820308,1546915254,0,0,NULL,0,'',0,0,0,0,2,NULL,1920,1080,NULL,NULL,0),(4,0,1546918619,1546918618,0,0,NULL,0,'',0,0,0,0,4,NULL,1,1,NULL,NULL,0),(5,0,1679823273,1546922224,0,0,NULL,0,'',0,0,0,0,5,NULL,1400,1084,NULL,NULL,0),(8,0,1679820326,1546994332,0,0,NULL,0,'',0,0,0,0,8,NULL,150,150,NULL,NULL,0),(10,0,1547775392,1547775391,0,0,NULL,0,'',0,0,0,0,10,NULL,128,128,NULL,NULL,0),(13,0,1679820318,1548056315,0,0,NULL,0,'',0,0,0,0,13,NULL,150,150,NULL,NULL,0),(16,0,1679747678,1559996683,0,0,NULL,0,'',0,0,0,0,16,NULL,0,0,NULL,NULL,0),(21,0,1568973233,1568973233,0,0,NULL,0,'',0,0,0,0,21,NULL,23,19,NULL,NULL,0),(22,0,1568973288,1568973288,0,0,NULL,0,'',0,0,0,0,22,NULL,23,19,NULL,NULL,0),(29,0,1569484601,1569484600,0,0,NULL,0,'',0,0,0,0,29,NULL,0,0,NULL,NULL,0),(30,0,1569484724,1569484724,0,0,NULL,0,'',0,0,0,0,30,NULL,0,0,NULL,NULL,0),(31,0,1569484753,1569484753,0,0,NULL,0,'',0,0,0,0,31,NULL,0,0,NULL,NULL,0),(32,0,1569490843,1569490842,0,0,NULL,0,'',0,0,0,0,32,NULL,0,0,NULL,NULL,0),(33,0,1569490861,1569490861,0,0,NULL,0,'',0,0,0,0,33,NULL,0,0,NULL,NULL,0),(34,0,1642087033,1569493071,0,0,NULL,0,'',0,0,0,0,34,NULL,0,0,NULL,NULL,0),(35,0,1642087033,1569493071,0,0,NULL,0,'',0,0,0,0,35,NULL,0,0,NULL,NULL,0),(39,0,1638523729,1638523729,0,0,NULL,0,'',0,0,0,0,39,NULL,1280,720,NULL,NULL,0),(40,0,1638529922,1638529922,0,0,NULL,0,'',0,0,0,0,40,NULL,512,512,NULL,NULL,0),(41,0,1679820704,1638776307,0,0,NULL,0,'',0,0,0,0,41,'The Claypool Lennon Delirium - Blood and Rockets (Live at The Current)',2048,1152,NULL,NULL,0),(42,0,1638776310,1638776310,0,0,NULL,0,'',0,0,0,0,42,NULL,320,180,NULL,NULL,0),(46,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,46,NULL,595,842,NULL,NULL,0),(47,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,47,NULL,595,842,NULL,NULL,0),(48,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,48,NULL,595,842,NULL,NULL,0),(49,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,49,NULL,595,842,NULL,NULL,0),(50,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,50,NULL,595,842,NULL,NULL,0),(51,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,51,NULL,595,842,NULL,NULL,0),(52,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,52,NULL,595,842,NULL,NULL,0),(53,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,53,NULL,595,842,NULL,NULL,0),(54,0,1639949398,1639949398,0,0,NULL,0,'',0,0,0,0,54,NULL,595,842,NULL,NULL,0),(74,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,74,NULL,0,0,NULL,NULL,0),(81,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,81,NULL,0,0,NULL,NULL,0),(82,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,82,NULL,0,0,NULL,NULL,0),(83,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,83,NULL,0,0,NULL,NULL,0),(84,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,84,NULL,0,0,NULL,NULL,0),(85,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,85,NULL,0,0,NULL,NULL,0),(86,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,86,NULL,0,0,NULL,NULL,0),(92,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,92,NULL,4812,3208,NULL,NULL,0),(93,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,93,NULL,0,0,NULL,NULL,0),(95,0,1642087032,1642087032,0,0,NULL,0,'',0,0,0,0,95,'The Knife - A Tooth For An Eye - Official video',200,113,NULL,NULL,0),(97,0,1642344306,1642344306,0,0,NULL,0,'',0,0,0,0,97,NULL,0,0,NULL,NULL,0),(101,0,1658668023,1658668023,0,0,NULL,0,'',0,0,0,0,101,NULL,0,0,NULL,NULL,0),(110,0,1667121975,1667121975,0,0,NULL,0,'',0,0,0,0,110,NULL,512,512,NULL,NULL,0),(114,0,1679820308,1678444624,0,0,NULL,0,'',0,0,0,0,114,NULL,100,100,NULL,NULL,0),(119,0,1679823005,1678612658,0,0,NULL,0,'',0,0,0,0,119,NULL,1400,1050,NULL,NULL,0),(120,0,1679823015,1678612660,0,0,NULL,0,'',0,0,0,0,120,NULL,1400,1050,NULL,NULL,0),(123,0,1679822992,1678612672,0,0,NULL,0,'',0,0,0,0,123,NULL,1050,1400,NULL,NULL,0),(125,0,1679822974,1678612678,0,0,NULL,0,'{\"alternative\":\"\",\"description\":\"\",\"title\":\"\",\"sys_language_uid\":\"\",\"categories\":\"\"}',0,0,0,0,125,NULL,1050,1400,NULL,NULL,0),(128,0,1679823037,1678612743,0,0,NULL,0,'',0,0,0,0,128,NULL,2592,1936,NULL,NULL,0),(130,0,1679823055,1678612748,0,0,NULL,0,'',0,0,0,0,130,NULL,1400,1050,NULL,NULL,0),(134,0,1679823066,1678612757,0,0,NULL,0,'',0,0,0,0,134,NULL,1400,1050,NULL,NULL,0),(135,0,1679823078,1678612761,0,0,NULL,0,'',0,0,0,0,135,NULL,1400,1050,NULL,NULL,0),(136,0,1679823090,1678612761,0,0,NULL,0,'',0,0,0,0,136,NULL,1400,1050,NULL,NULL,0),(141,0,1679823639,1679055637,0,0,NULL,0,'',0,0,0,0,141,NULL,1400,1400,NULL,NULL,0),(142,0,1679820718,1679055662,0,0,NULL,0,'',0,0,0,0,142,'VisionVersion: Why? \"These Few Presidents\"',2048,1152,NULL,NULL,0),(148,0,1679393492,1679393492,0,0,NULL,0,'',0,0,0,0,148,NULL,0,0,NULL,NULL,0),(149,0,1679394204,1679394204,0,0,NULL,0,'',0,0,0,0,149,NULL,0,0,NULL,NULL,0),(150,0,1679394323,1679394323,0,0,NULL,0,'',0,0,0,0,150,NULL,0,0,NULL,NULL,0),(151,0,1679394327,1679394327,0,0,NULL,0,'',0,0,0,0,151,NULL,0,0,NULL,NULL,0),(152,0,1679394340,1679394340,0,0,NULL,0,'',0,0,0,0,152,NULL,0,0,NULL,NULL,0),(153,0,1679751448,1679751448,0,0,NULL,0,'',0,0,0,0,153,NULL,512,512,NULL,NULL,0),(155,0,1679821045,1679820997,0,0,NULL,0,'',0,0,0,0,155,NULL,0,0,NULL,NULL,0),(156,0,1679823495,1679821324,0,0,NULL,0,'',0,0,0,0,156,NULL,1120,1400,NULL,NULL,0),(157,0,1679823260,1679823256,0,0,NULL,0,'',0,0,0,0,157,NULL,1400,1084,NULL,NULL,0),(158,0,1679823374,1679823374,0,0,NULL,0,'',0,0,0,0,158,NULL,1168,1400,NULL,NULL,0),(160,0,1679823621,1679823621,0,0,NULL,0,'',0,0,0,0,160,NULL,1400,768,NULL,NULL,0),(161,0,1701863262,1701863262,0,0,NULL,0,'',0,0,0,0,161,NULL,0,0,NULL,NULL,0),(162,0,1701863294,1701863294,0,0,NULL,0,'',0,0,0,0,162,'Windsurf - Hardcore',2048,1152,NULL,NULL,0),(163,0,1701863363,1701863363,0,0,NULL,0,'',0,0,0,0,163,NULL,1280,720,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  `processing_url` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=3697 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `crop` varchar(4000) NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  `tx_youtubevideo_autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_youtubevideo_rel` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_youtubevideo_starttime` varchar(10) DEFAULT NULL,
  `tx_youtubevideo_endtime` varchar(10) DEFAULT NULL,
  `tx_youtubevideo_ratio` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_youtubevideo_fullscreen` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_youtubevideo_loop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_youtubevideo_mute` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_youtubevideo_coverimage` int(11) NOT NULL DEFAULT 0,
  `tx_vimeovideo_starttime` varchar(10) DEFAULT NULL,
  `tx_vimeovideo_endtime` varchar(10) DEFAULT NULL,
  `tx_vimeovideo_ratio` varchar(10) DEFAULT NULL,
  `tx_vimeovideo_loop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_vimeovideo_mute` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_vimeovideo_coverimage` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES (5,6,1678817249,1546922491,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,5,3,'tx_personnel_domain_model_person','images',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":0.875968992248062,\"width\":0.678,\"x\":0.159,\"y\":0.03359173126614987},\"selectedRatio\":\"1:1\",\"focusArea\":null}}',0,0,0,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,0,0,0),(6,1,1546994336,1546994336,0,0,0,0,NULL,'',0,0,0,0,8,1,'pages','favicon',1,NULL,NULL,NULL,'','',0,0,0,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,0,0,0),(16,1,1638206748,1551408917,0,0,0,0,NULL,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,13,1,'pages','tx_favicon_favicon',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0,0,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,0,0,0),(76,1,1638523616,1637190395,0,1,0,0,NULL,'a:4:{s:4:\"crop\";N;s:9:\"uid_local\";N;s:6:\"hidden\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,2,16,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0,0,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,0,0,0),(80,5,1679752375,1638776308,0,0,0,0,NULL,'{\"title\":\"\",\"description\":\"\",\"tx_youtubevideo_mute\":\"\",\"tx_youtubevideo_loop\":\"\",\"tx_youtubevideo_fullscreen\":\"\",\"tx_youtubevideo_rel\":\"\",\"tx_youtubevideo_starttime\":\"\",\"tx_youtubevideo_endtime\":\"\",\"tx_youtubevideo_ratio\":\"\",\"tx_youtubevideo_coverimage\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,41,165,'tt_content','tx_youtubevideo_assets',1,'The Claypool Lennon Delirium','Blood and Rockets',NULL,'','',0,0,0,'','',0,1,0,0,0,NULL,NULL,NULL,0,0,0),(155,1,1679829793,1678444642,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,114,1,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(184,1,1679749915,1678612875,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,119,158,'tt_content','assets',3,NULL,NULL,'Straight Summer road','','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"x\":0,\"y\":0.125,\"width\":1,\"height\":0.75},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2210599721059972,\"width\":1,\"height\":0.5578800557880056},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21875,\"y\":0,\"width\":0.5625,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.323,\"y\":0.20185185185185184,\"width\":0.323,\"height\":0.7656296296296297},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.33,\"y\":0.0012866666666666417,\"width\":0.313,\"height\":0.9974266666666667},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(188,1,1679749915,1678612875,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,130,158,'tt_content','assets',4,NULL,NULL,'Road on a dam','','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"x\":0,\"y\":0.125,\"width\":1,\"height\":0.75},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2210599721059972,\"width\":1,\"height\":0.5578800557880056},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21875,\"y\":0,\"width\":0.5625,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.325,\"y\":0.1614814814814815,\"width\":0.289,\"height\":0.6850370370370369},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.37304811715481173,\"y\":0.042666666666666665,\"width\":0.2569037656903766,\"height\":0.8186666666666668},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(189,1,1679749915,1678612875,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,128,158,'tt_content','assets',2,NULL,NULL,'Winter road','','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0.002057613168724338,\"y\":0,\"width\":0.9958847736625513,\"height\":1},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"x\":0,\"y\":0.1234504132231405,\"width\":1,\"height\":0.753099173553719},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.21990732736263355,\"width\":1,\"height\":0.5601853452747328},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.12654320987654322,\"y\":0,\"width\":0.7469135802469136,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21990740740740758,\"y\":0,\"width\":0.5601851851851852,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.25108273836085077,\"y\":0.13788487282463185,\"width\":0.3498345232782984,\"height\":0.8326639892904953},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.365,\"y\":0.20739365583546301,\"width\":0.23100000000000004,\"height\":0.7391618181818184},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(193,5,1679397244,1678805035,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,135,5,'pages','tx_pagelist_images',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":0.7493333333333333,\"width\":0.999,\"x\":0,\"y\":0.23066666666666666},\"selectedRatio\":\"16:9\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(199,1,1701863399,1679055709,0,0,0,0,NULL,'{\"title\":\"\",\"description\":\"\",\"tx_youtubevideo_mute\":\"\",\"tx_youtubevideo_loop\":\"\",\"tx_youtubevideo_fullscreen\":\"\",\"tx_youtubevideo_rel\":\"\",\"tx_youtubevideo_starttime\":\"\",\"tx_youtubevideo_endtime\":\"\",\"tx_youtubevideo_ratio\":\"\",\"tx_youtubevideo_coverimage\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,142,16,'tt_content','tx_youtubevideo_assets',1,NULL,NULL,NULL,'','',0,0,1,'','',0,1,0,0,1,NULL,NULL,NULL,0,0,0),(200,1,1701863399,1679055709,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,141,199,'sys_file_reference','tx_youtubevideo_coverimage',1,NULL,NULL,NULL,'','{\"widescreen\":{\"cropArea\":{\"x\":0.1493333333333333,\"y\":0.034,\"width\":0.6933333333333334,\"height\":0.39},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0.125,\"width\":1,\"height\":0.75},\"selectedRatio\":\"4:3\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(203,5,1679397623,1679229170,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,125,163,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0.21875,\"width\":1,\"height\":0.5625},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"height\":0.421,\"width\":1,\"x\":0,\"y\":0.311},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.3430962343096235,\"width\":1,\"height\":0.3138075313807531},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0,\"y\":0.125,\"width\":1,\"height\":0.75},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.22105997210599734,\"y\":0,\"width\":0.5578800557880056,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(204,5,1679397623,1679229170,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,123,163,'tt_content','assets',2,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":0.421,\"width\":0.9973333333333333,\"x\":0,\"y\":0.352},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0.21875,\"width\":1,\"height\":0.5625},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"height\":0.421,\"width\":1,\"x\":0,\"y\":0.475},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.3430962343096235,\"width\":1,\"height\":0.3138075313807531},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0,\"y\":0.125,\"width\":1,\"height\":0.75},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.22105997210599748,\"y\":0,\"width\":0.5578800557880056,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(205,5,1679397623,1679229170,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,136,163,'tt_content','assets',3,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"height\":0.6173333333333333,\"width\":0.823,\"x\":0.017,\"y\":0},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2210599721059972,\"width\":1,\"height\":0.5578800557880056},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21875,\"y\":0,\"width\":0.5625,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.2890625,\"y\":0,\"width\":0.421875,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.34309623430962344,\"y\":0,\"width\":0.3138075313807531,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(206,5,1679397623,1679229170,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,134,163,'tt_content','assets',4,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"height\":1,\"width\":1,\"x\":0,\"y\":0},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"height\":0.7493333333333333,\"width\":1,\"x\":0,\"y\":0.20933333333333334},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2210599721059972,\"width\":1,\"height\":0.5578800557880056},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.21875,\"y\":0,\"width\":0.5625,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.2890625,\"y\":0,\"width\":0.421875,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.34309623430962344,\"y\":0,\"width\":0.3138075313807531,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(211,7,1679388709,1679337505,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,134,7,'pages','tx_pagelist_images',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":0.5946666666666667,\"width\":0.794,\"x\":0.205,\"y\":0.36133333333333334},\"selectedRatio\":\"16:9\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(214,1,1679749915,1679605882,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,120,158,'tt_content','assets',1,NULL,NULL,'Summer road','','{\"default\":{\"cropArea\":{\"x\":-0.001,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0,\"y\":0.00022036139268400177,\"width\":1,\"height\":0.999559277214632},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"x\":7.5189707487841285e-17,\"y\":0.125165271044513,\"width\":0.99999999999999989,\"height\":0.74966945791097395},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.2211829073320413,\"width\":1,\"height\":0.55763418533591735},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.12483465608465609,\"y\":0,\"width\":0.75033068783068779,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.121,\"y\":0.0094966945791097011,\"width\":0.41700000000000004,\"height\":0.74100661084178054},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.14699999999999999,\"y\":0.0006011458792419712,\"width\":0.29999999999999999,\"height\":0.71079770824151611},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.34302705275508621,\"y\":0,\"width\":0.31394589448982757,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(217,6,1679821425,1679821407,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,156,2,'tx_personnel_domain_model_person','images',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0.0074999999999999989,\"y\":0.01402984429065744,\"width\":0.94874999999999998,\"height\":0.75894031141868512},\"selectedRatio\":\"1:1\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(218,6,1679823471,1679823471,0,0,0,0,NULL,'',0,0,0,0,158,7,'tx_personnel_domain_model_person','images',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":0.834,\"width\":1,\"x\":0,\"y\":0.003},\"selectedRatio\":\"1:1\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(219,2,1679823717,1679823717,0,0,0,0,NULL,'',0,0,0,0,160,267,'tt_content','assets',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"tv\":{\"cropArea\":{\"x\":0.13428571428571429,\"y\":0,\"width\":0.73142857142857143,\"height\":1},\"selectedRatio\":\"4:3\",\"focusArea\":null},\"widescreen\":{\"cropArea\":{\"x\":0.012380952380952407,\"y\":0,\"width\":0.97523809523809524,\"height\":1},\"selectedRatio\":\"16:9\",\"focusArea\":null},\"anamorphic\":{\"cropArea\":{\"x\":0,\"y\":0.11863668061366806,\"width\":1,\"height\":0.76272663877266389},\"selectedRatio\":\"2_39:1\",\"focusArea\":null},\"square\":{\"cropArea\":{\"x\":0.2257142857142857,\"y\":0,\"width\":0.5485714285714286,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null},\"portrait\":{\"cropArea\":{\"x\":0.29428571428571426,\"y\":0,\"width\":0.41142857142857142,\"height\":1},\"selectedRatio\":\"3:4\",\"focusArea\":null},\"tower\":{\"cropArea\":{\"x\":0.3457142857142857,\"y\":0,\"width\":0.30857142857142855,\"height\":1},\"selectedRatio\":\"9:16\",\"focusArea\":null},\"skyscraper\":{\"cropArea\":{\"x\":0.38523610280932458,\"y\":0,\"width\":0.22952779438135085,\"height\":1},\"selectedRatio\":\"1:2_39\",\"focusArea\":null}}',0,0,1,NULL,NULL,0,1,0,0,0,NULL,NULL,NULL,0,0,0),(220,1,1701863373,1701863361,0,0,0,0,NULL,'{\"title\":\"\",\"description\":\"\",\"tx_vimeovideo_mute\":\"\",\"tx_vimeovideo_loop\":\"\",\"tx_vimeovideo_starttime\":\"\",\"tx_vimeovideo_endtime\":\"\",\"tx_vimeovideo_ratio\":\"\",\"tx_vimeovideo_coverimage\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,162,333,'tt_content','tx_vimeovideo_assets',1,NULL,NULL,NULL,'','',0,0,1,NULL,NULL,0,1,0,0,0,'','','0',0,0,0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `driver` tinytext DEFAULT NULL,
  `configuration` text DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1658667601,1546914447,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin/ (auto-created)','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"baseUri\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
INSERT INTO `sys_filemounts` VALUES (1,0,1639988930,0,0,256,'','Files',0,'1:/user_upload/');
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(32) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) NOT NULL DEFAULT '',
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `parent` (`pid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `channel` (`channel`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `message` text DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`fields`)),
  `identifier` varchar(36) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) NOT NULL DEFAULT '',
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('014e9145ac19ccb2a7ad062ef959c504','sys_file',30,'metadata','','','',0,0,'sys_file_metadata',30,''),('02ff87103c05ddc5c3100f854fe9623f','sys_file',85,'storage','','','',0,0,'sys_file_storage',1,''),('03130f0d682948d2bbbb9176bd3cc867','sys_file',50,'storage','','','',0,0,'sys_file_storage',1,''),('03e4764a35c3b1f131a1a0c7c66e994e','sys_file',50,'metadata','','','',0,0,'sys_file_metadata',50,''),('03e925867c5ac09b11c9c5094df32965','sys_file',35,'storage','','','',0,0,'sys_file_storage',1,''),('04409d20f4d0d02388fcdecf01e91a80','sys_file_metadata',52,'file','','','',0,0,'sys_file',52,''),('0531758ecc221acdfbda084f47657389','tt_content',13,'bodytext','','typolink_tag','1',-1,0,'pages',1,''),('05d5e7de5f4f21df4b07936b474782f4','tx_personnel_domain_model_person',7,'email','','email','2',-1,0,'_STRING',0,'example@domain.com'),('06fbbd1bcf2d9d01e4d9cc1d267de19b','sys_file_metadata',128,'file','','','',0,0,'sys_file',128,''),('076efd2605c2d2fb5b1db21cc8c30ecb','sys_file',123,'metadata','','','',0,0,'sys_file_metadata',123,''),('0826c19097811ebecc3c9cc744ad9ba6','sys_file',142,'metadata','','','',0,0,'sys_file_metadata',142,''),('0870bb4b83e18a7142d1b8a4b2c69694','sys_file_metadata',95,'file','','','',0,0,'sys_file',95,''),('09dad6e5106c71255fd539e47fe0fd47','sys_file',46,'storage','','','',0,0,'sys_file_storage',1,''),('0ae53cefd9d1768f05cec38e8de18e28','tt_content',323,'tx_container_parent','','','',0,0,'tt_content',166,''),('0be16d2414942c028029834b29d87f10','tt_content',309,'bodytext','','typolink_tag','1',-1,0,'pages',2,''),('0c209a7f09de10dbe5cc78aaa5ab1a42','sys_file_reference',189,'uid_local','','','',0,0,'sys_file',128,''),('0c3e754852083f9c591f9ebcee29a1cc','tt_content',19,'tx_container_parent','','','',0,0,'tt_content',6,''),('0fff0d1dedbea94bd37f4a0e7aaf713c','sys_file_reference',155,'uid_local','','','',0,0,'sys_file',114,''),('12d585212e2cc7408ae67d19390414cf','sys_file',95,'storage','','','',0,0,'sys_file_storage',1,''),('131e66eb58321eda7d8b00ced59268e4','sys_file_metadata',33,'file','','','',0,0,'sys_file',33,''),('13c9d76de5872edc45e72172fee0ac56','sys_file',156,'metadata','','','',0,0,'sys_file_metadata',156,''),('13d8fb9941ce946dcb07df62ef011a03','sys_file',53,'metadata','','','',0,0,'sys_file_metadata',53,''),('13edfb87dbec64b44af6a3b0c0a1695d','tt_content',165,'tx_youtubevideo_assets','','','',0,0,'sys_file_reference',80,''),('1412c68f02343e0b35149317df7b9076','sys_file',150,'metadata','','','',0,0,'sys_file_metadata',150,''),('14ee01323df816fc7cfe3dc6258b152a','sys_file_metadata',151,'file','','','',0,0,'sys_file',151,''),('16f8a2eb03d20262089f58b9bda41d9d','tt_content',22,'tx_container_parent','','','',0,0,'tt_content',5,''),('17516f60f5789f88718c7e02377d7cc2','tt_content',159,'tx_container_parent','','','',0,0,'tt_content',157,''),('177a98741a97628dcac2d64d4a46e13f','tt_content',16,'tx_youtubevideo_assets','','','',0,0,'sys_file_reference',199,''),('18710caee73b67ab529faf648faaa8b7','pages',5,'tx_personnel_authors','','','',0,0,'tx_personnel_domain_model_person',2,''),('19d697c050a347544670168270a45c11','sys_file',158,'storage','','','',0,0,'sys_file_storage',1,''),('1c9b8784c1518ef7b22704c4fc698ca9','sys_file',2,'storage','','','',0,0,'sys_file_storage',1,''),('1d0c915ba80d50b79070fee03197459d','sys_file',31,'storage','','','',0,0,'sys_file_storage',1,''),('1d9bf3e82f9d8f8460dfb6b7074ccc16','sys_file_reference',5,'uid_local','','','',0,0,'sys_file',5,''),('1d9ea97da5cddcedae16f1420a865e08','sys_file',158,'metadata','','','',0,0,'sys_file_metadata',158,''),('1db6f423d98136650a22dd68006be1a8','sys_file_metadata',136,'file','','','',0,0,'sys_file',136,''),('1efe0f915811a82b0392b70425abe6fd','sys_file',151,'metadata','','','',0,0,'sys_file_metadata',151,''),('1f14573acf90f337fff037fdc450b354','sys_file_metadata',16,'file','','','',0,0,'sys_file',16,''),('201dc1e0bfcfe2f0da28f73af08e60c0','sys_file_metadata',2,'file','','','',0,0,'sys_file',2,''),('205ee1e7af4e30938944dda3fc6a9e60','sys_file',13,'storage','','','',0,0,'sys_file_storage',1,''),('208beee30966b76498a00167dbd15d78','sys_file',41,'storage','','','',0,0,'sys_file_storage',1,''),('20d38759c5b96b98641549771e1e1f6a','sys_file',93,'metadata','','','',0,0,'sys_file_metadata',93,''),('21459982906562a9b18a79ce3cc5cb74','sys_file',95,'metadata','','','',0,0,'sys_file_metadata',95,''),('2168032d562f64d32038d6547292b3dc','sys_file',101,'metadata','','','',0,0,'sys_file_metadata',101,''),('222cbfe52b4682648b9b6610ca5475f0','tt_content',333,'tx_container_parent','','','',0,0,'tt_content',332,''),('241893c8898d82d971299feeb8f61b0c','tt_content',91,'pi_flexform','sDEF/lDEF/settings.persistenceIdentifier/vDEF/','formPersistenceIdentifier','db0d68dfa12306bf049df0d2d77291cb',-1,0,'sys_file',155,''),('2532f5f01c7068d6cd1723377a7061ed','sys_file',48,'storage','','','',0,0,'sys_file_storage',1,''),('27bdcffd83d4726a8bc6e6846385ef0d','sys_file_metadata',152,'file','','','',0,0,'sys_file',152,''),('29c9f1b0ae60524e5895506c9186a7a4','sys_file_metadata',29,'file','','','',0,0,'sys_file',29,''),('2afa08f370c96201a704aad33eb17159','sys_file',51,'metadata','','','',0,0,'sys_file_metadata',51,''),('2bf3d65e32ee4456030b500b1e231e06','sys_file',82,'storage','','','',0,0,'sys_file_storage',1,''),('2e063935c54c7c1a55234e2c184477c2','sys_file',92,'storage','','','',0,0,'sys_file_storage',1,''),('2f438b18ee477413a114c366c2ee6a9f','sys_file',83,'metadata','','','',0,0,'sys_file_metadata',83,''),('3050cc591591f5c18b646e1ae4cd9afa','pages',7,'tx_personnel_authors','','','',0,0,'tx_personnel_domain_model_person',3,''),('307f25cc922de5d6001ca1615bed02f1','sys_file',151,'storage','','','',0,0,'sys_file_storage',1,''),('31c68235a696e7e07d652ab86b1e681c','pages',5,'tx_pagelist_images','','','',0,0,'sys_file_reference',193,''),('33a1a89e73c3c0c666b119182676818a','tt_content',163,'assets','','','',1,0,'sys_file_reference',204,''),('362d9b4b950a432f129d8696975270b6','sys_file',128,'metadata','','','',0,0,'sys_file_metadata',128,''),('3795391fab50cd89c13cc42a90f9441e','tt_content',31,'tx_container_parent','','','',0,0,'tt_content',7,''),('379e19f3c05eee4d7307ef585ec8a037','sys_file',123,'storage','','','',0,0,'sys_file_storage',1,''),('37a8085704cfdb14094e519ad1eb4203','sys_file',155,'storage','','','',0,0,'sys_file_storage',1,''),('37cce10ec4e0c089a957970d06983cee','sys_file_metadata',120,'file','','','',0,0,'sys_file',120,''),('3841356c5dac2b98e45aa8b5c87f00eb','sys_file_metadata',148,'file','','','',0,0,'sys_file',148,''),('39bc2d5c23ed0417800861069836c423','sys_file',136,'storage','','','',0,0,'sys_file_storage',1,''),('39cbde01f953d2523aba16c7fa02f876','tt_content',20,'pages','','','',0,0,'pages',6,''),('39dcc71290eb7518251d53839d471007','tt_content',24,'bodytext','','typolink_tag','3',-1,0,'pages',1,''),('3c04889d5e9dff80d8339dfbd508ab13','sys_file',10,'metadata','','','',0,0,'sys_file_metadata',10,''),('3d8f82df29ca366dc60c3fd2d9da2648','sys_file',141,'metadata','','','',0,0,'sys_file_metadata',141,''),('3f66705547724e17d946ac9c1681ff80','sys_file_metadata',93,'file','','','',0,0,'sys_file',93,''),('40b63d8a1a0e340fe33c9bd63e1befba','sys_file',40,'metadata','','','',0,0,'sys_file_metadata',40,''),('420d6995eb9975afd0d5225a795913c6','tt_content',163,'assets','','','',0,0,'sys_file_reference',203,''),('423625973acb1a34275fa48b74f76f78','sys_file',8,'metadata','','','',0,0,'sys_file_metadata',8,''),('431ec60dffc6db479df413b2f27092b8','sys_file_metadata',47,'file','','','',0,0,'sys_file',47,''),('43b48dd3260d7a695d5535df5ae5cf7c','sys_file',39,'metadata','','','',0,0,'sys_file_metadata',39,''),('4623d430381ce0c0d96a7ce3457bb233','sys_file_metadata',85,'file','','','',0,0,'sys_file',85,''),('4750dd38eb5ff9d98e5df04ea4a442c4','sys_file',32,'storage','','','',0,0,'sys_file_storage',1,''),('47899da464265d22d955fccad07e7383','sys_file',22,'metadata','','','',0,0,'sys_file_metadata',22,''),('48c59f5f478bab7f218a6a928e4f8b87','sys_file',136,'metadata','','','',0,0,'sys_file_metadata',136,''),('48daaf78b655aefdf8a835343649b4ae','sys_file',16,'metadata','','','',0,0,'sys_file_metadata',16,''),('491dd54a1dce8453693ea4d17e5b0486','sys_file_metadata',86,'file','','','',0,0,'sys_file',86,''),('49b12c90eaf4a80295b934250348ddba','sys_file',153,'metadata','','','',0,0,'sys_file_metadata',153,''),('4d9fd84367dce56d921b12e6dd2d135d','tt_content',2,'tx_container_parent','','','',0,0,'tt_content',1,''),('4e9a7d84fd524aef314d554630a620e5','sys_file_metadata',158,'file','','','',0,0,'sys_file',158,''),('50c6b41c4b3df6a512bafdb62a204e95','sys_file_metadata',153,'file','','','',0,0,'sys_file',153,''),('52237f87bb0a7b7fca70dd8438709feb','tt_content',2,'bodytext','','typolink_tag','0cab4f88bc7a0d5318af1f7b96dce7b9:1',-1,0,'tt_content',3,''),('52d745f0161e289a9c8ad92cd5e5c039','sys_file_metadata',101,'file','','','',0,0,'sys_file',101,''),('539e473da2e46432dfea444628bc4746','sys_file',120,'metadata','','','',0,0,'sys_file_metadata',120,''),('549b891bbf2b8d8c7dc23cf1281683a7','sys_file',92,'metadata','','','',0,0,'sys_file_metadata',92,''),('54cad1e717af832e6a1b2b560359925b','tt_content',187,'tx_container_parent','','','',0,0,'tt_content',9,''),('54d5bc51bf47154f3cbb9d2c0ab4d13b','sys_file',41,'metadata','','','',0,0,'sys_file_metadata',41,''),('55f62d4d2c99a52c5fbc552141ecadb7','sys_file_metadata',50,'file','','','',0,0,'sys_file',50,''),('56e727aca421fa994df3bafc75259f8d','tx_personnel_domain_model_person',7,'images','','','',0,0,'sys_file_reference',218,''),('573c3164eb8c83d9f9ad95eb3620227c','tt_content',158,'tx_container_parent','','','',0,0,'tt_content',157,''),('59abaa06dcf8e28f0addceee173e4b18','sys_file',128,'storage','','','',0,0,'sys_file_storage',1,''),('5a5b6aa225a045f63d5e784a2445895a','sys_file',148,'metadata','','','',0,0,'sys_file_metadata',148,''),('5a8cafcb2e835c6f75ec3f747b2f9c09','sys_file_metadata',134,'file','','','',0,0,'sys_file',134,''),('5b6d3b71b04f7443a121be23b85a1332','sys_file',130,'storage','','','',0,0,'sys_file_storage',1,''),('5d075746177918b286cfa8ab85a1ba2e','sys_file',29,'storage','','','',0,0,'sys_file_storage',1,''),('5d733278b3c0882d1be9d928bca31561','tx_personnel_domain_model_person',2,'email','','email','2',-1,0,'_STRING',0,'example@domain.com'),('5da7bbaa9339f9cb04a088062a69fe20','sys_file_metadata',156,'file','','','',0,0,'sys_file',156,''),('5ef13ab734b9153143ad30cce90cd70e','sys_file',85,'metadata','','','',0,0,'sys_file_metadata',85,''),('60e676dba9e57f4451dff6f2230582b1','sys_file_metadata',123,'file','','','',0,0,'sys_file',123,''),('61977478bd2dfb37904b8a4f7a50dd00','sys_file',13,'metadata','','','',0,0,'sys_file_metadata',13,''),('643e5c81fe35f47e2a610656ec3d4060','tt_content',32,'tx_container_parent','','','',0,0,'tt_content',7,''),('65827e61ebeb8c5c8fbdeff1644047e1','sys_file',160,'storage','','','',0,0,'sys_file_storage',1,''),('686bd383362ddd11eff9fce9dc30bb42','sys_file_reference',218,'uid_local','','','',0,0,'sys_file',158,''),('687e68460217e3b43fcd508e8510dc0c','sys_file_metadata',160,'file','','','',0,0,'sys_file',160,''),('692e129d0a6ae1105f43e3627f14e64d','sys_file',8,'storage','','','',0,0,'sys_file_storage',1,''),('6b65b767c242c3191e8d2cf0026a1710','tt_content',16,'tx_container_parent','','','',0,0,'tt_content',332,''),('6ba21a8d2dc056b3575d9554fb53d4a4','sys_file_reference',199,'tx_youtubevideo_coverimage','','','',0,0,'sys_file_reference',200,''),('6ca73b7ed9ee7af533ea7b9a1c82e64a','sys_file',86,'storage','','','',0,0,'sys_file_storage',1,''),('6d956b9630706f0e01239d7edb5cd63a','sys_file_metadata',81,'file','','','',0,0,'sys_file',81,''),('6da977dcf0267c79b2e49921f2e79e2b','sys_file_reference',204,'uid_local','','','',0,0,'sys_file',123,''),('70811c4e0c6633abf1b3ac1786bb3079','tt_content',8,'tx_container_parent','','','',0,0,'tt_content',3,''),('70e44f7fcaeb072c3a09e7fadfd37426','sys_file',130,'metadata','','','',0,0,'sys_file_metadata',130,''),('7206b31211e1355569917c596b548185','tt_content',78,'tx_container_parent','','','',0,0,'tt_content',3,''),('721347c0ce4df94752a268820abd42d6','sys_file',81,'storage','','','',0,0,'sys_file_storage',1,''),('72b2f9f5cdf4e9679b405c82b7be8e93','tx_personnel_domain_model_person',2,'images','','','',0,0,'sys_file_reference',217,''),('732d00ac3e6683b82a9deec0f428a463','sys_file_metadata',157,'file','','','',0,0,'sys_file',157,''),('7401dfeb14147ed1d6597e9ee008dc66','sys_file_metadata',53,'file','','','',0,0,'sys_file',53,''),('7438b33eb243d508cb1f90a0974d0501','sys_file',93,'storage','','','',0,0,'sys_file_storage',1,''),('749b0771828793d3e3eba1372852a7a8','sys_file',2,'metadata','','','',0,0,'sys_file_metadata',2,''),('7692cc3a0eb321f3516c7b047f5e6211','sys_file',29,'metadata','','','',0,0,'sys_file_metadata',29,''),('771d3c16378082f19a4a8d2c1c1582e3','sys_file',134,'metadata','','','',0,0,'sys_file_metadata',134,''),('7782b1ee1538a061408b5e0d31f0c149','sys_file_metadata',114,'file','','','',0,0,'sys_file',114,''),('790350e1dea97804892212c437058cd9','tt_content',17,'tx_paginatedprocessors_anchorid','','','',0,0,'tt_content',5,''),('791d3f9d43dcbfa78cd49dd8258caa09','sys_file',5,'storage','','','',0,0,'sys_file_storage',1,''),('79d2c903b87f5713c13d0b4cbafc1f35','sys_file',31,'metadata','','','',0,0,'sys_file_metadata',31,''),('7afa6934a0491343b7b2832837d78000','sys_file_metadata',34,'file','','','',0,0,'sys_file',34,''),('7dea25184bfdd1efc3e160636f252be7','sys_file',125,'storage','','','',0,0,'sys_file_storage',1,''),('7e6b7cca077f2e98aa7f7088d5f233d7','tt_content',24,'bodytext','','typolink_tag','7d6410794cd398f259caaa7295be76dd:3',-1,0,'tt_content',329,''),('7f15ea8d3d71989d5ea275a32a7e85bb','sys_file',49,'storage','','','',0,0,'sys_file_storage',1,''),('809760df02cc79bfed6bd34a0741cc3a','tt_content',1,'image','','','',0,0,'sys_file_reference',155,''),('80f6b9177c5e17a45113b806c39109ef','sys_file_reference',203,'uid_local','','','',0,0,'sys_file',125,''),('817a42bcedd459d0930e36776634f878','tt_content',158,'assets','','','',2,0,'sys_file_reference',184,''),('8233d2bb37cc1001bf35c88ee118f4cb','tt_content',330,'tx_container_parent','','','',0,0,'tt_content',329,''),('82650aa1fe5bd83e1ecb6f61c36417bf','sys_file',162,'storage','','','',0,0,'sys_file_storage',1,''),('82b54f58a09ff7c754eb47c874eff6c2','sys_file_metadata',10,'file','','','',0,0,'sys_file',10,''),('83766280f5bdc4b856fa034501dcc0b8','sys_file_metadata',135,'file','','','',0,0,'sys_file',135,''),('8501db49d3e7423980f6c0343ca064da','sys_file_metadata',149,'file','','','',0,0,'sys_file',149,''),('858d757fcdd731e3e8bf8f03a47e63a9','sys_file',51,'storage','','','',0,0,'sys_file_storage',1,''),('8592793a32ae37a399ab3b10d0e9973a','sys_file',35,'metadata','','','',0,0,'sys_file_metadata',35,''),('8987893411baca05f986dca0a4c38bd8','sys_file',5,'metadata','','','',0,0,'sys_file_metadata',5,''),('8b449777adf7b3d6b5fc6c4500578a1b','sys_file',54,'metadata','','','',0,0,'sys_file_metadata',54,''),('8bd345fe20011f78b1c1e0b8d7597fae','tt_content',90,'tx_container_parent','','','',0,0,'tt_content',89,''),('8cdb4b99b67a38464f26bf651849bde6','sys_file',125,'metadata','','','',0,0,'sys_file_metadata',125,''),('8d23731a2b2037f4781f89c5149c57be','sys_file_metadata',5,'file','','','',0,0,'sys_file',5,''),('8e02b4670398476bf4565f2ab0624e16','tt_content',163,'assets','','','',2,0,'sys_file_reference',205,''),('8f8397c45b5341cd83fb5e6ebc8c5544','tt_content',266,'bodytext','','typolink_tag','1',-1,0,'pages',1,''),('8fd6e23eca349e02ba628a6979d4199d','sys_file',157,'metadata','','','',0,0,'sys_file_metadata',157,''),('908d99d11254b098427aa11d88c52ae7','tt_content',158,'assets','','','',0,0,'sys_file_reference',214,''),('92caa29eaa405d11ab718473c1318ceb','sys_file_reference',220,'uid_local','','','',0,0,'sys_file',162,''),('92cc3842a84c2f6c1b01dfbf5935e0fc','sys_file',157,'storage','','','',0,0,'sys_file_storage',1,''),('9316901796f4763c98698177b373b6c4','tt_content',309,'tx_container_parent','','','',0,0,'tt_content',3,''),('952d5320e2db1d3343d80387c24c754c','sys_file_metadata',155,'file','','','',0,0,'sys_file',155,''),('952ff58309ea86d82acc12b3e4080ecc','tt_content',158,'assets','','','',1,0,'sys_file_reference',189,''),('96a207c4ca6aa58a7438792b4a42d366','sys_file_metadata',97,'file','','','',0,0,'sys_file',97,''),('96d65656979cfe98847ca94e0bb7489e','sys_file',142,'storage','','','',0,0,'sys_file_storage',1,''),('979c69cb03358a2d36b7e2714b4e4f88','tt_content',17,'pages','','','',0,0,'pages',3,''),('97f4f1ce666977d0059b799bcc45ab66','sys_file',155,'metadata','','','',0,0,'sys_file_metadata',155,''),('98573766620928ffb5c3877a32c44ace','sys_file',148,'storage','','','',0,0,'sys_file_storage',1,''),('99ca53250f4c18a528379d3d73d32963','sys_file',149,'metadata','','','',0,0,'sys_file_metadata',149,''),('99d190a15a12f183cd654f995176e2f7','sys_file',74,'metadata','','','',0,0,'sys_file_metadata',74,''),('99de689fcc8d549c1edc8d615d5e37a0','sys_file_metadata',4,'file','','','',0,0,'sys_file',4,''),('9add96dac2e37ee67c28e1187359ace9','tt_content',267,'assets','','','',0,0,'sys_file_reference',219,''),('9b6f369edfacbaf7be9f030e5130ddf6','sys_file_metadata',110,'file','','','',0,0,'sys_file',110,''),('9c0010ae14257773393bc978d172c883','sys_file',150,'storage','','','',0,0,'sys_file_storage',1,''),('9c8ea432459b121b02497c7f21d8d81a','sys_file_reference',76,'uid_local','','','',0,0,'sys_file',2,''),('9c9a7f6439eedb583b757e975ab9a7ce','sys_file_metadata',83,'file','','','',0,0,'sys_file',83,''),('9d045b88ecd74a28975bab42ed13a99e','sys_file_reference',214,'uid_local','','','',0,0,'sys_file',120,''),('9d1834b89afa44ba238a34c738f79204','tt_content',21,'tx_container_parent','','','',0,0,'tt_content',31,''),('9d5f6e844610c967eab14ac7af2f16e3','sys_file_metadata',141,'file','','','',0,0,'sys_file',141,''),('9dc2c83b8552791f2ded590f59e953f0','pages',7,'tx_pagelist_images','','','',0,0,'sys_file_reference',211,''),('9dcc5741d394ad0dfa1bbe0b3b6e3687','sys_file',160,'metadata','','','',0,0,'sys_file_metadata',160,''),('a00625faa664b731bc39f7a8b9e9686a','sys_file_metadata',39,'file','','','',0,0,'sys_file',39,''),('a01426ae6a06b63ecfed5c9dc15c0374','tt_content',81,'tx_container_parent','','','',0,0,'tt_content',80,''),('a155e86b7915bb76541c7061cffcf707','tt_content',9,'tx_container_parent','','','',0,0,'tt_content',3,''),('a1e46773c821e13ad488d005962cf05b','sys_file',30,'storage','','','',0,0,'sys_file_storage',1,''),('a35233b40f8aa7f021a7fd8ae7f8bb8f','tt_content',158,'assets','','','',3,0,'sys_file_reference',188,''),('a5ba571ba315e717ff4d3bf4f32475d8','sys_file_reference',6,'uid_local','','','',0,0,'sys_file',8,''),('a5e29a3a81967287c153e016ee36cba5','sys_file',54,'storage','','','',0,0,'sys_file_storage',1,''),('a6572b97acc7d0627fbf9e311fec1cc4','sys_file',16,'storage','','','',0,0,'sys_file_storage',1,''),('a665d2a2e117ae005bd0b1e800b1c86c','sys_file_metadata',130,'file','','','',0,0,'sys_file',130,''),('a66832d778186a6ad275c3deb26c20a2','sys_file',134,'storage','','','',0,0,'sys_file_storage',1,''),('a8a00494a7aaad240d055e9f1759cd7a','sys_file_reference',200,'uid_local','','','',0,0,'sys_file',141,''),('ac1a08a702bf97b64b015eb6103fbd2c','sys_file_metadata',125,'file','','','',0,0,'sys_file',125,''),('ac597d1c856d319c699ffce32fb24009','sys_file',114,'metadata','','','',0,0,'sys_file_metadata',114,''),('add8efad26c05469e1737c6381b1d493','sys_file',135,'storage','','','',0,0,'sys_file_storage',1,''),('ae5f749627222d0c0e9f9b2da1e794dc','sys_file',161,'storage','','','',0,0,'sys_file_storage',1,''),('aeb45c5f34c3aab73286b3fa0ab6cb99','tt_content',164,'tx_container_parent','','','',0,0,'tt_content',166,''),('af678b277177775a05c7cba09836a6fd','tt_content',124,'bodytext','','typolink_tag','1',-1,0,'pages',1,''),('aff8619cb291eb2743fcdee66964fc81','sys_template',2,'constants','','url','7',-1,0,'_STRING',0,'https://twitter.com/t3brightside'),('b1f3036a5e5118607c52701c9ab644e6','sys_file_metadata',84,'file','','','',0,0,'sys_file',84,''),('b29369f461d443f4eb1b8259f627eaf4','sys_file',149,'storage','','','',0,0,'sys_file_storage',1,''),('b445d1bae12e6345690ecadf933c92e2','sys_file',97,'metadata','','','',0,0,'sys_file_metadata',97,''),('b4fc6db3bdfc8f91a8e87dfad30996ee','tt_content',333,'tx_vimeovideo_assets','','','',0,0,'sys_file_reference',220,''),('b50f65443dd36304cb85aac1e0253da5','sys_file',47,'metadata','','','',0,0,'sys_file_metadata',47,''),('b5d8a5ee30fefad52d3847a23a678558','sys_file_metadata',74,'file','','','',0,0,'sys_file',74,''),('b79c96177201ae7b121ca0965a949291','sys_file_reference',188,'uid_local','','','',0,0,'sys_file',130,''),('b8ebfd578a12410878bd742a4c1f2413','sys_file',42,'metadata','','','',0,0,'sys_file_metadata',42,''),('baa22019f2ea8b1f88ed6ba714399740','sys_file_metadata',13,'file','','','',0,0,'sys_file',13,''),('bb745801590a1442ba37c253da57cc3c','sys_file',48,'metadata','','','',0,0,'sys_file_metadata',48,''),('bbf33e7f83847f0ce1983e92c2c761b5','sys_file_metadata',48,'file','','','',0,0,'sys_file',48,''),('bc1b5dad51146707f3d784fee807c99e','sys_file_reference',219,'uid_local','','','',0,0,'sys_file',160,''),('bd13fa7b4f0b587e1949ce8e78a80db3','sys_file_metadata',142,'file','','','',0,0,'sys_file',142,''),('bd55138958258043e44365a0e16e3d79','tt_content',327,'bodytext','','typolink_tag','1',-1,0,'pages',1,''),('be549680be5bcabef6fe90ab2f83b042','sys_file',52,'metadata','','','',0,0,'sys_file_metadata',52,''),('be83d54bc28dcd9866709bc7eaf0e1c1','sys_file',119,'storage','','','',0,0,'sys_file_storage',1,''),('bfe765cb21c7469f08b05c6d60b2f3ca','sys_template',2,'constants','','url','2',-1,0,'_STRING',0,'https://microtemplate.t3brightside.com/'),('c0b0e162fa6e6d211d44ceaa65269399','tt_content',17,'tx_container_parent','','','',0,0,'tt_content',5,''),('c2472d27fdbdf12adcacf67ad558dfb5','sys_file',81,'metadata','','','',0,0,'sys_file_metadata',81,''),('c2eab9bdec3b0927c1d9050754111031','sys_file',47,'storage','','','',0,0,'sys_file_storage',1,''),('c2eb74d56cd587786177f51681cda789','sys_file',110,'metadata','','','',0,0,'sys_file_metadata',110,''),('c3a7df501a6692ea8ba19067d94eaa75','tt_content',331,'tx_container_parent','','','',0,0,'tt_content',4,''),('c3da14db519dfa74eee714471843ed5f','tt_content',24,'tx_container_parent','','','',0,0,'tt_content',23,''),('c4f959a3de7389dc9ee792145540589b','sys_file_reference',199,'uid_local','','','',0,0,'sys_file',142,''),('c61149d114d7178aba3d8e406023250f','sys_file',156,'storage','','','',0,0,'sys_file_storage',1,''),('c78c9588e7aadd6bcfc994551fe0540c','sys_file_metadata',21,'file','','','',0,0,'sys_file',21,''),('c80ba2a160d792c820431076e2373b43','sys_file',34,'metadata','','','',0,0,'sys_file_metadata',34,''),('cbadf06dc8652de5e793d0a6d52a5dd2','sys_file_reference',80,'uid_local','','','',0,0,'sys_file',41,''),('cbafd710778f2b16fd6ddbbdda8e9c0c','sys_file',120,'storage','','','',0,0,'sys_file_storage',1,''),('cbf603ff6f07831a78fee4a2952ed7c0','sys_file',141,'storage','','','',0,0,'sys_file_storage',1,''),('cc109381e9cf183f2c6bb7b7733025b9','tt_content',16,'image','','','',0,0,'sys_file_reference',76,''),('cd5231d05a5dfa030126ddaa004f3f7f','sys_file_metadata',22,'file','','','',0,0,'sys_file',22,''),('ce671e3684d78c110e94d7b58b26b0b8','sys_file_metadata',42,'file','','','',0,0,'sys_file',42,''),('cfa24d5d5a74c51b595c9fe018c101fb','sys_file_metadata',119,'file','','','',0,0,'sys_file',119,''),('d07b5d96253322ad53209d5ed3bc5c73','sys_file_metadata',32,'file','','','',0,0,'sys_file',32,''),('d238ad01c110266a753ba2566e0a1fc0','sys_file',152,'metadata','','','',0,0,'sys_file_metadata',152,''),('d2bd41560fe0f5e715127f74b7e2e676','sys_file',152,'storage','','','',0,0,'sys_file_storage',1,''),('d3970681b798dc90c4a7f7e7cd25bdab','tt_content',20,'tx_container_parent','','','',0,0,'tt_content',6,''),('d5b995e8a3fe8a4502c602b3cfc47bc0','sys_file_reference',211,'uid_local','','','',0,0,'sys_file',134,''),('d7cd2959cf13f044f3c321499599adb6','tt_content',33,'tx_container_parent','','','',0,0,'tt_content',31,''),('d85040f054c4f271af748697872d00c2','sys_file_reference',217,'uid_local','','','',0,0,'sys_file',156,''),('d860ef2766c42de6aa9d4772ca15443a','tx_personnel_domain_model_person',3,'images','','','',0,0,'sys_file_reference',5,''),('d8d9d25a7f3d83a886b583ae12ca136b','tt_content',163,'tx_paginatedprocessors_anchorid','','','',0,0,'tt_content',320,''),('da2944582a70b78cd69061550f2273fd','sys_file',84,'metadata','','','',0,0,'sys_file_metadata',84,''),('da67a01ed44ffd76d06b52fb67fb5ed4','sys_file',84,'storage','','','',0,0,'sys_file_storage',1,''),('db53bb5a34b43eeb97fcf974bdb1a93f','sys_file_metadata',49,'file','','','',0,0,'sys_file',49,''),('dc698db592512df5e8c9172f42ce59e2','sys_file',32,'metadata','','','',0,0,'sys_file_metadata',32,''),('dc8eaef8903e505b4778ef95debc8910','sys_file_metadata',40,'file','','','',0,0,'sys_file',40,''),('dd634c72f492fe1f69d55727b633f620','sys_file_metadata',51,'file','','','',0,0,'sys_file',51,''),('dd8186968bc801ad39522e557d7cd6d3','sys_file',135,'metadata','','','',0,0,'sys_file_metadata',135,''),('ddb89c754923625ea59d16459b4067bd','tt_content',10,'tx_container_parent','','','',0,0,'tt_content',9,''),('ddd77a9f8fb4fdf5a153e8bbbfc4a031','tt_content',85,'tx_container_parent','','','',0,0,'tt_content',80,''),('de28246790cc908b18bc4ddfb6048688','sys_file_metadata',92,'file','','','',0,0,'sys_file',92,''),('de60d2e2952c418fdf8d778f20d4ab69','sys_file',119,'metadata','','','',0,0,'sys_file_metadata',119,''),('df7941865f85a7c052d8325a495fc9c7','sys_file',46,'metadata','','','',0,0,'sys_file_metadata',46,''),('e08245868d20a8a886ddf7c4ba1a407d','sys_file_metadata',30,'file','','','',0,0,'sys_file',30,''),('e1322d48726d9a88913af93a4346d11e','tt_content',332,'tx_container_parent','','','',0,0,'tt_content',4,''),('e1dcf0085116e1304ba2607d59e85621','sys_file',33,'metadata','','','',0,0,'sys_file_metadata',33,''),('e2de3f1a500b27c086eb0507d6d7cb2c','sys_file_reference',184,'uid_local','','','',0,0,'sys_file',119,''),('e2f7aa23dc74e552b0957ffbf792d8c7','sys_file',86,'metadata','','','',0,0,'sys_file_metadata',86,''),('e3c29349febb6bb6ac551f326a2032ae','sys_file',83,'storage','','','',0,0,'sys_file_storage',1,''),('e4f25600caf6b47af195b39234312146','tt_content',2,'bodytext','','typolink_tag','1',-1,0,'pages',1,''),('e53a53527080ace80846d7f3112cd88f','sys_file_metadata',54,'file','','','',0,0,'sys_file',54,''),('e71f9a441a77a4684c950e9ca053309f','sys_file',52,'storage','','','',0,0,'sys_file_storage',1,''),('e73a9744cb16317b33be99593e291f19','sys_file_metadata',82,'file','','','',0,0,'sys_file',82,''),('e7dc538d1406a5a2d77b2dfa43b0be3b','tt_content',91,'tx_container_parent','','','',0,0,'tt_content',89,''),('ea3b0a4e1d6aad10e3a0278c33280af7','sys_file_metadata',31,'file','','','',0,0,'sys_file',31,''),('eb2653780c25deadd1ed253485b02dbe','sys_file',33,'storage','','','',0,0,'sys_file_storage',1,''),('ec01e9666331703a2215b40555f23bf6','sys_file',4,'metadata','','','',0,0,'sys_file_metadata',4,''),('ed6d2b4834715c14094537dfba600afe','sys_file',101,'storage','','','',0,0,'sys_file_storage',1,''),('eeed546becbfe3071f052082a9b9707a','sys_file_reference',193,'uid_local','','','',0,0,'sys_file',135,''),('efe5ffbc1b341f3a5efb8f97fed82792','sys_file_metadata',8,'file','','','',0,0,'sys_file',8,''),('f0d6c1b2e6715768ca64011e501ca402','tt_content',266,'bodytext','','typolink_tag','270dccea89ad9178ee9552ab6c5b384f:1',-1,0,'tt_content',7,''),('f2e6fca58e49306bb461f131ba61a85a','sys_file_metadata',150,'file','','','',0,0,'sys_file',150,''),('f3dd5d2ff5a296310a1fb907730c2863','sys_file',49,'metadata','','','',0,0,'sys_file_metadata',49,''),('f553e622178ae41c17f4aa628cfe7c75','sys_file_reference',206,'uid_local','','','',0,0,'sys_file',134,''),('f5d62fa507b9a41a2e8627265abc1ae6','sys_file',74,'storage','','','',0,0,'sys_file_storage',1,''),('f68c0805e7b937b9dd993024a7e3e74f','sys_file',21,'metadata','','','',0,0,'sys_file_metadata',21,''),('f6aa798ddf3af217759f0c4ac2ffbe56','sys_file_reference',16,'uid_local','','','',0,0,'sys_file',13,''),('f8044c0435d4088839f2eead4a7bd4d6','sys_template',2,'constants','','url','12',-1,0,'_STRING',0,'https://github.com/t3brightside'),('f836388fb2eb4afbb27c6770f192e4cf','sys_file',114,'storage','','','',0,0,'sys_file_storage',1,''),('f89e1f5c2c517c7e1bde227ded31c82b','sys_file_metadata',41,'file','','','',0,0,'sys_file',41,''),('fb149e2ea3ae318985101d54c3757ca8','sys_file',34,'storage','','','',0,0,'sys_file_storage',1,''),('fc904066767cd2c01d906ff41eaf80c5','tt_content',163,'assets','','','',3,0,'sys_file_reference',206,''),('fd3745cd4c8a8104a41de0fdf20f0cca','sys_file_metadata',35,'file','','','',0,0,'sys_file',35,''),('fd7d102c97967eb7e9871a7aa480a68f','sys_file_metadata',46,'file','','','',0,0,'sys_file',46,''),('fdac21ac7f91c672e4b344d6ce39e503','sys_file',53,'storage','','','',0,0,'sys_file_storage',1,''),('fe6baa496480c7da7ee5b771fe029733','tx_personnel_domain_model_person',3,'email','','email','2',-1,0,'_STRING',0,'example@domain.com'),('fe996e77775f48360a2b04cd9f089783','sys_file',82,'metadata','','','',0,0,'sys_file_metadata',82,''),('ff66364ce763f8d256f9ab7ef8fd5add','sys_file_reference',205,'uid_local','','','',0,0,'sys_file',136,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=622 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ExtensionManagerTables','i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\WizardDoneToRegistry','i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\StartModuleUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FrontendUserImageUpdateWizard','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\DatabaseRowsUpdateWizard','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CommandLineBackendUserRemovalUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FillTranslationSourceField','i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SectionFrameToFrameClassUpdate','i:1;'),(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SplitMenusUpdate','i:1;'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BulletContentElementUpdate','i:1;'),(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\UploadContentElementUpdate','i:1;'),(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFscStaticTemplateUpdate','i:1;'),(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FileReferenceUpdate','i:1;'),(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateFeSessionDataUpdate','i:1;'),(15,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Compatibility7ExtractionUpdate','i:1;'),(16,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FormLegacyExtractionUpdate','i:1;'),(17,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RteHtmlAreaExtractionUpdate','i:1;'),(18,'installUpdate','TYPO3\\CMS\\Install\\Updates\\LanguageSortingUpdate','i:1;'),(19,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Typo3DbExtractionUpdate','i:1;'),(20,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FuncExtractionUpdate','i:1;'),(21,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateUrlTypesInPagesUpdate','i:1;'),(22,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SeparateSysHistoryFromSysLogUpdate','i:1;'),(23,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectExtractionUpdate','i:1;'),(24,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserStartModuleUpdate','i:1;'),(25,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayUpdate','i:1;'),(26,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayBeGroupsAccessRights','i:1;'),(27,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendLayoutIconUpdateWizard','i:1;'),(28,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectsExtensionUpdate','i:1;'),(29,'installUpdate','TYPO3\\CMS\\Install\\Updates\\AdminPanelInstall','i:1;'),(30,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PopulatePageSlugs','i:1;'),(31,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Argon2iPasswordHashes','i:1;'),(33,'extensionDataImport','typo3conf/ext/gridelements/ext_tables_static+adt.sql','s:0:\"\";'),(34,'extensionDataImport','typo3conf/ext/pagelist/ext_tables_static+adt.sql','s:0:\"\";'),(35,'extensionDataImport','typo3conf/ext/personnel/ext_tables_static+adt.sql','s:0:\"\";'),(36,'extensionDataImport','typo3conf/ext/youtubevideo/ext_tables_static+adt.sql','s:0:\"\";'),(37,'extensionDataImport','typo3conf/ext/metaplus/ext_tables_static+adt.sql','s:0:\"\";'),(38,'extensionDataImport','typo3conf/ext/microtemplate/ext_tables_static+adt.sql','s:0:\"\";'),(39,'extensionDataImport','typo3/sysext/recycler/ext_tables_static+adt.sql','s:0:\"\";'),(40,'extensionDataImport','typo3/sysext/scheduler/ext_tables_static+adt.sql','s:0:\"\";'),(41,'extensionDataImport','typo3conf/ext/advancedtitle/ext_tables_static+adt.sql','s:0:\"\";'),(42,'extensionDataImport','typo3conf/ext/favicon/ext_tables_static+adt.sql','s:0:\"\";'),(43,'extensionDataImport','typo3conf/ext/news/ext_tables_static+adt.sql','s:0:\"\";'),(44,'extensionDataImport','typo3/sysext/form/ext_tables_static+adt.sql','s:0:\"\";'),(47,'tx_scheduler','lastRun','a:3:{s:5:\"start\";i:1642087032;s:3:\"end\";i:1642087033;s:4:\"type\";s:6:\"manual\";}'),(49,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RsaauthExtractionUpdate','i:1;'),(50,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeeditExtractionUpdate','i:1;'),(51,'installUpdate','TYPO3\\CMS\\Install\\Updates\\TaskcenterExtractionUpdate','i:1;'),(52,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysActionExtractionUpdate','i:1;'),(53,'extensionDataImport','typo3conf/ext/staticfilecache/ext_tables_static+adt.sql','s:0:\"\";'),(55,'extensionDataImport','typo3conf/ext/gallerycontent/ext_tables_static+adt.sql','s:0:\"\";'),(60,'extensionDataImport','typo3conf/ext/form_to_database/ext_tables_static+adt.sql','s:0:\"\";'),(62,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),(63,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserLanguageMigration','i:1;'),(64,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogChannel','i:1;'),(65,'core','formProtectionSessionToken:3','s:64:\"a2cf043719e4e56d6f589bdf9dff784a3d22e421e0685aab0a0dd78fea454b16\";'),(66,'core','sys_refindex_lastUpdate','i:1679829963;'),(90,'core','formProtectionSessionToken:4','s:64:\"42eedeb138ccc62dbf61f11ed4937811e39ad4b3d4a148c16ed25746b36297de\";'),(201,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendGroupsExplicitAllowDenyMigration','i:1;'),(202,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileMountIdentifierMigration','i:1;'),(203,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate','i:1;'),(205,'core','formProtectionSessionToken:1','s:64:\"0e9d8de184a321e6a189391cc24acbafd8e948ed51cfb0011f634b082ce06b67\";'),(206,'extensionScannerNotAffected','1faef6b0562993ec8a054bed2ef2c93d','s:32:\"1faef6b0562993ec8a054bed2ef2c93d\";'),(207,'extensionScannerNotAffected','f416c9b17936bb2c9f6e525e3a2d10f7','s:32:\"f416c9b17936bb2c9f6e525e3a2d10f7\";'),(208,'extensionScannerNotAffected','6a69258d7e410abf281bb233ce1661b4','s:32:\"6a69258d7e410abf281bb233ce1661b4\";'),(209,'extensionScannerNotAffected','fd283cc724be66c8d6bed30408616ec0','s:32:\"fd283cc724be66c8d6bed30408616ec0\";'),(210,'extensionScannerNotAffected','3c562313c6689bc62fb848b678587f30','s:32:\"3c562313c6689bc62fb848b678587f30\";'),(211,'extensionScannerNotAffected','10491f982a8c97a285074bafecd4850c','s:32:\"10491f982a8c97a285074bafecd4850c\";'),(212,'extensionScannerNotAffected','1a768c46e0bc3222ecd5de6fa243e9c3','s:32:\"1a768c46e0bc3222ecd5de6fa243e9c3\";'),(213,'extensionScannerNotAffected','252e11cc4c45060b62906e765a69a9b9','s:32:\"252e11cc4c45060b62906e765a69a9b9\";'),(214,'extensionScannerNotAffected','7487ebac255315ebacdc2037d8703830','s:32:\"7487ebac255315ebacdc2037d8703830\";'),(215,'extensionScannerNotAffected','6a0bf83873b9e942825b66eafffa5b5e','s:32:\"6a0bf83873b9e942825b66eafffa5b5e\";'),(216,'extensionScannerNotAffected','a2c672f1cd58289b62009e699b3fb917','s:32:\"a2c672f1cd58289b62009e699b3fb917\";'),(217,'extensionScannerNotAffected','9461687a740bf75293500661c28dc086','s:32:\"9461687a740bf75293500661c28dc086\";'),(218,'extensionScannerNotAffected','92bde134c0712419f41b56cf75fade47','s:32:\"92bde134c0712419f41b56cf75fade47\";'),(219,'extensionScannerNotAffected','087c7a25d0ebc24b631f0200778af7aa','s:32:\"087c7a25d0ebc24b631f0200778af7aa\";'),(220,'extensionScannerNotAffected','e5bf6cace2a7bd01920f1b9d78fe6af3','s:32:\"e5bf6cace2a7bd01920f1b9d78fe6af3\";'),(221,'extensionScannerNotAffected','8d5d8fc5aaaa63362e0e66645e84cd04','s:32:\"8d5d8fc5aaaa63362e0e66645e84cd04\";'),(222,'extensionScannerNotAffected','b2184d0767b2c8db68fd1c71e99b09ae','s:32:\"b2184d0767b2c8db68fd1c71e99b09ae\";'),(223,'extensionScannerNotAffected','0161c1715c79c76be4bc0ca57f66ece2','s:32:\"0161c1715c79c76be4bc0ca57f66ece2\";'),(224,'extensionScannerNotAffected','a2d416eba69e875edc13e6e37169265d','s:32:\"a2d416eba69e875edc13e6e37169265d\";'),(225,'extensionScannerNotAffected','7c3dd0ff8c604268a31354f06ee49271','s:32:\"7c3dd0ff8c604268a31354f06ee49271\";'),(226,'extensionScannerNotAffected','901343ea26f5f0d78740ac282171e0ae','s:32:\"901343ea26f5f0d78740ac282171e0ae\";'),(227,'extensionScannerNotAffected','c8ae5ce15ce02f46a2c3a036d7073d54','s:32:\"c8ae5ce15ce02f46a2c3a036d7073d54\";'),(228,'extensionScannerNotAffected','8889d2cabb7a5d076d15574ffc9f0cf4','s:32:\"8889d2cabb7a5d076d15574ffc9f0cf4\";'),(229,'extensionScannerNotAffected','595ba7108ca292dcfe7c3684fd6ea490','s:32:\"595ba7108ca292dcfe7c3684fd6ea490\";'),(230,'extensionScannerNotAffected','f347e36ac973787adddfd05fe112ac0c','s:32:\"f347e36ac973787adddfd05fe112ac0c\";'),(231,'extensionScannerNotAffected','b1c85d92f1ac1d25fb0419a7d92bac49','s:32:\"b1c85d92f1ac1d25fb0419a7d92bac49\";'),(232,'extensionScannerNotAffected','8eaa532805aebdbb5e995b74d9b09502','s:32:\"8eaa532805aebdbb5e995b74d9b09502\";'),(233,'extensionScannerNotAffected','c62dc21e825d5deb840b8398aea22364','s:32:\"c62dc21e825d5deb840b8398aea22364\";'),(234,'extensionScannerNotAffected','8b5ea79532c9c1e51cf74c321d37d44d','s:32:\"8b5ea79532c9c1e51cf74c321d37d44d\";'),(235,'extensionScannerNotAffected','ba449b0ec547e6799851e556884d3cc9','s:32:\"ba449b0ec547e6799851e556884d3cc9\";'),(236,'extensionScannerNotAffected','7c086c7c671a702bbb19feb4bde0cce5','s:32:\"7c086c7c671a702bbb19feb4bde0cce5\";'),(237,'extensionScannerNotAffected','d713ed1319435c932ab25edc639efd48','s:32:\"d713ed1319435c932ab25edc639efd48\";'),(238,'extensionScannerNotAffected','1eea68e3ee257d2d55dcf5e34e549f46','s:32:\"1eea68e3ee257d2d55dcf5e34e549f46\";'),(239,'extensionScannerNotAffected','209c9172fd59c89a350cc212f8ce72ed','s:32:\"209c9172fd59c89a350cc212f8ce72ed\";'),(240,'extensionScannerNotAffected','81eecacac2cb8e30724923278d989190','s:32:\"81eecacac2cb8e30724923278d989190\";'),(241,'extensionScannerNotAffected','d0d0ce43c93e0695f3dc5e838a7ca747','s:32:\"d0d0ce43c93e0695f3dc5e838a7ca747\";'),(242,'extensionScannerNotAffected','ed59921fd9ba21c899a942f0853d0174','s:32:\"ed59921fd9ba21c899a942f0853d0174\";'),(243,'extensionScannerNotAffected','625a1f560231b99623efad8e1cfea17d','s:32:\"625a1f560231b99623efad8e1cfea17d\";'),(244,'extensionScannerNotAffected','cc33e6442844cdcd7750eeda6cefc5bd','s:32:\"cc33e6442844cdcd7750eeda6cefc5bd\";'),(245,'extensionScannerNotAffected','a2eaa3723e22394abc3a0bdb038a5a2d','s:32:\"a2eaa3723e22394abc3a0bdb038a5a2d\";'),(246,'extensionScannerNotAffected','8adb3cad3f824023512c4d59e05018f1','s:32:\"8adb3cad3f824023512c4d59e05018f1\";'),(247,'extensionScannerNotAffected','759b1697fd3cfc2c866993011cf40bcd','s:32:\"759b1697fd3cfc2c866993011cf40bcd\";'),(248,'extensionScannerNotAffected','0a02f6c26050f2843e94e6a02c8b9f31','s:32:\"0a02f6c26050f2843e94e6a02c8b9f31\";'),(249,'extensionScannerNotAffected','738d136046e3786fa7697ed7a9599e75','s:32:\"738d136046e3786fa7697ed7a9599e75\";'),(250,'extensionScannerNotAffected','41f5925b02b9cd0184b4a9a60445591e','s:32:\"41f5925b02b9cd0184b4a9a60445591e\";'),(251,'extensionScannerNotAffected','cf30296fc712c5019f9e41ad7b391d05','s:32:\"cf30296fc712c5019f9e41ad7b391d05\";'),(252,'extensionScannerNotAffected','85b0efe4750aedf3673dbdee06fb4659','s:32:\"85b0efe4750aedf3673dbdee06fb4659\";'),(253,'extensionScannerNotAffected','b4b04b96018216823f4ae488ef33f5e2','s:32:\"b4b04b96018216823f4ae488ef33f5e2\";'),(254,'extensionScannerNotAffected','a3cf1408f6b2c8797d4250c6fc15af28','s:32:\"a3cf1408f6b2c8797d4250c6fc15af28\";'),(255,'extensionScannerNotAffected','72fbcb357d250400dd199c53e4c9fd2a','s:32:\"72fbcb357d250400dd199c53e4c9fd2a\";'),(256,'extensionScannerNotAffected','9fe7d021d2fa5a417f5e063887ee14c7','s:32:\"9fe7d021d2fa5a417f5e063887ee14c7\";'),(257,'extensionScannerNotAffected','7da735b8ec41537724eac26c7e124e8e','s:32:\"7da735b8ec41537724eac26c7e124e8e\";'),(258,'extensionScannerNotAffected','b745a90643fc5296a0b2009f83de8533','s:32:\"b745a90643fc5296a0b2009f83de8533\";'),(259,'extensionScannerNotAffected','dc291f82d5ef4d17dd152bc0035378d7','s:32:\"dc291f82d5ef4d17dd152bc0035378d7\";'),(260,'extensionScannerNotAffected','6de1c713d7186d98adea577a8143421f','s:32:\"6de1c713d7186d98adea577a8143421f\";'),(261,'extensionScannerNotAffected','d4711b0253657ca879c919dfac68f6cb','s:32:\"d4711b0253657ca879c919dfac68f6cb\";'),(262,'extensionScannerNotAffected','db080fcfa58a6ff0c463a7194a7f2d53','s:32:\"db080fcfa58a6ff0c463a7194a7f2d53\";'),(263,'extensionScannerNotAffected','ae49edc5d81324435d65b41a94a45f15','s:32:\"ae49edc5d81324435d65b41a94a45f15\";'),(264,'extensionScannerNotAffected','dc86a1c15cb13a0627dcd562712a3493','s:32:\"dc86a1c15cb13a0627dcd562712a3493\";'),(265,'extensionScannerNotAffected','54b140e518734e045c84661ccf91326b','s:32:\"54b140e518734e045c84661ccf91326b\";'),(266,'extensionScannerNotAffected','3ed29a6e143843d495b7813535aaed1e','s:32:\"3ed29a6e143843d495b7813535aaed1e\";'),(267,'extensionScannerNotAffected','195568ce7afd80c6e6c54230d28c878e','s:32:\"195568ce7afd80c6e6c54230d28c878e\";'),(268,'extensionScannerNotAffected','e78e0aaec884228c9ddb207dcba3fdcb','s:32:\"e78e0aaec884228c9ddb207dcba3fdcb\";'),(269,'extensionScannerNotAffected','8b1b4c666f981d018261756563fa7a51','s:32:\"8b1b4c666f981d018261756563fa7a51\";'),(270,'extensionScannerNotAffected','9c169afac1995c48f1d08585420afb2e','s:32:\"9c169afac1995c48f1d08585420afb2e\";'),(271,'extensionScannerNotAffected','217fe2d7f41bb756e4c408a8d612bd25','s:32:\"217fe2d7f41bb756e4c408a8d612bd25\";'),(272,'extensionScannerNotAffected','dc58d384de76019c3b59743f42273d25','s:32:\"dc58d384de76019c3b59743f42273d25\";'),(273,'extensionScannerNotAffected','07dcd6a4ab34b7b776e320d8bf8ff4e1','s:32:\"07dcd6a4ab34b7b776e320d8bf8ff4e1\";'),(274,'extensionScannerNotAffected','bad8815536fffa9c5b081b6c38c45811','s:32:\"bad8815536fffa9c5b081b6c38c45811\";'),(275,'extensionScannerNotAffected','edbf3c3ff5463311f0ce6d953638a2c7','s:32:\"edbf3c3ff5463311f0ce6d953638a2c7\";'),(276,'extensionScannerNotAffected','d0ea2c1615870e16ce17ddd181604a4d','s:32:\"d0ea2c1615870e16ce17ddd181604a4d\";'),(277,'extensionScannerNotAffected','8ba8c53900fd266b9d2eea5d2746fd53','s:32:\"8ba8c53900fd266b9d2eea5d2746fd53\";'),(278,'extensionScannerNotAffected','1cd8ab1c12378c570ec4e66227aff97c','s:32:\"1cd8ab1c12378c570ec4e66227aff97c\";'),(279,'extensionScannerNotAffected','f5ce4e049277aa36fc83303bcb6055b1','s:32:\"f5ce4e049277aa36fc83303bcb6055b1\";'),(280,'extensionScannerNotAffected','14fd13563d1f17fb4db9cb11864048de','s:32:\"14fd13563d1f17fb4db9cb11864048de\";'),(281,'extensionScannerNotAffected','05bbe791e33558b09f8f30f00155ac37','s:32:\"05bbe791e33558b09f8f30f00155ac37\";'),(282,'extensionScannerNotAffected','c0aa129dac148fa44ab4c912d5b5cfcb','s:32:\"c0aa129dac148fa44ab4c912d5b5cfcb\";'),(283,'extensionScannerNotAffected','e4582c4edcb5b7f4b9c1b2b09f0de8ac','s:32:\"e4582c4edcb5b7f4b9c1b2b09f0de8ac\";'),(284,'extensionScannerNotAffected','110b117081a2e2d2a876a7f69799060b','s:32:\"110b117081a2e2d2a876a7f69799060b\";'),(285,'extensionScannerNotAffected','54a4661a0a79695809480784d49b3fc1','s:32:\"54a4661a0a79695809480784d49b3fc1\";'),(286,'extensionScannerNotAffected','6590b836e87a4be9ea0326c6bebce7b0','s:32:\"6590b836e87a4be9ea0326c6bebce7b0\";'),(287,'extensionScannerNotAffected','fcdf9ed05d525c1354d9c5c7ab043c17','s:32:\"fcdf9ed05d525c1354d9c5c7ab043c17\";'),(288,'extensionScannerNotAffected','3c47e3798a565d74d9fc990b8093ba50','s:32:\"3c47e3798a565d74d9fc990b8093ba50\";'),(289,'extensionScannerNotAffected','f93b9500411ad5e214034757a971e09a','s:32:\"f93b9500411ad5e214034757a971e09a\";'),(290,'extensionScannerNotAffected','343f573ef870e727d900672f5c55b58d','s:32:\"343f573ef870e727d900672f5c55b58d\";'),(291,'extensionScannerNotAffected','0cce48811ea2ce1b1bb690a78b7c1c26','s:32:\"0cce48811ea2ce1b1bb690a78b7c1c26\";'),(292,'extensionScannerNotAffected','a56c3d280b72b38afb1ec1102390754c','s:32:\"a56c3d280b72b38afb1ec1102390754c\";'),(293,'extensionScannerNotAffected','94e665a09f15f32a4c8980422a87e8c6','s:32:\"94e665a09f15f32a4c8980422a87e8c6\";'),(294,'extensionScannerNotAffected','c6f081ec6d0595b63f2c36afcbb06e0a','s:32:\"c6f081ec6d0595b63f2c36afcbb06e0a\";'),(295,'extensionScannerNotAffected','23f9c88fbd4fc32a43aa91484c28875d','s:32:\"23f9c88fbd4fc32a43aa91484c28875d\";'),(296,'extensionScannerNotAffected','71c476013c0eff29b821b97ebcf22729','s:32:\"71c476013c0eff29b821b97ebcf22729\";'),(297,'extensionScannerNotAffected','766c7969440bf79b6c81ee839c0e28d2','s:32:\"766c7969440bf79b6c81ee839c0e28d2\";'),(298,'extensionScannerNotAffected','01877cb58cc6718143d454af0e22e7a1','s:32:\"01877cb58cc6718143d454af0e22e7a1\";'),(299,'extensionScannerNotAffected','13c07913127ab79a0b19f2381c27dbc5','s:32:\"13c07913127ab79a0b19f2381c27dbc5\";'),(300,'extensionScannerNotAffected','f0de3d2d6407343dbdaa2aa46a029589','s:32:\"f0de3d2d6407343dbdaa2aa46a029589\";'),(301,'extensionScannerNotAffected','98877f6c0f3d08bab2c8905e658909bd','s:32:\"98877f6c0f3d08bab2c8905e658909bd\";'),(302,'extensionScannerNotAffected','2d8c13760adab1f09bc60cb2e755a702','s:32:\"2d8c13760adab1f09bc60cb2e755a702\";'),(303,'extensionScannerNotAffected','12d2cf32eb677dc029d573366841e5be','s:32:\"12d2cf32eb677dc029d573366841e5be\";'),(304,'extensionScannerNotAffected','09f06ea508acbec6a1d1cfcec1cdc341','s:32:\"09f06ea508acbec6a1d1cfcec1cdc341\";'),(305,'extensionScannerNotAffected','9c901fade5881d2d6b86cab31374afa2','s:32:\"9c901fade5881d2d6b86cab31374afa2\";'),(306,'extensionScannerNotAffected','ab50726177c2478d1c74e36ee28a72a0','s:32:\"ab50726177c2478d1c74e36ee28a72a0\";'),(307,'extensionScannerNotAffected','74bb572d676afda82986e28117e7b83a','s:32:\"74bb572d676afda82986e28117e7b83a\";'),(308,'extensionScannerNotAffected','8ff4781e994ca9651c6c2ca3af9ca1af','s:32:\"8ff4781e994ca9651c6c2ca3af9ca1af\";'),(309,'extensionScannerNotAffected','9fd8b5ab403710c4f351958450fe16e5','s:32:\"9fd8b5ab403710c4f351958450fe16e5\";'),(310,'extensionScannerNotAffected','af4912b503cec16f4f683299246fb13d','s:32:\"af4912b503cec16f4f683299246fb13d\";'),(311,'extensionScannerNotAffected','1d4942180d68f2945c11546228dd046b','s:32:\"1d4942180d68f2945c11546228dd046b\";'),(312,'extensionScannerNotAffected','0cd3cea5ce9cf53bb878d834fe978834','s:32:\"0cd3cea5ce9cf53bb878d834fe978834\";'),(313,'extensionScannerNotAffected','0b6fbaa43e4fa4039c709df5e37cb9ea','s:32:\"0b6fbaa43e4fa4039c709df5e37cb9ea\";'),(314,'extensionScannerNotAffected','63ac38f1ce52667e677c6d3b92d2343d','s:32:\"63ac38f1ce52667e677c6d3b92d2343d\";'),(315,'extensionScannerNotAffected','176228940ec6d0ebf8bd09b17a327eab','s:32:\"176228940ec6d0ebf8bd09b17a327eab\";'),(316,'extensionScannerNotAffected','1bed3603d8260f87eb3cc32df434a692','s:32:\"1bed3603d8260f87eb3cc32df434a692\";'),(317,'extensionScannerNotAffected','ccdc92eac42157b5151a29dd1a631eac','s:32:\"ccdc92eac42157b5151a29dd1a631eac\";'),(318,'extensionScannerNotAffected','d954a4fe5723e5c621c625eb5b71f92d','s:32:\"d954a4fe5723e5c621c625eb5b71f92d\";'),(319,'extensionScannerNotAffected','915f89ba7007d23066d966232ddaf5c9','s:32:\"915f89ba7007d23066d966232ddaf5c9\";'),(320,'extensionScannerNotAffected','9886bc3921cbde67d0f86a4cbcd3d6ab','s:32:\"9886bc3921cbde67d0f86a4cbcd3d6ab\";'),(321,'extensionScannerNotAffected','400915f740ff0d95c494ec029d4fa99e','s:32:\"400915f740ff0d95c494ec029d4fa99e\";'),(322,'extensionScannerNotAffected','5d754ca0288ee2174388230e92b91ead','s:32:\"5d754ca0288ee2174388230e92b91ead\";'),(323,'extensionScannerNotAffected','1422bec9f8bbb27eeede573b31e65c6a','s:32:\"1422bec9f8bbb27eeede573b31e65c6a\";'),(324,'extensionScannerNotAffected','d7141cecea6548e7153471910c0c7082','s:32:\"d7141cecea6548e7153471910c0c7082\";'),(325,'extensionScannerNotAffected','9bcb0bd6f5682a33b489eecf20189b91','s:32:\"9bcb0bd6f5682a33b489eecf20189b91\";'),(326,'extensionScannerNotAffected','f3e3e87a6287a82abc502befd2ae9262','s:32:\"f3e3e87a6287a82abc502befd2ae9262\";'),(327,'extensionScannerNotAffected','df957f25f5fcb2a650be7a902d046d5f','s:32:\"df957f25f5fcb2a650be7a902d046d5f\";'),(328,'extensionScannerNotAffected','ed0b1db5ff7c2db0b25623635acfb661','s:32:\"ed0b1db5ff7c2db0b25623635acfb661\";'),(329,'extensionScannerNotAffected','87dfebfd4c19f7e4b9b7d35544e59800','s:32:\"87dfebfd4c19f7e4b9b7d35544e59800\";'),(330,'extensionScannerNotAffected','a303c1518194f40e675ea712b92d897e','s:32:\"a303c1518194f40e675ea712b92d897e\";'),(331,'extensionScannerNotAffected','d53f132a55d2f23d56b4ceb73ffa3bdc','s:32:\"d53f132a55d2f23d56b4ceb73ffa3bdc\";'),(332,'extensionScannerNotAffected','344a90c7e0053be0c693dff2c8006acf','s:32:\"344a90c7e0053be0c693dff2c8006acf\";'),(333,'extensionScannerNotAffected','1c2f4d48334dfda58273b2d9d4d82771','s:32:\"1c2f4d48334dfda58273b2d9d4d82771\";'),(334,'extensionScannerNotAffected','85deaeb5619bf22362f08cb09e680efc','s:32:\"85deaeb5619bf22362f08cb09e680efc\";'),(335,'extensionScannerNotAffected','d678bbe44635ebe8bce726d708c7a80a','s:32:\"d678bbe44635ebe8bce726d708c7a80a\";'),(336,'extensionScannerNotAffected','9dc6000ae9b28143304b92a50c848724','s:32:\"9dc6000ae9b28143304b92a50c848724\";'),(337,'extensionScannerNotAffected','f273cca2ccce3ffd5a2ecfff8b28f365','s:32:\"f273cca2ccce3ffd5a2ecfff8b28f365\";'),(338,'extensionScannerNotAffected','abfeef94e8f69dff3c2351e0fb258c64','s:32:\"abfeef94e8f69dff3c2351e0fb258c64\";'),(339,'extensionScannerNotAffected','2c6025c21906acd5224231278951a73c','s:32:\"2c6025c21906acd5224231278951a73c\";'),(340,'extensionScannerNotAffected','ade09d1df6614f6ab7469887f5d2d248','s:32:\"ade09d1df6614f6ab7469887f5d2d248\";'),(341,'extensionScannerNotAffected','9866b0b48efd56e4845f5ee54a15178e','s:32:\"9866b0b48efd56e4845f5ee54a15178e\";'),(342,'extensionScannerNotAffected','1dbe8708a0f10bd80e34c0e75e68b1fd','s:32:\"1dbe8708a0f10bd80e34c0e75e68b1fd\";'),(343,'extensionScannerNotAffected','c80e4f8f0f7311133c8bbaca3d457b73','s:32:\"c80e4f8f0f7311133c8bbaca3d457b73\";'),(344,'extensionScannerNotAffected','324e28d10fd1d464bc8145e775dda6ae','s:32:\"324e28d10fd1d464bc8145e775dda6ae\";'),(345,'extensionScannerNotAffected','17b2a3df8ff87d4e93d7cb8eb2b772e9','s:32:\"17b2a3df8ff87d4e93d7cb8eb2b772e9\";'),(346,'extensionScannerNotAffected','3fe70aa1f2c5e78750cbdefd56447f3c','s:32:\"3fe70aa1f2c5e78750cbdefd56447f3c\";'),(347,'extensionScannerNotAffected','e6259480e6f36dc930821269d1a589ae','s:32:\"e6259480e6f36dc930821269d1a589ae\";'),(348,'extensionScannerNotAffected','9af17b92bffa30bac327e0abc02ca7cd','s:32:\"9af17b92bffa30bac327e0abc02ca7cd\";'),(349,'extensionScannerNotAffected','2824b8876243a2d39c2a6837ca996e2a','s:32:\"2824b8876243a2d39c2a6837ca996e2a\";'),(350,'extensionScannerNotAffected','c9bec55731d0544d95274453e56f6ef4','s:32:\"c9bec55731d0544d95274453e56f6ef4\";'),(351,'extensionScannerNotAffected','9eb6e6bad95bc6e4eab2d956f7a4b4cc','s:32:\"9eb6e6bad95bc6e4eab2d956f7a4b4cc\";'),(352,'extensionScannerNotAffected','b09ec2731f29170c2f0f5609153f6ebe','s:32:\"b09ec2731f29170c2f0f5609153f6ebe\";'),(353,'extensionScannerNotAffected','b70d7d6c6305141700464904600fc232','s:32:\"b70d7d6c6305141700464904600fc232\";'),(354,'extensionScannerNotAffected','898c41fd59415c24ecfa193e8ff8c13d','s:32:\"898c41fd59415c24ecfa193e8ff8c13d\";'),(355,'extensionScannerNotAffected','59f26cab8fae72894d4867b334d914b0','s:32:\"59f26cab8fae72894d4867b334d914b0\";'),(356,'extensionScannerNotAffected','0a7d587bcf91e38382ac8bb270dae721','s:32:\"0a7d587bcf91e38382ac8bb270dae721\";'),(357,'extensionScannerNotAffected','8bea9d810503cbeafd3ec1eeb5889b29','s:32:\"8bea9d810503cbeafd3ec1eeb5889b29\";'),(358,'extensionScannerNotAffected','737e9b4d966382ffda13162e4faebf5e','s:32:\"737e9b4d966382ffda13162e4faebf5e\";'),(359,'extensionScannerNotAffected','7e75dac7391b40c952a673633b06fdf7','s:32:\"7e75dac7391b40c952a673633b06fdf7\";'),(360,'extensionScannerNotAffected','7bcf1948811d1042a25e123663ca6fb2','s:32:\"7bcf1948811d1042a25e123663ca6fb2\";'),(361,'extensionScannerNotAffected','6b59d48adbb52a285bd6dedd821181fd','s:32:\"6b59d48adbb52a285bd6dedd821181fd\";'),(362,'extensionScannerNotAffected','a859d1492a9608a5b3033ef9386f70cd','s:32:\"a859d1492a9608a5b3033ef9386f70cd\";'),(363,'extensionScannerNotAffected','3e49e0f18a1d972eb0f0e2d9331c3adc','s:32:\"3e49e0f18a1d972eb0f0e2d9331c3adc\";'),(364,'extensionScannerNotAffected','d9ab2a929768eef40427dbba78475e0b','s:32:\"d9ab2a929768eef40427dbba78475e0b\";'),(365,'extensionScannerNotAffected','21d21b236ac7b67c7db7a19bdab6c8d6','s:32:\"21d21b236ac7b67c7db7a19bdab6c8d6\";'),(366,'extensionScannerNotAffected','e6149f464b533888fda416c97196b480','s:32:\"e6149f464b533888fda416c97196b480\";'),(367,'extensionScannerNotAffected','8386a8482642549e47699bb9932c597c','s:32:\"8386a8482642549e47699bb9932c597c\";'),(368,'extensionScannerNotAffected','471a2e9555c860e3455df935b2ae267c','s:32:\"471a2e9555c860e3455df935b2ae267c\";'),(369,'extensionScannerNotAffected','b8606ea80291cdb9967ae99134458d6e','s:32:\"b8606ea80291cdb9967ae99134458d6e\";'),(370,'extensionScannerNotAffected','2686fc92f56974b8c177b1037edb7802','s:32:\"2686fc92f56974b8c177b1037edb7802\";'),(371,'extensionScannerNotAffected','5b94ae0411266b07650f0780cda37f4e','s:32:\"5b94ae0411266b07650f0780cda37f4e\";'),(372,'extensionScannerNotAffected','17b6b7eaebaee383f8aa2c60388a9ba6','s:32:\"17b6b7eaebaee383f8aa2c60388a9ba6\";'),(373,'extensionScannerNotAffected','2ec427290f951b808ac206c264b0a8ea','s:32:\"2ec427290f951b808ac206c264b0a8ea\";'),(374,'extensionScannerNotAffected','7e3a05e76ce4a0a9337876500601bee3','s:32:\"7e3a05e76ce4a0a9337876500601bee3\";'),(375,'extensionScannerNotAffected','f3a54a6f1d13f03504745af117dcc032','s:32:\"f3a54a6f1d13f03504745af117dcc032\";'),(376,'extensionScannerNotAffected','72fda82a23e71be951eb74b45e7554d2','s:32:\"72fda82a23e71be951eb74b45e7554d2\";'),(377,'extensionScannerNotAffected','6fa734df2c37c25dc45e90aaa43bfb65','s:32:\"6fa734df2c37c25dc45e90aaa43bfb65\";'),(378,'extensionScannerNotAffected','adfee89e126e184e8813de4f39fab1c5','s:32:\"adfee89e126e184e8813de4f39fab1c5\";'),(379,'extensionScannerNotAffected','dffce21225dad8ce1b65ee0e8263be81','s:32:\"dffce21225dad8ce1b65ee0e8263be81\";'),(380,'extensionScannerNotAffected','a1bcabf0b593700aa64f6318b676eff6','s:32:\"a1bcabf0b593700aa64f6318b676eff6\";'),(381,'extensionScannerNotAffected','cd41e90753126eec12c9636b476d88e7','s:32:\"cd41e90753126eec12c9636b476d88e7\";'),(382,'extensionScannerNotAffected','5360dcf47c8467e899195bc2238e3034','s:32:\"5360dcf47c8467e899195bc2238e3034\";'),(383,'extensionScannerNotAffected','cc3032da10c33172c022073233fb2073','s:32:\"cc3032da10c33172c022073233fb2073\";'),(384,'extensionScannerNotAffected','c97ef638506e95d3fba0f04850f9b733','s:32:\"c97ef638506e95d3fba0f04850f9b733\";'),(385,'extensionScannerNotAffected','8bdd67afcd45687f5a10912a93993e21','s:32:\"8bdd67afcd45687f5a10912a93993e21\";'),(386,'extensionScannerNotAffected','8f5fa21fab02544da90f243885c33907','s:32:\"8f5fa21fab02544da90f243885c33907\";'),(387,'extensionScannerNotAffected','2f51daeacc3ec70cb1feb4f3473be0f8','s:32:\"2f51daeacc3ec70cb1feb4f3473be0f8\";'),(388,'extensionScannerNotAffected','0aa3a077801aeec1378e15f48fd04085','s:32:\"0aa3a077801aeec1378e15f48fd04085\";'),(389,'extensionScannerNotAffected','8cb9af86b0f5c3be3f458e2ae616b8d9','s:32:\"8cb9af86b0f5c3be3f458e2ae616b8d9\";'),(390,'extensionScannerNotAffected','b664fdd3c37899aed1984ad83d8e840c','s:32:\"b664fdd3c37899aed1984ad83d8e840c\";'),(391,'extensionScannerNotAffected','836cf172821154f36eb8d943f494c416','s:32:\"836cf172821154f36eb8d943f494c416\";'),(392,'extensionScannerNotAffected','6998fe944bf6376b184805ed00e16784','s:32:\"6998fe944bf6376b184805ed00e16784\";'),(393,'extensionScannerNotAffected','192975d53cd934a17614d613115fc5f0','s:32:\"192975d53cd934a17614d613115fc5f0\";'),(394,'extensionScannerNotAffected','e33ea194d97ec367bdab714ff02be462','s:32:\"e33ea194d97ec367bdab714ff02be462\";'),(395,'extensionScannerNotAffected','a33b9f4dd4f5da96a4c5c2a674102c42','s:32:\"a33b9f4dd4f5da96a4c5c2a674102c42\";'),(396,'extensionScannerNotAffected','2f4ef542b7e12539f1c858bf142c4c1c','s:32:\"2f4ef542b7e12539f1c858bf142c4c1c\";'),(397,'extensionScannerNotAffected','4346f09e5036ab5e9b0bbcd39d796e31','s:32:\"4346f09e5036ab5e9b0bbcd39d796e31\";'),(398,'extensionScannerNotAffected','85191e2718f47805bca9eaca48df37f7','s:32:\"85191e2718f47805bca9eaca48df37f7\";'),(399,'extensionScannerNotAffected','da91a8846d40aa2a08537f88cbf9d67b','s:32:\"da91a8846d40aa2a08537f88cbf9d67b\";'),(400,'extensionScannerNotAffected','cb3b34610c5a08d40e9bb6b9934f4281','s:32:\"cb3b34610c5a08d40e9bb6b9934f4281\";'),(401,'extensionScannerNotAffected','de4f78129ccd0ff356b1decf529cdb97','s:32:\"de4f78129ccd0ff356b1decf529cdb97\";'),(402,'extensionScannerNotAffected','865bb7d2bc4f13fa6270bfc21095c96b','s:32:\"865bb7d2bc4f13fa6270bfc21095c96b\";'),(403,'extensionScannerNotAffected','338425e76cbfa9ab68fa513a4f9a8da8','s:32:\"338425e76cbfa9ab68fa513a4f9a8da8\";'),(404,'extensionScannerNotAffected','113e37a399eca4d97593a5c63758bd90','s:32:\"113e37a399eca4d97593a5c63758bd90\";'),(405,'extensionScannerNotAffected','8bb3f19abdcc30cd9803055ed60ed696','s:32:\"8bb3f19abdcc30cd9803055ed60ed696\";'),(406,'extensionScannerNotAffected','b8e3638d5f10b52a6383642591e0389b','s:32:\"b8e3638d5f10b52a6383642591e0389b\";'),(407,'extensionScannerNotAffected','2f24b3647e448d26dd247b6f84ee1622','s:32:\"2f24b3647e448d26dd247b6f84ee1622\";'),(408,'extensionScannerNotAffected','7b3bdad6f4a6f29903ca75c1d78c9045','s:32:\"7b3bdad6f4a6f29903ca75c1d78c9045\";'),(409,'extensionScannerNotAffected','8e7ba344126721feb3d3b70cb492ae62','s:32:\"8e7ba344126721feb3d3b70cb492ae62\";'),(410,'extensionScannerNotAffected','9de4b2449f0b5592583a3483442f26fa','s:32:\"9de4b2449f0b5592583a3483442f26fa\";'),(411,'extensionScannerNotAffected','31488ac80433722392a6f101443e456c','s:32:\"31488ac80433722392a6f101443e456c\";'),(412,'extensionScannerNotAffected','91299ca37f2ff269a177dc8997a313a9','s:32:\"91299ca37f2ff269a177dc8997a313a9\";'),(413,'extensionScannerNotAffected','33615382b70df5f5c9188014025efb3b','s:32:\"33615382b70df5f5c9188014025efb3b\";'),(414,'extensionScannerNotAffected','3ca8182b629890f563c3f96af63cc508','s:32:\"3ca8182b629890f563c3f96af63cc508\";'),(415,'extensionScannerNotAffected','22c96e35d7df82b64644722ae115d8ef','s:32:\"22c96e35d7df82b64644722ae115d8ef\";'),(416,'extensionScannerNotAffected','5ac57be87683e4c7e1edbb04f004ed02','s:32:\"5ac57be87683e4c7e1edbb04f004ed02\";'),(417,'extensionScannerNotAffected','b507d9617d8ab776b739c285ef8f82e1','s:32:\"b507d9617d8ab776b739c285ef8f82e1\";'),(418,'extensionScannerNotAffected','22429ca46d8b1e925ca537dc189b1f45','s:32:\"22429ca46d8b1e925ca537dc189b1f45\";'),(419,'extensionScannerNotAffected','0ae3c5822c70a6ba35463962ec93a19d','s:32:\"0ae3c5822c70a6ba35463962ec93a19d\";'),(420,'extensionScannerNotAffected','e4513c8aec99e02d734d6c88f0cf5d45','s:32:\"e4513c8aec99e02d734d6c88f0cf5d45\";'),(421,'extensionScannerNotAffected','c9ab262630b4a1f349cf2ec45b822cda','s:32:\"c9ab262630b4a1f349cf2ec45b822cda\";'),(422,'extensionScannerNotAffected','042610074ad3436e7eefc7bf5c6cc810','s:32:\"042610074ad3436e7eefc7bf5c6cc810\";'),(423,'extensionScannerNotAffected','a95d350b20474d9e420dfe2b981b26e1','s:32:\"a95d350b20474d9e420dfe2b981b26e1\";'),(424,'extensionScannerNotAffected','c3275b175cc1d3488a5c1febc17e81d3','s:32:\"c3275b175cc1d3488a5c1febc17e81d3\";'),(425,'extensionScannerNotAffected','d4ecb764ccfaaad1965aa3de4c1538ec','s:32:\"d4ecb764ccfaaad1965aa3de4c1538ec\";'),(426,'extensionScannerNotAffected','1fab2904a16a5857dcb58251137d1628','s:32:\"1fab2904a16a5857dcb58251137d1628\";'),(427,'extensionScannerNotAffected','7a9d2755e712863f5b21964b8875296f','s:32:\"7a9d2755e712863f5b21964b8875296f\";'),(428,'extensionScannerNotAffected','67cc8ccda99af7f5b4c650ebc9cf0118','s:32:\"67cc8ccda99af7f5b4c650ebc9cf0118\";'),(429,'extensionScannerNotAffected','ce1cc4420d0a93076afd4ac6a4483def','s:32:\"ce1cc4420d0a93076afd4ac6a4483def\";'),(430,'extensionScannerNotAffected','30a11b57255b9e69def26e40e51a2692','s:32:\"30a11b57255b9e69def26e40e51a2692\";'),(431,'extensionScannerNotAffected','1e29f401ebde3aa98a5baacfd54c947e','s:32:\"1e29f401ebde3aa98a5baacfd54c947e\";'),(432,'extensionScannerNotAffected','0ae318dfe4b78d7da63e3794ab200db2','s:32:\"0ae318dfe4b78d7da63e3794ab200db2\";'),(433,'extensionScannerNotAffected','f942095aff6efa110444fc2d6aa72a19','s:32:\"f942095aff6efa110444fc2d6aa72a19\";'),(434,'extensionScannerNotAffected','d5360c9d1e21fdeda265108180abac53','s:32:\"d5360c9d1e21fdeda265108180abac53\";'),(435,'extensionScannerNotAffected','ce689b3c60bc6af2962c1033fa6fcfcd','s:32:\"ce689b3c60bc6af2962c1033fa6fcfcd\";'),(436,'extensionScannerNotAffected','355ca000e0f66c61fd554241cb95b202','s:32:\"355ca000e0f66c61fd554241cb95b202\";'),(437,'extensionScannerNotAffected','d7c5e769cde14fb4dfd385967d36975a','s:32:\"d7c5e769cde14fb4dfd385967d36975a\";'),(438,'extensionScannerNotAffected','e0bdc5e387014314b68c8459edfdc092','s:32:\"e0bdc5e387014314b68c8459edfdc092\";'),(439,'extensionScannerNotAffected','a458c39dd7c35c469051c0832f87c40a','s:32:\"a458c39dd7c35c469051c0832f87c40a\";'),(440,'extensionScannerNotAffected','39b05c57979e382cc79298e1fc2f1413','s:32:\"39b05c57979e382cc79298e1fc2f1413\";'),(441,'extensionScannerNotAffected','2d41669f9c242cb93b89b0954adbe1a7','s:32:\"2d41669f9c242cb93b89b0954adbe1a7\";'),(442,'extensionScannerNotAffected','a3fcdb0b710f4434650f1e23238726b9','s:32:\"a3fcdb0b710f4434650f1e23238726b9\";'),(443,'extensionScannerNotAffected','aa061d6fd6844d166886a02468a2c8c7','s:32:\"aa061d6fd6844d166886a02468a2c8c7\";'),(444,'extensionScannerNotAffected','e5fb8959e90ef8f85797eac0c831db45','s:32:\"e5fb8959e90ef8f85797eac0c831db45\";'),(445,'extensionScannerNotAffected','8bd94ed0ef4d4449d731396d3eca2950','s:32:\"8bd94ed0ef4d4449d731396d3eca2950\";'),(446,'extensionScannerNotAffected','6b3ac9fb900b2e53de8248364574e48f','s:32:\"6b3ac9fb900b2e53de8248364574e48f\";'),(447,'extensionScannerNotAffected','0c44bac06883c5ea942a91bc2edacdfb','s:32:\"0c44bac06883c5ea942a91bc2edacdfb\";'),(448,'extensionScannerNotAffected','0f49206e1150f80bdb80eaa5e4fd2ecf','s:32:\"0f49206e1150f80bdb80eaa5e4fd2ecf\";'),(449,'extensionScannerNotAffected','d20f8da2eb1cb7a7eca52a145fc787e2','s:32:\"d20f8da2eb1cb7a7eca52a145fc787e2\";'),(450,'extensionScannerNotAffected','fb5a3f0af01005c18639082b1a404b69','s:32:\"fb5a3f0af01005c18639082b1a404b69\";'),(451,'extensionScannerNotAffected','f5fd76fc9907cd3fe609e44a72657f1c','s:32:\"f5fd76fc9907cd3fe609e44a72657f1c\";'),(452,'extensionScannerNotAffected','6c8b81e030762c668def5fdaad99ab54','s:32:\"6c8b81e030762c668def5fdaad99ab54\";'),(453,'extensionScannerNotAffected','6763b0d6e9b6bc5ec9e7622ba04761dc','s:32:\"6763b0d6e9b6bc5ec9e7622ba04761dc\";'),(454,'extensionScannerNotAffected','cb8a107c133de25112085547cb51fee7','s:32:\"cb8a107c133de25112085547cb51fee7\";'),(455,'extensionScannerNotAffected','a7056572c1b4cdb727e48c6a28b4e528','s:32:\"a7056572c1b4cdb727e48c6a28b4e528\";'),(456,'extensionScannerNotAffected','da0efe14d3cb2782a53ab02ccc85f5a1','s:32:\"da0efe14d3cb2782a53ab02ccc85f5a1\";'),(457,'extensionScannerNotAffected','b7ef0ef7adc26e716130fb74dee0a4fd','s:32:\"b7ef0ef7adc26e716130fb74dee0a4fd\";'),(458,'extensionScannerNotAffected','6bdd13c460d24f22a219d91d121d7fb9','s:32:\"6bdd13c460d24f22a219d91d121d7fb9\";'),(459,'extensionScannerNotAffected','a69448c1b682bf753c4fabfae77e2b03','s:32:\"a69448c1b682bf753c4fabfae77e2b03\";'),(460,'extensionScannerNotAffected','e3f754d8dad6184cb0ad5b03d686b8cb','s:32:\"e3f754d8dad6184cb0ad5b03d686b8cb\";'),(461,'extensionScannerNotAffected','165330c2d09a53d009204a19b538e568','s:32:\"165330c2d09a53d009204a19b538e568\";'),(462,'extensionScannerNotAffected','160b52118d33ad5c149fd859e43ddd70','s:32:\"160b52118d33ad5c149fd859e43ddd70\";'),(463,'extensionScannerNotAffected','3545b03c4525f913e50a3a7b0141985e','s:32:\"3545b03c4525f913e50a3a7b0141985e\";'),(464,'extensionScannerNotAffected','8c4b22b879db672714ac1690dd2b3237','s:32:\"8c4b22b879db672714ac1690dd2b3237\";'),(465,'extensionScannerNotAffected','5f5077001a66e69aea233d3e93d1310a','s:32:\"5f5077001a66e69aea233d3e93d1310a\";'),(466,'extensionScannerNotAffected','feee31a4f626a6e125a5886c05638641','s:32:\"feee31a4f626a6e125a5886c05638641\";'),(467,'extensionScannerNotAffected','be5e9c098491dac91f80e7a1de064e9d','s:32:\"be5e9c098491dac91f80e7a1de064e9d\";'),(468,'extensionScannerNotAffected','5d612a94ffffdcb591692e002ff2ab9f','s:32:\"5d612a94ffffdcb591692e002ff2ab9f\";'),(469,'extensionScannerNotAffected','f3a267cb99caea4e72ed6d66bf4e2da8','s:32:\"f3a267cb99caea4e72ed6d66bf4e2da8\";'),(470,'extensionScannerNotAffected','014e5dcf35c3d6fc8b8a692cbb56e43a','s:32:\"014e5dcf35c3d6fc8b8a692cbb56e43a\";'),(471,'extensionScannerNotAffected','8c18585d0c72f55b03906fa74b79e30d','s:32:\"8c18585d0c72f55b03906fa74b79e30d\";'),(472,'extensionScannerNotAffected','7c4c3a6eb349d033a95e8724b0b725ba','s:32:\"7c4c3a6eb349d033a95e8724b0b725ba\";'),(473,'extensionScannerNotAffected','326a48421379558a7527a56b45c24e1b','s:32:\"326a48421379558a7527a56b45c24e1b\";'),(474,'extensionScannerNotAffected','16be5a40555f720156c6006f34dcfacd','s:32:\"16be5a40555f720156c6006f34dcfacd\";'),(475,'extensionScannerNotAffected','997ee9b6a3dae2a060def0bebcfc9aca','s:32:\"997ee9b6a3dae2a060def0bebcfc9aca\";'),(476,'extensionScannerNotAffected','9d8da8c7e57a1d109a100f35334b1d47','s:32:\"9d8da8c7e57a1d109a100f35334b1d47\";'),(477,'extensionScannerNotAffected','e0127e7c34fa573e3cae3815130f8211','s:32:\"e0127e7c34fa573e3cae3815130f8211\";'),(478,'extensionScannerNotAffected','168ead984b1d1dd9414b43bfb7463383','s:32:\"168ead984b1d1dd9414b43bfb7463383\";'),(479,'extensionScannerNotAffected','7b640070cdb67b65b964fb8008a81670','s:32:\"7b640070cdb67b65b964fb8008a81670\";'),(480,'extensionScannerNotAffected','c40b044fad095951023985f97183d4e7','s:32:\"c40b044fad095951023985f97183d4e7\";'),(481,'extensionScannerNotAffected','b0b91dbb7f0f75c6c1d49c32aba9c863','s:32:\"b0b91dbb7f0f75c6c1d49c32aba9c863\";'),(482,'extensionScannerNotAffected','6771f198146576fc2a70ce5461728021','s:32:\"6771f198146576fc2a70ce5461728021\";'),(483,'extensionScannerNotAffected','ff1d6d30074b812fe841bb0a198ddfbf','s:32:\"ff1d6d30074b812fe841bb0a198ddfbf\";'),(484,'extensionScannerNotAffected','03ee79ca31203e4b288fa61017b0cb04','s:32:\"03ee79ca31203e4b288fa61017b0cb04\";'),(485,'extensionScannerNotAffected','ecc8d90045bf5b51a4f5087f19e3bb72','s:32:\"ecc8d90045bf5b51a4f5087f19e3bb72\";'),(486,'extensionScannerNotAffected','b3eb2f57b7048dc10b06b601afa1a68b','s:32:\"b3eb2f57b7048dc10b06b601afa1a68b\";'),(487,'extensionScannerNotAffected','7f030ea0c1e7246e77472efc8ebf1b2e','s:32:\"7f030ea0c1e7246e77472efc8ebf1b2e\";'),(488,'extensionScannerNotAffected','4e8f9d2deaef1ad3d7207ea590882a33','s:32:\"4e8f9d2deaef1ad3d7207ea590882a33\";'),(489,'extensionScannerNotAffected','c6fbc609b28b5481a761b791cb61da80','s:32:\"c6fbc609b28b5481a761b791cb61da80\";'),(490,'extensionScannerNotAffected','38354fcab935ef5dee086db0a7770360','s:32:\"38354fcab935ef5dee086db0a7770360\";'),(491,'extensionScannerNotAffected','932da83d688a200c366300752d904773','s:32:\"932da83d688a200c366300752d904773\";'),(492,'extensionScannerNotAffected','544a390bad17591adb404198dbb9d3b6','s:32:\"544a390bad17591adb404198dbb9d3b6\";'),(493,'extensionScannerNotAffected','44845e9f43edfe787e293d09d66d8b8c','s:32:\"44845e9f43edfe787e293d09d66d8b8c\";'),(494,'extensionScannerNotAffected','89b1943128ab1b71dd4983855c5ce1e8','s:32:\"89b1943128ab1b71dd4983855c5ce1e8\";'),(495,'extensionScannerNotAffected','37b4a4b1ccd4f2a7a50c41cd97456b2b','s:32:\"37b4a4b1ccd4f2a7a50c41cd97456b2b\";'),(496,'extensionScannerNotAffected','17c5edeb29362e8ea099f7589be67ad4','s:32:\"17c5edeb29362e8ea099f7589be67ad4\";'),(497,'extensionScannerNotAffected','fa77b4ee0f04a894e7d389285e5cc8b1','s:32:\"fa77b4ee0f04a894e7d389285e5cc8b1\";'),(498,'extensionScannerNotAffected','8160290ad0e0a2b26df443f27751a519','s:32:\"8160290ad0e0a2b26df443f27751a519\";'),(499,'extensionScannerNotAffected','d47cc2621605a6652ab17ed6f239ac9b','s:32:\"d47cc2621605a6652ab17ed6f239ac9b\";'),(500,'extensionScannerNotAffected','e71d3f59519be4cb6df58929f0436275','s:32:\"e71d3f59519be4cb6df58929f0436275\";'),(501,'extensionScannerNotAffected','6d29b1ad49f8ecc3fecbea36a67859ec','s:32:\"6d29b1ad49f8ecc3fecbea36a67859ec\";'),(502,'extensionScannerNotAffected','9f89c82b6e0b431c04b87e4e229769d3','s:32:\"9f89c82b6e0b431c04b87e4e229769d3\";'),(503,'extensionScannerNotAffected','18f664c8c929b1cdb4418781aeda7af0','s:32:\"18f664c8c929b1cdb4418781aeda7af0\";'),(504,'extensionScannerNotAffected','ffba01881f59bda8b8095ca54ecf72a3','s:32:\"ffba01881f59bda8b8095ca54ecf72a3\";'),(505,'extensionScannerNotAffected','f3433235666f9f90138a5cc9c8b41965','s:32:\"f3433235666f9f90138a5cc9c8b41965\";'),(506,'extensionScannerNotAffected','9869b0cc809f66493dccd791ca3525cd','s:32:\"9869b0cc809f66493dccd791ca3525cd\";'),(507,'extensionScannerNotAffected','b9d9a059308b72188e7509b43b846547','s:32:\"b9d9a059308b72188e7509b43b846547\";'),(508,'extensionScannerNotAffected','7ef2b99923b54ba86061deb6092e67c8','s:32:\"7ef2b99923b54ba86061deb6092e67c8\";'),(509,'extensionScannerNotAffected','09d5425f8dcc500277411b9bd0d5fbb7','s:32:\"09d5425f8dcc500277411b9bd0d5fbb7\";'),(510,'extensionScannerNotAffected','efae40738a60a8456a1b3948da8cfccc','s:32:\"efae40738a60a8456a1b3948da8cfccc\";'),(511,'extensionScannerNotAffected','c07befd21624591e3f814d5401a30ab5','s:32:\"c07befd21624591e3f814d5401a30ab5\";'),(512,'extensionScannerNotAffected','45d4bb180e30ef974e9b4e584836d78c','s:32:\"45d4bb180e30ef974e9b4e584836d78c\";'),(513,'extensionScannerNotAffected','8f45ae1aaba029344a202292be5330e6','s:32:\"8f45ae1aaba029344a202292be5330e6\";'),(514,'extensionScannerNotAffected','6f5d8526244b83ae2759751e8bf436a7','s:32:\"6f5d8526244b83ae2759751e8bf436a7\";'),(515,'extensionScannerNotAffected','2fab8c2a8303d0a8114f19c44e1fa845','s:32:\"2fab8c2a8303d0a8114f19c44e1fa845\";'),(516,'extensionScannerNotAffected','16693438f698c4c62a0b084e48d45bba','s:32:\"16693438f698c4c62a0b084e48d45bba\";'),(517,'extensionScannerNotAffected','cb228474381c9bad647a56a5fa5c81e6','s:32:\"cb228474381c9bad647a56a5fa5c81e6\";'),(518,'extensionScannerNotAffected','3295a8a4fb1c867e34d1fe5e59850e3b','s:32:\"3295a8a4fb1c867e34d1fe5e59850e3b\";'),(519,'extensionScannerNotAffected','d4c7b89fac340cb568aeec849a9351a7','s:32:\"d4c7b89fac340cb568aeec849a9351a7\";'),(520,'extensionScannerNotAffected','af6c8a91b462b758ba24a21814c3fd4a','s:32:\"af6c8a91b462b758ba24a21814c3fd4a\";'),(521,'extensionScannerNotAffected','a4cfe53b75527725ffe8b9c303441ffd','s:32:\"a4cfe53b75527725ffe8b9c303441ffd\";'),(522,'extensionScannerNotAffected','669243de0464324ebcdf223492862f8e','s:32:\"669243de0464324ebcdf223492862f8e\";'),(523,'extensionScannerNotAffected','715138a5b463064e31a081aedb900026','s:32:\"715138a5b463064e31a081aedb900026\";'),(524,'extensionScannerNotAffected','0df982270c206f486f2f7c6854a6f99f','s:32:\"0df982270c206f486f2f7c6854a6f99f\";'),(525,'extensionScannerNotAffected','7b13ac9c4bdb0c699cc2c9271f75aa1d','s:32:\"7b13ac9c4bdb0c699cc2c9271f75aa1d\";'),(526,'extensionScannerNotAffected','72e33b0cd5ea51707ee9f2a87a066ebb','s:32:\"72e33b0cd5ea51707ee9f2a87a066ebb\";'),(527,'extensionScannerNotAffected','a2513e917270e1444cb272b38569011c','s:32:\"a2513e917270e1444cb272b38569011c\";'),(528,'extensionScannerNotAffected','c99d2df025ecc1582a7049e9be6e6405','s:32:\"c99d2df025ecc1582a7049e9be6e6405\";'),(529,'extensionScannerNotAffected','f91b97a15f215c9e427638d785caf933','s:32:\"f91b97a15f215c9e427638d785caf933\";'),(530,'extensionScannerNotAffected','ead9f6ff892cd928e4937d19b36272ec','s:32:\"ead9f6ff892cd928e4937d19b36272ec\";'),(531,'extensionScannerNotAffected','e0e6fa9bfc877ecd4b4c21cab0063fc3','s:32:\"e0e6fa9bfc877ecd4b4c21cab0063fc3\";'),(532,'extensionScannerNotAffected','7d7372a93db8f0ae259ae77372cfbcd6','s:32:\"7d7372a93db8f0ae259ae77372cfbcd6\";'),(533,'extensionScannerNotAffected','bc81bd413ec79a3bd71c16ea1afd3115','s:32:\"bc81bd413ec79a3bd71c16ea1afd3115\";'),(534,'extensionScannerNotAffected','7131beea634942741f92e9601786da79','s:32:\"7131beea634942741f92e9601786da79\";'),(535,'extensionScannerNotAffected','60b2c243b6ca4e013f444d7e2d62611f','s:32:\"60b2c243b6ca4e013f444d7e2d62611f\";'),(536,'extensionScannerNotAffected','3c18b48efafd3165cff971d467d727a5','s:32:\"3c18b48efafd3165cff971d467d727a5\";'),(537,'extensionScannerNotAffected','849409f5781ae37108ac498323e0b786','s:32:\"849409f5781ae37108ac498323e0b786\";'),(538,'extensionScannerNotAffected','0899a3301413807e5bb8d7431a92b042','s:32:\"0899a3301413807e5bb8d7431a92b042\";'),(539,'extensionScannerNotAffected','3e4178c5b2bcbd76797b85cbb7cb0ecb','s:32:\"3e4178c5b2bcbd76797b85cbb7cb0ecb\";'),(540,'extensionScannerNotAffected','adb5167fdb6a60c96ea7233ccbd0a630','s:32:\"adb5167fdb6a60c96ea7233ccbd0a630\";'),(541,'extensionScannerNotAffected','a3204ad427a5493624561fdca88f3994','s:32:\"a3204ad427a5493624561fdca88f3994\";'),(542,'extensionScannerNotAffected','0638957df2121314be77233a34bd138e','s:32:\"0638957df2121314be77233a34bd138e\";'),(543,'extensionScannerNotAffected','a32ab65f5492301a7bfef920ee30e237','s:32:\"a32ab65f5492301a7bfef920ee30e237\";'),(544,'extensionScannerNotAffected','afce2ed8b41decf309b87a6fba363309','s:32:\"afce2ed8b41decf309b87a6fba363309\";'),(545,'extensionScannerNotAffected','1bcca5208a568bb7d212ab2ba8f53264','s:32:\"1bcca5208a568bb7d212ab2ba8f53264\";'),(546,'extensionScannerNotAffected','116f6fea622aa1d03d3ee1a0aa976765','s:32:\"116f6fea622aa1d03d3ee1a0aa976765\";'),(547,'extensionScannerNotAffected','75c72558f548655ad173eac504ed7c83','s:32:\"75c72558f548655ad173eac504ed7c83\";'),(548,'extensionScannerNotAffected','4521d52bf6b6f35d7aab6ee189f024ac','s:32:\"4521d52bf6b6f35d7aab6ee189f024ac\";'),(549,'extensionScannerNotAffected','1b838cb5afa8a8747d5f8c32197f797f','s:32:\"1b838cb5afa8a8747d5f8c32197f797f\";'),(550,'extensionScannerNotAffected','fc45009fe1064c751abc7f6037173a10','s:32:\"fc45009fe1064c751abc7f6037173a10\";'),(551,'extensionScannerNotAffected','cfcb23aaa05c6c2c9447279702ee60b1','s:32:\"cfcb23aaa05c6c2c9447279702ee60b1\";'),(552,'extensionScannerNotAffected','fdef8b8e54457e6afb6363b0eccf7ba9','s:32:\"fdef8b8e54457e6afb6363b0eccf7ba9\";'),(553,'extensionScannerNotAffected','bb7e90b7b2e103dfc5a434e1d5facd81','s:32:\"bb7e90b7b2e103dfc5a434e1d5facd81\";'),(554,'extensionScannerNotAffected','3de90c68e822c91f0ded139b68bfe482','s:32:\"3de90c68e822c91f0ded139b68bfe482\";'),(555,'extensionScannerNotAffected','a267e0d6dc4a0385543f7a8b8a2a8ebb','s:32:\"a267e0d6dc4a0385543f7a8b8a2a8ebb\";'),(556,'extensionScannerNotAffected','3ffba20946d109ca5f8fcdad0eb7ef9d','s:32:\"3ffba20946d109ca5f8fcdad0eb7ef9d\";'),(557,'extensionScannerNotAffected','6c3cd6027c59bdb765ad671987b71ca1','s:32:\"6c3cd6027c59bdb765ad671987b71ca1\";'),(558,'extensionScannerNotAffected','1d33bcb61f5318f8f76b66dbf246dd1d','s:32:\"1d33bcb61f5318f8f76b66dbf246dd1d\";'),(559,'extensionScannerNotAffected','0293b40f4b6581d5b5f657797e02e880','s:32:\"0293b40f4b6581d5b5f657797e02e880\";'),(560,'extensionScannerNotAffected','2690c3f607b061473e9015f09435fc58','s:32:\"2690c3f607b061473e9015f09435fc58\";'),(561,'extensionScannerNotAffected','2cceb729a693916619e3898a48bb7d7f','s:32:\"2cceb729a693916619e3898a48bb7d7f\";'),(562,'extensionScannerNotAffected','f801ab642054829ee07b7827c6260c1a','s:32:\"f801ab642054829ee07b7827c6260c1a\";'),(563,'extensionScannerNotAffected','3584234aa6609e266b4d9dbb2b86d6ae','s:32:\"3584234aa6609e266b4d9dbb2b86d6ae\";'),(564,'extensionScannerNotAffected','29912aad74ac0ac74b563abfa2691046','s:32:\"29912aad74ac0ac74b563abfa2691046\";'),(565,'extensionScannerNotAffected','4b8eab6dc6925a8361432070110460ff','s:32:\"4b8eab6dc6925a8361432070110460ff\";'),(566,'extensionScannerNotAffected','6f8a563727b06eca78f63f7a4a60e1e5','s:32:\"6f8a563727b06eca78f63f7a4a60e1e5\";'),(567,'extensionScannerNotAffected','82a630b895e10045dcc02537ff1dbc0d','s:32:\"82a630b895e10045dcc02537ff1dbc0d\";'),(568,'extensionScannerNotAffected','7b080cc6b1c75d4f0250d21d0347a5e4','s:32:\"7b080cc6b1c75d4f0250d21d0347a5e4\";'),(569,'extensionScannerNotAffected','b38fed99897122695e3c7a32c8ca3fb6','s:32:\"b38fed99897122695e3c7a32c8ca3fb6\";'),(570,'extensionScannerNotAffected','49e9b2afd8c29c002992df010f42ed8f','s:32:\"49e9b2afd8c29c002992df010f42ed8f\";'),(571,'extensionScannerNotAffected','610700d32cc7a4c67695c4628e9d0c68','s:32:\"610700d32cc7a4c67695c4628e9d0c68\";'),(572,'extensionScannerNotAffected','8159e82a48c8a5304dc727db44cf9ccc','s:32:\"8159e82a48c8a5304dc727db44cf9ccc\";'),(573,'extensionScannerNotAffected','c867e41158524f2425306c52f1344f75','s:32:\"c867e41158524f2425306c52f1344f75\";'),(574,'extensionScannerNotAffected','77b498481c54b2bdba2caea86be14528','s:32:\"77b498481c54b2bdba2caea86be14528\";'),(575,'extensionScannerNotAffected','d0d23edf6c292c455044e4b156757bce','s:32:\"d0d23edf6c292c455044e4b156757bce\";'),(576,'extensionScannerNotAffected','73c26732718e840a0c3a13f510f694ec','s:32:\"73c26732718e840a0c3a13f510f694ec\";'),(577,'extensionScannerNotAffected','a53a92fe2d6c98562d32885b77c7c118','s:32:\"a53a92fe2d6c98562d32885b77c7c118\";'),(578,'extensionScannerNotAffected','7068e4f7efdaddea25cbb2d7d7c39994','s:32:\"7068e4f7efdaddea25cbb2d7d7c39994\";'),(579,'extensionScannerNotAffected','1d3586c7e8327fa52cf0d6953eaaf9a9','s:32:\"1d3586c7e8327fa52cf0d6953eaaf9a9\";'),(580,'extensionScannerNotAffected','83fd799b47acc1b01dfc15faf495c6fa','s:32:\"83fd799b47acc1b01dfc15faf495c6fa\";'),(581,'extensionScannerNotAffected','362eee6e56383d6ee4f61bc84a53412e','s:32:\"362eee6e56383d6ee4f61bc84a53412e\";'),(582,'extensionScannerNotAffected','fc0849229ef2b9f0025fc95d61645b4e','s:32:\"fc0849229ef2b9f0025fc95d61645b4e\";'),(583,'extensionScannerNotAffected','d7b642039705d72c6e28a3a0dbcc3128','s:32:\"d7b642039705d72c6e28a3a0dbcc3128\";'),(584,'extensionScannerNotAffected','217b962b55424e8b5905143e5d044a85','s:32:\"217b962b55424e8b5905143e5d044a85\";'),(585,'extensionScannerNotAffected','527f6e433f022b4f9bbfa0696107bba4','s:32:\"527f6e433f022b4f9bbfa0696107bba4\";'),(586,'extensionScannerNotAffected','51dee146d4cd05df5ac931c3e6fc2bcb','s:32:\"51dee146d4cd05df5ac931c3e6fc2bcb\";'),(587,'extensionScannerNotAffected','35a7e9bd2bb88459c1bc9aefe2efff33','s:32:\"35a7e9bd2bb88459c1bc9aefe2efff33\";'),(588,'extensionScannerNotAffected','55f49723ea2532b995d6d9aaebdcbd67','s:32:\"55f49723ea2532b995d6d9aaebdcbd67\";'),(589,'extensionScannerNotAffected','bbfe9546564594ee855a227bc3ee4bc0','s:32:\"bbfe9546564594ee855a227bc3ee4bc0\";'),(590,'extensionScannerNotAffected','b07252d8a7122b98d43cc2a4014d04fb','s:32:\"b07252d8a7122b98d43cc2a4014d04fb\";'),(591,'extensionScannerNotAffected','13e7127f427e0f21e15ffa5b5796bd14','s:32:\"13e7127f427e0f21e15ffa5b5796bd14\";'),(592,'extensionScannerNotAffected','fce695ddf31518b64a70a4db5fc7f2b9','s:32:\"fce695ddf31518b64a70a4db5fc7f2b9\";'),(593,'extensionScannerNotAffected','d057f8afa511161ac29cc64bf69191dc','s:32:\"d057f8afa511161ac29cc64bf69191dc\";'),(594,'extensionScannerNotAffected','644c08fddac592313d084b05773d57a0','s:32:\"644c08fddac592313d084b05773d57a0\";'),(595,'extensionScannerNotAffected','d660c9ab53b9eceb2583ee3d0223edea','s:32:\"d660c9ab53b9eceb2583ee3d0223edea\";'),(596,'extensionScannerNotAffected','c428519a0bdac804eb834fa5f5e48533','s:32:\"c428519a0bdac804eb834fa5f5e48533\";'),(597,'extensionScannerNotAffected','d8ca805203b2e45899537e7780032ff8','s:32:\"d8ca805203b2e45899537e7780032ff8\";'),(598,'extensionScannerNotAffected','2cbeb3b086105df5d4ba831d55802395','s:32:\"2cbeb3b086105df5d4ba831d55802395\";'),(599,'extensionScannerNotAffected','1afb1edc3ae1b1083c09200591d1b929','s:32:\"1afb1edc3ae1b1083c09200591d1b929\";'),(600,'extensionScannerNotAffected','ed983315cf25ac96bd414ffbfed6cf79','s:32:\"ed983315cf25ac96bd414ffbfed6cf79\";'),(601,'extensionScannerNotAffected','335ecc9f4130c3fc4b00e416ae00a608','s:32:\"335ecc9f4130c3fc4b00e416ae00a608\";'),(602,'extensionScannerNotAffected','8242a09071390f9b0eee618057a861ba','s:32:\"8242a09071390f9b0eee618057a861ba\";'),(603,'extensionScannerNotAffected','6fbf1a0bc13c1f883aa587c45a466e4a','s:32:\"6fbf1a0bc13c1f883aa587c45a466e4a\";'),(604,'extensionScannerNotAffected','b9f9b7fd91fee7ac6ec34aeeac8ca018','s:32:\"b9f9b7fd91fee7ac6ec34aeeac8ca018\";'),(605,'extensionScannerNotAffected','38a00c1a79f1521e29c10c43db146e7f','s:32:\"38a00c1a79f1521e29c10c43db146e7f\";'),(606,'extensionScannerNotAffected','533828d0a15378bcdadcff7fe3ad595f','s:32:\"533828d0a15378bcdadcff7fe3ad595f\";'),(607,'extensionScannerNotAffected','7fb6f9460525b3dda81f192a341d39af','s:32:\"7fb6f9460525b3dda81f192a341d39af\";'),(608,'extensionScannerNotAffected','091e5b4094bc3130d41a5582b291912a','s:32:\"091e5b4094bc3130d41a5582b291912a\";'),(609,'extensionScannerNotAffected','f37b07ef576c54a9f4c89c9e5b4025fe','s:32:\"f37b07ef576c54a9f4c89c9e5b4025fe\";'),(610,'extensionScannerNotAffected','e5f98248a9e22264708a39db4329ebc4','s:32:\"e5f98248a9e22264708a39db4329ebc4\";'),(611,'extensionScannerNotAffected','680b0fe8152a292d916e4329e58fcdcc','s:32:\"680b0fe8152a292d916e4329e58fcdcc\";'),(612,'extensionScannerNotAffected','38af711de1842099efa03bb1b1d04a51','s:32:\"38af711de1842099efa03bb1b1d04a51\";'),(613,'extensionScannerNotAffected','367dae17293f842d45930d8b5470cf45','s:32:\"367dae17293f842d45930d8b5470cf45\";'),(614,'extensionScannerNotAffected','22e17d683c48685fc8a7184252fc2485','s:32:\"22e17d683c48685fc8a7184252fc2485\";'),(615,'extensionScannerNotAffected','14be0a015f1bef748eae080c2b57aba7','s:32:\"14be0a015f1bef748eae080c2b57aba7\";'),(616,'extensionScannerNotAffected','e88e9e27dab577f87d38f63c24bfe01d','s:32:\"e88e9e27dab577f87d38f63c24bfe01d\";'),(617,'extensionScannerNotAffected','f92caf92ac4069d38ca1db6c0400a259','s:32:\"f92caf92ac4069d38ca1db6c0400a259\";'),(618,'extensionScannerNotAffected','43ec24ad0c3b73b7aef27e6cba9ce4c7','s:32:\"43ec24ad0c3b73b7aef27e6cba9ce4c7\";'),(619,'extensionScannerNotAffected','54ffc49091b69458321d4b670d5a384d','s:32:\"54ffc49091b69458321d4b670d5a384d\";'),(620,'extensionScannerNotAffected','743f1789098f2c75437e5c3a93e9f5cf','s:32:\"743f1789098f2c75437e5c3a93e9f5cf\";'),(621,'extensionScannerNotAffected','9c4f56051dc7c5ffecf6c0e5ea995028','s:32:\"9c4f56051dc7c5ffecf6c0e5ea995028\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text DEFAULT NULL,
  `constants` text DEFAULT NULL,
  `config` text DEFAULT NULL,
  `basedOn` tinytext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (2,1,1701863219,1546914508,0,0,0,0,256,NULL,0,'Microtemplate: Root',1,3,'EXT:favicon/Configuration/TypoScript,EXT:advancedtitle/Configuration/TypoScript/,EXT:fluid_styled_content/Configuration/TypoScript/,EXT:paginatedprocessors/Configuration/TypoScript,EXT:pagelist/Configuration/TypoScript/,EXT:containeritems/Configuration/TypoScript,EXT:form/Configuration/TypoScript/,EXT:gallerycontent/Configuration/TypoScript,EXT:youtubevideo/Configuration/TypoScript/,EXT:vimeovideo/Configuration/TypoScript/,EXT:pagelist/Configuration/TypoScript/EventVcal/,EXT:personnel/Configuration/TypoScript/,EXT:microtemplate/Configuration/TypoScript,EXT:microtemplate/Configuration/TypoScript/DarkMode','# domainName = https://microtemplate.t3brightside.com/\r\nfavicon.svgPath = data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'36\' height=\'36\' viewBox=\'0 0 36 36\'%3E%3Cg transform=\'translate(-481 -613)\'%3E%3Cg transform=\'translate(-280 -278)\'%3E%3Cpath d=\'M0,0H36V36H0Z\' transform=\'translate(761 891)\' fill=\'%23bc0000\'/%3E%3C/g%3E%3Crect width=\'22\' height=\'7\' transform=\'translate(488 620)\' fill=\'%23fff\'/%3E%3Crect width=\'9\' height=\'11\' transform=\'translate(488 631)\' fill=\'%23fff\'/%3E%3Crect width=\'9\' height=\'11\' transform=\'translate(501 631)\' fill=\'%23fff\'/%3E%3C/g%3E%3C/svg%3E%0A\r\nfavicon.pngPath = EXT:microtemplate/Resources/Public/Icons/Extension.png\r\ncontainerSection.bgImageQuality = 70\r\nyoutubevideo.cssPriority = 0\r\nmicrotemplate.mobilemenuContentPage = 54\r\nmicrotemplate.socialLinksEnabled = 1\r\nmicrotemplate.twitterUrl = https://twitter.com/t3brightside\r\nmicrotemplate.githubUrl = https://github.com/t3brightside','','',0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(2048) NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `verify_ssl` int(11) NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`additional_headers`)),
  `identifier` varchar(36) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text DEFAULT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `bodytext` mediumtext DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `records` text DEFAULT NULL,
  `pages` text DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `header_link` varchar(1024) NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) NOT NULL DEFAULT '0',
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `date` int(11) NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext DEFAULT NULL,
  `accessibility_title` varchar(30) NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) NOT NULL DEFAULT '',
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_caption` varchar(255) DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_pagelist_authors` tinytext DEFAULT NULL,
  `tx_pagelist_template` varchar(25) DEFAULT NULL,
  `tx_pagelist_orderby` tinytext DEFAULT NULL,
  `tx_pagelist_disableimages` int(11) NOT NULL DEFAULT 0,
  `tx_pagelist_disableabstract` int(11) NOT NULL DEFAULT 0,
  `tx_pagelist_startfrom` varchar(6) DEFAULT NULL,
  `tx_pagelist_limit` varchar(6) DEFAULT NULL,
  `tx_personnel` tinytext DEFAULT NULL,
  `tx_personnel_template` varchar(25) DEFAULT NULL,
  `tx_personnel_images` int(11) NOT NULL DEFAULT 0,
  `tx_personnel_vcard` int(11) NOT NULL DEFAULT 0,
  `tx_personnel_information` int(11) NOT NULL DEFAULT 0,
  `tx_personnel_orderby` tinytext DEFAULT NULL,
  `tx_personnel_startfrom` varchar(6) DEFAULT NULL,
  `tx_personnel_limit` varchar(6) DEFAULT NULL,
  `tx_pagelist_recursive` int(11) NOT NULL DEFAULT 0,
  `tx_gallerycontent_template` varchar(25) DEFAULT NULL,
  `tx_gallerycontent_cropratio` varchar(25) DEFAULT NULL,
  `tx_gallerycontent_cropratiozoom` varchar(25) DEFAULT NULL,
  `tx_gallerycontent_showtitle` int(11) NOT NULL DEFAULT 0,
  `tx_gallerycontent_showdesc` int(11) NOT NULL DEFAULT 0,
  `tx_gallerycontent_showtitlezoom` int(11) NOT NULL DEFAULT 0,
  `tx_gallerycontent_showdesczoom` int(11) NOT NULL DEFAULT 0,
  `tx_youtubevideo_assets` int(11) NOT NULL DEFAULT 0,
  `tx_youtubevideo_colcount` int(11) NOT NULL DEFAULT 0,
  `tx_youtubevideo_oneatatime` int(11) NOT NULL DEFAULT 0,
  `tx_youtubevideo_titles` int(11) NOT NULL DEFAULT 0,
  `tx_youtubevideo_descriptions` int(11) NOT NULL DEFAULT 0,
  `tx_paginatedprocessors_paginationenabled` int(11) NOT NULL DEFAULT 0,
  `tx_paginatedprocessors_itemsperpage` varchar(6) DEFAULT NULL,
  `tx_paginatedprocessors_pagelinksshown` varchar(6) DEFAULT NULL,
  `tx_paginatedprocessors_urlsegment` varchar(20) DEFAULT NULL,
  `tx_paginatedprocessors_anchor` int(11) NOT NULL DEFAULT 0,
  `tx_paginatedprocessors_anchorid` int(11) NOT NULL DEFAULT 0,
  `tx_container_parent` int(11) NOT NULL DEFAULT 0,
  `tx_containeritems_a_stayopen` int(11) DEFAULT NULL,
  `tx_containeritems_a_firstopen` int(11) DEFAULT NULL,
  `tx_containeritems_s_aligncontent` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_framepadding` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_fullheight` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_textcolorselect` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_bgcolorselect` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_bgimagewidth` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_bgvideosound` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgvideoclearframe` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgvideoonoloop` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgplacement` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_bgfixed` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgoverlay` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_bgoverlaydark` varchar(25) DEFAULT NULL,
  `tx_containeritems_classes` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_valign` varchar(7) DEFAULT NULL,
  `tx_containeritems_s_bgoverlayfilters` int(11) DEFAULT NULL,
  `tx_containeritems_s_bgoverlayblur` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgoverlaysaturate` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgoverlayhue` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgoverlaybrightness` smallint(6) DEFAULT NULL,
  `tx_containeritems_s_bgoverlaysepia` smallint(6) DEFAULT NULL,
  `tx_containeritems_b_style` varchar(25) DEFAULT NULL,
  `tx_personnel_titlewrap` varchar(2) DEFAULT NULL,
  `tx_pagelist_titlewrap` varchar(12) DEFAULT NULL,
  `tx_containeritems_siema_style` varchar(25) DEFAULT NULL,
  `tx_containeritems_siema_startindex` int(11) DEFAULT NULL,
  `tx_containeritems_siema_loop` int(11) DEFAULT NULL,
  `tx_containeritems_siema_pagination` varchar(25) DEFAULT NULL,
  `tx_containeritems_siema_nav` int(11) DEFAULT NULL,
  `tx_containeritems_customid` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_bgmediaeffect` varchar(25) DEFAULT NULL,
  `tx_containeritems_s_contentwidth` varchar(25) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `tx_vimeovideo_assets` int(11) NOT NULL DEFAULT 0,
  `tx_vimeovideo_colcount` int(11) NOT NULL DEFAULT 0,
  `tx_vimeovideo_titles` int(11) NOT NULL DEFAULT 0,
  `tx_vimeovideo_descriptions` int(11) NOT NULL DEFAULT 0,
  `tx_vimeovideo_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `container_parent` (`tx_container_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=334 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (1,'',1,1679829793,1546914883,0,0,0,0,'',8,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','Home','',NULL,0,0,0,0,1,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',0,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\">home</value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">40</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">7</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\">#ffffff</value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n                <field index=\"bgvideobutton\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"overlaycolordarkmode\">\n                    <value index=\"vDEF\">#69008f</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,'left','0',1,'text-light','bg-dark','',0,0,1,'1',0,'','rgba(0,0,0,0.6)','home','bottom',1,14,148,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'fade-in','wide',0,0,0,0,0,NULL),(2,'',1,1679752550,1546914897,0,0,0,0,'',9,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<h1><br>Power of TYPO3<br>in a Friendly Package</h1>\r\n<p><a class=\"btn\" href=\"t3://page?uid=1#3\" title=\"Learn more about Microtemplate\">about Microtemplate</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,1,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(3,'',1,1678900168,1546915014,0,0,0,0,'',20480,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','Overview','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0',0,0,0,0,0,NULL),(4,'',1,1701863467,1546915078,0,0,0,0,'',20736,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','YouTube & Vimeo','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,'center','0',0,'0','bg-black',NULL,0,0,0,'0',1,NULL,NULL,NULL,'center',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','wide',0,0,0,0,0,NULL),(5,'',1,1678811995,1546915121,0,0,0,0,'',20992,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','News & Events','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0',0,0,0,0,0,NULL),(6,'',1,1678862674,1546915139,0,0,0,0,'',21248,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','People','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,'center','0',0,'0','bg-dark',NULL,0,0,0,'0',0,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','regular',0,0,0,0,0,NULL),(7,'',1,1679233939,1546915175,0,0,0,0,'',21504,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','Get Microtemplate','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',0,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlaycolordarkmode\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','wide',0,0,0,0,0,NULL),(8,'',1,1679752561,1546915458,0,0,0,0,'',16,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Microtemplate features','','<p><strong>Microtemplate is a ready to go TYPO3 template. Easy enough to set it up yourself.</strong><br /><strong>Or it can be a website as a service...</strong></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,3,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(9,'',1,1678457509,1546915505,0,0,0,0,'',1538,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerColumns-1-1','Features info in 2 columns','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'extra-small','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,3,0,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(10,'',1,1679752722,1546915539,0,0,0,0,'',1543,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Layouts','','<p>Section containers come with video &amp; image backgrounds, automatic menu construction and much more. Besides just neatly structured grids there\'s a lot to get creative with.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,102,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,9,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(13,'',2,1679820871,1546915742,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<h2>Devices</h2>\r\n<p>Template works on mobiles, tablets and desktops. It\'s fully touch friendly.</p>\r\n<h2>SEO &amp; META</h2>\r\n<p>Fully prepared for social media and sure, it\'s search engine friendly.</p>\r\n<h2>GDPR Friendly</h2>\r\n<p>It does not send cookies or collect user data by default.</p>\r\n<h2>Minimal design sub pages</h2>\r\n<p>Subpages are lightbox-like. It gives far greater possibilities for content editing compared to an actual lightbox. It works better on mobile devices and makes content sharing easier. Besides it\'s super nice and clutter-free to read.</p>\r\n<h2>Extensions and content</h2>\r\n<p><a href=\"t3://page?uid=1\">Back to the page</a> for content examples...</p>',0,0,0,0,0,0,10,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',1,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(14,'',2,1546917504,1546915775,0,0,0,0,'',128,0,0,0,0,NULL,0,'a:4:{s:6:\"colPos\";N;s:25:\"tx_gridelements_container\";N;s:23:\"tx_gridelements_columns\";N;s:16:\"sys_language_uid\";N;}',0,0,0,0,'header','Microtemplate features','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,5,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(16,'',1,1701863399,1546917717,0,0,0,0,'',20792,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"tx_youtubevideo_assets\":\"\",\"tx_youtubevideo_colcount\":\"\",\"tx_youtubevideo_titles\":\"\",\"tx_youtubevideo_descriptions\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'youtubevideo_pi1','','',NULL,0,0,0,0,1,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,1,0,0,1,0,0,'1','1','video',0,0,332,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(17,'',1,1678873227,1546918590,0,0,0,0,'',1920,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"pages\":\"\",\"tx_pagelist_recursive\":\"\",\"tx_pagelist_orderby\":\"\",\"tx_pagelist_startfrom\":\"\",\"tx_pagelist_limit\":\"\",\"tx_pagelist_template\":\"\",\"tx_pagelist_titlewrap\":\"\",\"tx_pagelist_disableimages\":\"\",\"tx_imagelazyload\":\"\",\"tx_pagelist_disableabstract\":\"\",\"selected_categories\":\"\",\"tx_pagelist_authors\":\"\",\"tx_paginatedprocessors_paginationenabled\":\"\",\"tx_paginatedprocessors_itemsperpage\":\"\",\"tx_paginatedprocessors_pagelinksshown\":\"\",\"tx_paginatedprocessors_urlsegment\":\"\",\"tx_paginatedprocessors_anchor\":\"\",\"tx_paginatedprocessors_anchorid\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'pagelist_sub','Pagelist to show articles','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'small','',NULL,'3',101,'','',0,'100','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','0','','',NULL,124,0,0,0,0,'','cards','pages.sorting',0,1,'','',NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,1,'2','3','pagelist',0,5,5,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'h2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(19,'',1,1679752657,1546921981,0,0,0,0,'',2561,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','People','','<p><strong>Personnell extension&nbsp;</strong>is a tool for creating contacts with vCard download. Besides it connects to Pagelist to use personnel records as authors, contact persons etc.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,6,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(20,'',1,1678451966,1546922012,0,0,0,0,'',2817,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"pages\":\"\",\"tx_personnel_orderby\":\"\",\"tx_personnel_startfrom\":\"\",\"tx_personnel_limit\":\"\",\"tx_personnel_template\":\"\",\"tx_personnel_titlewrap\":\"\",\"tx_personnel_images\":\"\",\"tx_imagelazyload\":\"\",\"tx_personnel_information\":\"\",\"tx_personnel_vcard\":\"\",\"selected_categories\":\"\",\"tx_paginatedprocessors_paginationenabled\":\"\",\"tx_paginatedprocessors_itemsperpage\":\"\",\"tx_paginatedprocessors_pagelinksshown\":\"\",\"tx_paginatedprocessors_urlsegment\":\"\",\"tx_paginatedprocessors_anchor\":\"\",\"tx_paginatedprocessors_anchorid\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'personnel_frompages','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'medium','extra-small',NULL,'6',101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','0','','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,6,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'h2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(21,'',1,1679752607,1546922676,0,0,0,0,'',1026,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Website as a Service','','<p>Fully maintained package with everything prebuilt. Full LTS maintenance in a yearly package and no cost on the template development.<br />&nbsp;</p>\r\n<p><a class=\"btn\" href=\"https://t3brightside.com/typo3-now\">SEE THE PACKAGE</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,31,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(22,'',1,1679752589,1546923013,0,0,0,0,'',1792,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','News & Events','','<p><strong>Pagelist extension</strong> introduces four new page types: articles, events, products, and vacancies. So creating different types of articles is as easy and dynamic as creating a page.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','extra-small',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,5,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(23,'',1,1678613629,1546923849,0,0,0,0,'',21760,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','Footer','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',0,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideobutton\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','wide',0,0,0,0,0,NULL),(24,'',1,1701851926,1546923876,0,0,0,0,'',1056,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p>by:&nbsp;<strong>Brightside OÜ</strong><br /><a href=\"https://t3brightside.com/\">TYPO3 development &amp; hosting agency</a><br />&nbsp;</p>\r\n<p><a href=\"t3://page?uid=1#329\">Data privacy</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,23,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(31,'',1,1639992607,1546940427,0,0,0,0,'',1632,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerColumns-1-1','Use It','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,7,0,0,'0','0',0,'0','0',NULL,0,0,0,'0',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(32,'',1,1679752600,1546940456,0,0,0,0,'',1600,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','Get Microtemplate','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,7,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(33,'',1,1679752614,1546940509,0,0,0,0,'',1032,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Do it Yourself','','<p>Use \'composer req&nbsp;<strong>t3brightside/microtemplate\'</strong> or get it from TYPO3 repo. Help yourself with the documentation to get going.<br />&nbsp;</p>\r\n<p><a class=\"btn\" href=\"https://github.com/t3brightside/microtemplate\">GitHub</a>&nbsp;<a class=\"btn\" href=\"https://extensions.typo3.org/extension/microtemplate/\">TER</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,102,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,31,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(36,'',7,1679752514,1547008799,0,0,0,0,'',64,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','Time schedule','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(37,'',7,1547010011,1547008808,0,0,0,0,'',128,0,0,0,0,NULL,0,'a:16:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:8:\"bodytext\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"sectionIndex\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;s:25:\"tx_gridelements_container\";N;}',0,0,0,0,'html','Time schedule table','','<table style=\"font-size: 0.8em; margin-top: 1em;\"  align=\"center\">\r\n<tr>\r\n <td>\r\n <td>8:30-9:30\r\n <td>9:30-10:30\r\n <td>10:3-11:30\r\n <td>11:30-12:30\r\n <td>12:30-2:00\r\n <td>2:00-3:00\r\n <td>3:00-4:00\r\n <td  align=\"center\">4:00-5:00\r\n</tr>\r\n<tr>\r\n <td align=\"center\">M\r\n <td align=\"center\">---<td align=\"center\"><font color=\"blue\">SUB1<br>\r\n <td align=\"center\"><font color=\"pink\">SUB2<br>\r\n <td align=\"center\"><font color=\"red\">SUB3<br>\r\n <td rowspan=\"6\"align=\"center\">L<br>U<br>N<br>C<br>H\r\n <td align=\"center\"><font color=\"maroon\">SUB4<br>\r\n <td align=\"center\"><font color=\"brown\">SUB5<br>\r\n <td align=\"center\">class\r\n</tr>\r\n<tr>\r\n <td align=\"center\">T\r\n <td align=\"center\"><font color=\"blue\">SUB1<br>\r\n <td align=\"center\"><font color=\"red\">SUB2<br>\r\n <td align=\"center\"><font color=\"pink\">SUB3<br>\r\n <td align=\"center\">---\r\n <td align=\"center\"><font color=\"orange\">SUB4<BR>\r\n <td align=\"center\"><font color=\"maroon\">SUB5<br>\r\n <td align=\"center\">library\r\n</tr>\r\n<tr>\r\n <td align=\"center\">W\r\n <td align=\"center\"><font color=\"pink\">SUB1<br>\r\n <td align=\"center\"><font color=\"orange\">SUB2<BR>\r\n <td align=\"center\"><font color=\"brown\">SWA<br>\r\n <td align=\"center\">---\r\n <td colspan=\"3\" align=\"center\"><font color=\"green\"> lab\r\n</tr>\r\n<tr>\r\n <td align=\"center\">T\r\n <td align=\"center\">SUB1<br>\r\n <td align=\"center\"><font color=\"brown\">SUB2<br>\r\n <td align=\"center\"><font color=\"orange\">SUB3<BR>\r\n <td align=\"center\">---\r\n <td align=\"center\"><font color=\"blue\">SUB4<br>\r\n <td align=\"center\"><font color=\"red\">SUB5<br>\r\n <td align=\"center\">library\r\n</tr>\r\n<tr>\r\n <td align=\"center\">F\r\n <td align=\"center\"><font color=\"orange\">SUB1<BR>\r\n <td align=\"center\"><font color=\"maroon\">SUB2<br>\r\n <td align=\"center\"><font color=\"blue\">SUB3<br>\r\n <td align=\"center\">---\r\n <td align=\"center\"><font color=\"pink\">SUB4<br>\r\n <td align=\"center\"><font color=\"brown\">SUB5<br>\r\n <td align=\"center\">library\r\n</tr>\r\n</table>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(38,'',7,1679752522,1547009124,0,0,0,0,'',384,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Some more...','','<p>Pellentesque in ipsum eget odio condimentum hendrerit sollicitudin vel tortor. Pellentesque diam odio, vulputate in faucibus vel, viverra at arcu. Phasellus sit amet nisl quis massa porttitor ullamcorper non a dolor. Duis lorem turpis, rhoncus in lacus a, commodo posuere sem.</p>\r\n<p>Pellentesque nec malesuada elit. Praesent ipsum massa, aliquam ac dapibus nec, ultrices in nulla. Etiam a ipsum odio. Duis rutrum eros et efficitur vestibulum. Nulla rhoncus, risus sed eleifend sodales, sem orci gravida magna, eget suscipit ex metus in nunc. Cras pharetra fringilla dolor nec finibus. Donec sed metus in ipsum elementum luctus.&nbsp;</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(40,'',7,1679752504,1547010050,0,0,0,0,'',32,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p>Event pages are part of Pagelist extension. Giving you full control over start and end time, vCal download, event location and all the regular features of the page content type.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(78,'',1,1679752731,1548001796,0,0,0,0,'',3600,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p><strong>Did you notice there is no GDPR-Cookie-Spookie popup?</strong><br />As long as you\'r server is compatible you are safe to go without one.<br /><br />?h, and there\'s a dark side – but only if you have the mode set on your device.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'medium','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,3,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(80,'',5,1679398585,1551407717,0,0,0,0,'',28,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_a_stayopen\":\"\",\"tx_containeritems_a_firstopen\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerAccordion','Accordion','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,1,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(81,'',5,1679752469,1551407746,0,0,0,0,'',30,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Second element in accordion','','<p>Fusce semper sed magna id semper. Suspendisse non diam tortor. Nullam eget consectetur urna. Curabitur laoreet lacinia lobortis. Vestibulum congue aliquet augue eu tincidunt. Proin et velit non eros laoreet blandit in ut velit. Maecenas porttitor venenatis leo eget malesuada. Lako ta reporio unta nema dscaredo.</p>',0,0,0,0,0,0,17,1,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,80,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(84,'',5,1679752393,1551408170,0,0,0,0,'',16,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p><strong>This is the Pagelist extension page type of article. It\'s a convenient way to build smaller scale news sections and blogs on your site.</strong></p>\r\n<p>Pagelist has event, vacancie and product page types besides articles. Very convenient way design your articles with all the content items at hand from media to forms. Authors and contact persons are set from personnel records.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(85,'',5,1679752481,1551760617,0,0,0,0,'',29,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','First element in accordion can be set open on load','','<p>Yup, simple as this, content elements in accordion container become accordion items.</p>\r\n<p>Mauris fermentum sit amet est eget porta. Nunc accumsan scelerisque felis a posuere. Etiam faucibus sollicitudin tristique. Sed et lectus in nunc convallis rhoncus. Praesent sollicitudin sem mi, non commodo arcu elementum quis. In sit amet nulla tincidunt enim hendrerit dignissim et sed mi. Pellentesque auctor purus justo, ut accumsan libero ultrices non. Ut eu nisi felis. Vivamus ultrices tincidunt condimentum. Mauris condimentum tristique nisi. Mauris porta risus neque, vitae elementum purus vestibulum ac.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,80,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(89,'',1,1679752270,1559996344,0,0,0,0,'',21696,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','Get in Touch','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',0,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">30</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">4</value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n                <field index=\"overlaycolordarkmode\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,'0','0',0,'text-light','bg-dark','300',0,0,0,'0',0,'','',NULL,'0',0,31,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0',0,0,0,0,0,NULL),(90,'',1,1679752626,1559996585,0,0,0,0,'',1552,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Send a message','','<p>Drop us a message if you\'d like custom setup or a&nbsp;<a href=\"https://t3brightside.com/typo3-hosting\">hosted package</a>&nbsp;of the Microtemplate. Bugs, feature requests and such, it all happens in <a href=\"https://github.com/t3brightside/microtemplate\">GitHub</a>.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,89,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(91,'',1,1679821022,1559996632,0,0,0,0,'',3080,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"pi_flexform\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'form_formframework','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.persistenceIdentifier\">\n                    <value index=\"vDEF\">1:/form_definitions/contact_us.form.yaml</value>\n                </field>\n                <field index=\"settings.overrideFinishers\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,89,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(124,'',26,1679752537,1568099852,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p>Thank you for getting in touch with us!<br />We will get back to you shortly.<br />&nbsp;</p>\r\n<p><a class=\"btn\" href=\"t3://page?uid=1\">back to the page</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'0','sorting ASC',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(157,'',1,1678811775,1616346056,0,0,0,0,'',20896,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_s_aligncontent\":\"\",\"tx_containeritems_s_valign\":\"\",\"tx_containeritems_s_fullheight\":\"\",\"tx_containeritems_s_contentwidth\":\"\",\"tx_containeritems_s_framepadding\":\"\",\"tx_containeritems_s_textcolorselect\":\"\",\"tx_containeritems_s_bgcolorselect\":\"\",\"image\":\"\",\"tx_containeritems_s_bgimagewidth\":\"\",\"assets\":\"\",\"tx_containeritems_s_bgvideosound\":\"\",\"tx_containeritems_s_bgvideoonoloop\":\"\",\"tx_containeritems_s_bgvideoclearframe\":\"\",\"tx_containeritems_s_bgplacement\":\"\",\"tx_containeritems_s_bgfixed\":\"\",\"tx_containeritems_s_bgmediaeffect\":\"\",\"tx_containeritems_s_bgoverlay\":\"\",\"tx_containeritems_s_bgoverlaydark\":\"\",\"tx_containeritems_s_bgoverlayfilters\":\"\",\"tx_containeritems_s_bgoverlayblur\":\"\",\"tx_containeritems_s_bgoverlaysaturate\":\"\",\"tx_containeritems_s_bgoverlayhue\":\"\",\"tx_containeritems_s_bgoverlaybrightness\":\"\",\"tx_containeritems_s_bgoverlaysepia\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerSection','Galleries','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"alignment\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"nopadding\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullwidth\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fullheight\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"vcenter\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"class\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"textcolor\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgcolordefined\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"bgcolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"image\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"bgimgeffect\">\n                    <value index=\"vDEF\">20</value>\n                </field>\n                <field index=\"bgimagewidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"bgvideo\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideosound\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgvideoclearframe\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"noloop\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"bgimgplacement\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"overlaycolor\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"overlayopacity\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n                <field index=\"bgfixed\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,'center','0',0,'0','bg-light',NULL,0,0,0,'0',0,'','',NULL,'0',NULL,0,100,0,100,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','wide',0,0,0,0,0,NULL),(158,'',1,1679749915,1616346184,0,0,0,0,'',20944,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"assets\":\"\",\"tx_gallerycontent_template\":\"\",\"imagecols\":\"\",\"tx_gallerycontent_cropratio\":\"\",\"tx_gallerycontent_showtitle\":\"\",\"tx_gallerycontent_showdesc\":\"\",\"image_zoom\":\"\",\"tx_gallerycontent_cropratiozoom\":\"\",\"tx_gallerycontent_showtitlezoom\":\"\",\"tx_gallerycontent_showdesczoom\":\"\",\"tx_paginatedprocessors_paginationenabled\":\"\",\"tx_paginatedprocessors_itemsperpage\":\"\",\"tx_paginatedprocessors_pagelinksshown\":\"\",\"tx_paginatedprocessors_urlsegment\":\"\",\"tx_paginatedprocessors_anchor\":\"\",\"tx_paginatedprocessors_anchorid\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'gallerycontent','Gallery of Roads','',NULL,0,0,0,4,0,0,0,4,0,0,0,'default',0,'','extra-small',NULL,NULL,101,'','',1,'100','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','tower','none',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,157,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(159,'',1,1679752575,1616346452,0,0,0,0,'',20920,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Galleries','','<p><strong>Gallerycontent extension</strong>&nbsp;is a breeze to create content with. Make it look good with the selection of predefined crop ratios and have a full control over titles and descriptions. Pagination and touch friendly lightbox are included.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','medium',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,157,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(163,'',5,1679397623,1616376872,0,0,0,0,'',24,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"assets\":\"\",\"tx_gallerycontent_template\":\"\",\"tx_imagelazyload\":\"\",\"imagecols\":\"\",\"tx_gallerycontent_cropratio\":\"\",\"tx_gallerycontent_showtitle\":\"\",\"tx_gallerycontent_showdesc\":\"\",\"image_zoom\":\"\",\"tx_gallerycontent_cropratiozoom\":\"\",\"tx_gallerycontent_showtitlezoom\":\"\",\"tx_gallerycontent_showdesczoom\":\"\",\"tx_paginatedprocessors_paginationenabled\":\"\",\"tx_paginatedprocessors_itemsperpage\":\"\",\"tx_paginatedprocessors_pagelinksshown\":\"\",\"tx_paginatedprocessors_urlsegment\":\"\",\"tx_paginatedprocessors_anchor\":\"\",\"tx_paginatedprocessors_anchorid\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'gallerycontent','Gallery','',NULL,0,0,0,4,0,0,0,1,0,0,0,'default',0,'small','',NULL,NULL,0,'','',0,'100','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'0',0,0,0,'0',NULL,NULL,0,'0','widescreen','default',0,0,0,0,0,0,0,0,0,1,'1','','g',1,320,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(164,'',5,1679752439,1616377231,0,0,0,0,'',1855,0,0,0,0,NULL,45,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Youtube','','<p>Youtubevideo is efficient and neat. Custom cover images and titles for overriding default ones or not...</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',101,'','',0,'3','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,'','0','sorting ASC',0,0,'','','','0',0,0,0,'0','','',0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,166,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(165,'',5,1679752375,1616377231,0,0,0,0,'',1984,0,0,0,0,NULL,44,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"tx_youtubevideo_assets\":\"\",\"tx_youtubevideo_colcount\":\"\",\"tx_youtubevideo_titles\":\"\",\"tx_youtubevideo_descriptions\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'youtubevideo_pi1','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'small','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,'','0','sorting ASC',0,0,'','','','0',0,0,0,'0','','',0,'0','default','default',0,0,0,0,1,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(166,'',5,1679398393,1616377231,0,0,0,0,'',1599,0,0,0,0,NULL,43,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerColumns-1-1','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','medium','','',0,'','',0,'100','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','','',NULL,124,0,0,0,0,'','0','sorting ASC',0,0,'','','','0',0,0,0,'0','','',0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(187,'',1,1679752741,1638849396,0,0,0,0,'',1541,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Content','','<p>Well designed content elements and extensions cover:<strong> text, videos, galleries,&nbsp;news, events, persons and forms</strong>. All come with styles that fit right in.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'2','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,9,0,0,NULL,'0',0,NULL,NULL,NULL,0,0,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL),(266,'',54,1679820213,1678368286,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p><a class=\"btn\" href=\"t3://page?uid=1#7\">I WANT IT NOW!</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,0,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(267,'',2,1679823717,1678456780,0,0,0,0,'',64,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"assets\":\"\",\"tx_gallerycontent_template\":\"\",\"imagecols\":\"\",\"tx_gallerycontent_cropratio\":\"\",\"tx_gallerycontent_showtitle\":\"\",\"tx_gallerycontent_showdesc\":\"\",\"image_zoom\":\"\",\"tx_gallerycontent_cropratiozoom\":\"\",\"tx_gallerycontent_showtitlezoom\":\"\",\"tx_gallerycontent_showdesczoom\":\"\",\"tx_paginatedprocessors_paginationenabled\":\"\",\"tx_paginatedprocessors_itemsperpage\":\"\",\"tx_paginatedprocessors_pagelinksshown\":\"\",\"tx_paginatedprocessors_urlsegment\":\"\",\"tx_paginatedprocessors_anchor\":\"\",\"tx_paginatedprocessors_anchorid\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'gallerycontent','','',NULL,0,0,0,1,0,0,0,2,0,0,0,'default',0,'medium','',NULL,NULL,0,'','',1,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','none',0,0,0,0,0,0,0,0,0,0,'','','',0,0,0,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(268,'',2,1679820862,1678466492,0,0,0,0,'',32,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<h2>Speedy &amp; lightweight</h2>\r\n<p>No CSS or JS frameworks. Embed and on demand loaded assets give some amazing speed scores!</p>',0,0,0,0,0,0,0,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','none',0,0,0,0,0,0,0,0,0,0,'','','',0,0,0,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(299,'',1,1701862987,1678812117,1,0,0,0,'',20848,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"assets\":\"\",\"imagewidth\":\"\",\"imageheight\":\"\",\"imageorient\":\"\",\"imagecols\":\"\",\"image_zoom\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p><strong>Youtubevideo extension</strong> integrates videos in a GDPR friendly way – no intrucive popups on page load but just consent after clicking \'play\'. Set custom cover images, titles, and descriptions, and create a fully paginated gallery of many videos.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'extra-small','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,4,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(309,'',1,1679752713,1679029162,0,0,0,0,'',3606,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p><a class=\"btn\" href=\"t3://page?uid=2\" title=\"Edit\">Speed, Devices, SEO &amp; More</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'medium','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,3,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(320,'',5,1679752402,1679397016,0,0,0,0,'',20,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Another gallery example','','<p>There\'s pagination with anchor setting to keep things in focus. Lightbox JS and CSS is not loaded to your page source if zoom is not activated in gallery.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,0,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(321,'',5,1679752430,1679397507,0,0,0,0,'',1597,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','Columns','','<p>There\'s plenty to choose from to divide the content and keep it neat.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,0,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(323,'',5,1679752452,1679398251,0,0,0,0,'',1919,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','GDPR','','<p>Youtubevideo loads everything only after you click play and consent. Including cover image, title, etc.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,102,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,166,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(324,'',5,1679752419,1679398439,0,0,0,0,'',26,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','Accordion','','',0,0,0,0,0,0,0,2,0,0,0,'default',0,'extra-small','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,'','','',0,0,0,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(327,'',11,1679747972,1679747888,0,0,0,0,'',128,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p><strong>Requested page was not found…</strong><br />&nbsp;</p>\r\n<p><a class=\"btn\" href=\"t3://page?uid=1\">Go to main page</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(329,NULL,1,1701851485,1701851474,0,0,0,0,'',4,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"tx_containeritems_customid\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerPopup','Data Privacy Popup','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,1,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,0,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(330,'',1,1701851508,1701851508,0,0,0,0,'',6,0,0,0,0,NULL,0,'',0,0,0,0,'text','Data privacy statement','','<p>Put your data privacy statement here…</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,329,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(331,'',1,1701862953,1701862953,0,0,0,0,'',20768,0,0,0,0,NULL,0,'',0,0,0,0,'text','YouTube & Vimeo','','<p><strong>Youtubevideo &amp; Vimeovideo</strong> extensions&nbsp;integrates videos in a GDPR friendly way – no intrucive popups on page load but just consent after clicking \'play\'. Set custom cover images, titles, and descriptions, and create a fully paginated galleries.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,4,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(332,NULL,1,1701863506,1701862999,0,0,0,0,'',20784,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"tx_containeritems_classes\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'containerColumns-1-1','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'medium','small',NULL,NULL,101,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,4,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,0,0,0,0,NULL),(333,'',1,1701863373,1701863361,0,0,0,0,'',20844,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"tx_container_parent\":\"\",\"header\":\"\",\"header_layout\":\"\",\"date\":\"\",\"subheader\":\"\",\"tx_vimeovideo_assets\":\"\",\"tx_vimeovideo_colcount\":\"\",\"tx_vimeovideo_titles\":\"\",\"tx_vimeovideo_descriptions\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'vimeovideo_pi1','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,102,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,NULL,'cards','pages.sorting',0,0,NULL,NULL,NULL,'cards',0,0,0,'0',NULL,NULL,0,'0','default','default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,0,0,332,NULL,NULL,'0','0',NULL,'0','0',NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'0',NULL,0,100,0,100,0,'0','0','0','0',NULL,NULL,'0',1,NULL,'0',NULL,0,1,0,1,0,NULL);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT 1,
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(11) NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `update_comment` mediumtext DEFAULT NULL,
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_news_domain_model_news` (
  `tx_personnel_authors` tinytext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news`
--

LOCK TABLES `tx_news_domain_model_news` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_personnel_domain_model_person`
--

DROP TABLE IF EXISTS `tx_personnel_domain_model_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_personnel_domain_model_person` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `firstname` tinytext DEFAULT NULL,
  `lastname` tinytext DEFAULT NULL,
  `profession` tinytext DEFAULT NULL,
  `info` text DEFAULT NULL,
  `phone` tinytext DEFAULT NULL,
  `email` tinytext DEFAULT NULL,
  `images` int(10) unsigned DEFAULT 0,
  `selected_categories` text DEFAULT NULL,
  `linkedin` tinytext DEFAULT NULL,
  `xing` tinytext DEFAULT NULL,
  `responsibility` tinytext DEFAULT NULL,
  `twitter` tinytext DEFAULT NULL,
  `github` tinytext DEFAULT NULL,
  `instagram` tinytext DEFAULT NULL,
  `youtube` tinytext DEFAULT NULL,
  `facebook` tinytext DEFAULT NULL,
  `website` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`sys_language_uid`),
  KEY `parent` (`pid`,`sorting`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_personnel_domain_model_person`
--

LOCK TABLES `tx_personnel_domain_model_person` WRITE;
/*!40000 ALTER TABLE `tx_personnel_domain_model_person` DISABLE KEYS */;
INSERT INTO `tx_personnel_domain_model_person` VALUES (2,6,1679821425,1546922417,0,0,0,0,'',48,0,0,0,NULL,0,'{\"title\":\"\",\"firstname\":\"\",\"lastname\":\"\",\"profession\":\"\",\"responsibility\":\"\",\"phone\":\"\",\"email\":\"\",\"images\":\"\",\"info\":\"\",\"linkedin\":\"\",\"xing\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"sys_language_uid\":\"\",\"selected_categories\":\"\"}',0,0,0,0,'','Lennart','Meri','2nd President of Estonia','','','example@domain.com',1,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,6,1678817249,1546922491,0,0,0,0,'',40,0,0,0,NULL,0,'{\"title\":\"\",\"firstname\":\"\",\"lastname\":\"\",\"profession\":\"\",\"responsibility\":\"\",\"phone\":\"\",\"email\":\"\",\"images\":\"\",\"info\":\"\",\"linkedin\":\"\",\"xing\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"sys_language_uid\":\"\",\"selected_categories\":\"\"}',0,0,0,0,'','Barack','Obama','44th President of the U.S.','','','example@domain.com',1,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,6,1679823471,1678816831,0,0,0,0,'',32,0,0,0,NULL,0,'{\"title\":\"\",\"firstname\":\"\",\"lastname\":\"\",\"profession\":\"\",\"responsibility\":\"\",\"phone\":\"\",\"email\":\"\",\"images\":\"\",\"info\":\"\",\"linkedin\":\"\",\"xing\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"sys_language_uid\":\"\",\"selected_categories\":\"\"}',0,0,0,0,'','Tsai','Ing-wen','7th President of Taiwan','','','example@domain.com',1,'0','','','',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tx_personnel_domain_model_person` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-06 11:54:40
